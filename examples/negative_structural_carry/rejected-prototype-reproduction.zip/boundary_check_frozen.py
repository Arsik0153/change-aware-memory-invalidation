"""Copy of review_checks.py using the frozen reconstructed rejected prototype."""
import ast
import importlib.util
import json
from pathlib import Path
import sys

from cami.index import build_index, compare_indexes, signature
from cami.models import Anchor, Claim, Equals, MemoryState, PolicyConfig, Provenance, Subject
from cami.policies import SelectionContext, advance_state, select_claims
from cami.validation import ValidationContext, validate_claim
from scripts.check_structural_carry import snapshot

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT))
from rejected_prototype import select_negative_carry
POLICY=PolicyConfig(id='symbol_validate')
source='def f(x=2):\n    return x\n'
before=snapshot(source)
after=snapshot(source+'\n# comment-only transition\n')
old_index,new_index=build_index(before),build_index(after)
claim=Claim(claim_id='fixture',repo_id=before.repo_id,origin_commit=before.revision,
    kind='signature_equals',text='Exact signature',scope='Exact syntax',
    subject=Subject(path='module.py',qualname='f',node_kind='function'),
    predicate=Equals(type='signature_equals',expected_signature=signature(ast.parse('def f(x=1): pass').body[0])))
prov=Provenance(claim_id=claim.claim_id,scenario_id='review',anchors=(Anchor(path='module.py',qualname='f',scope='symbol',observed_commit=before.revision,content_hash=before.blobs[0].content_hash,origin='static'),))
initial=MemoryState(claim_id=claim.claim_id,revision=before.revision,state='needs_validation',last_checked_commit=None,last_supported_commit=None,last_verdict=None,basis='validated',current_provenance=prov,available=False)
old_result=validate_claim(claim,ValidationContext(before,old_index,prov,OUT,OUT))
assert (old_result.verdict,old_result.reason)==('contradicted','predicate_mismatch')
previous=advance_state(initial,select_claims(SelectionContext(before.revision,(claim,),(prov,),(initial,),compare_indexes(old_index,old_index,before,before),protocol_version='1.1'),POLICY)[0],POLICY,old_result,True)
changes=compare_indexes(old_index,new_index,before,after)

def check(current_claim):
    original,=select_claims(SelectionContext(after.revision,(current_claim,),(prov,),(previous,),changes,protocol_version='1.1'),POLICY)
    decision=select_negative_carry(current_claim,prov,previous,original,before,after,old_index,new_index)
    fresh=validate_claim(current_claim,ValidationContext(after,new_index,prov,OUT,OUT))
    state=advance_state(previous,decision.effective,POLICY,None if decision.suppressed else fresh,True)
    return {'suppressed':decision.suppressed,'original_reasons':original.reasons,
       'fresh_verdict':fresh.verdict,'carried_verdict':state.last_verdict,'available':state.available,
       'last_checked_commit':state.last_checked_commit}

stable=check(claim)
assert stable['suppressed'] and stable['fresh_verdict']==stable['carried_verdict']=='contradicted'
changed_claim=claim.model_copy(update={'predicate':Equals(type='signature_equals',expected_signature=signature(ast.parse('def f(x=2): pass').body[0]))})
changed=check(changed_claim)
assert changed['suppressed'] and changed['fresh_verdict']=='supported' and not changed['available']

# Keep the claim frozen, but source signature recovers: production reason blocks carry.
recovered=snapshot('def f(x=1):\n    return x\n')
recovery_index=build_index(recovered)
recovery_changes=compare_indexes(old_index,recovery_index,before,recovered)
selection,=select_claims(SelectionContext(recovered.revision,(claim,),(prov,),(previous,),recovery_changes,protocol_version='1.1'),POLICY)
recovery=select_negative_carry(claim,prov,previous,selection,before,recovered,old_index,recovery_index)
assert not recovery.suppressed
result={'stable_context':stable,'same_ID_predicate_changed_outside_precondition':changed,
    'source_signature_recovery':{'suppressed':recovery.suppressed,'original_reasons':selection.reasons},
    'source_or_corpus_access':False}
(OUT/'frozen_rejected_boundary_results.json').write_text(json.dumps(result,indent=2)+'\n')
changed_artifact = {
    'prototype_provenance': 'Reconstructed initial rejected source; no original hash asserted.',
    'original_claim': claim.model_dump(mode='json'),
    'changed_claim': changed_claim.model_dump(mode='json'),
    'previous_state': previous.model_dump(mode='json'),
    'before_source': source,
    'after_source': source + '\n# comment-only transition\n',
    'observed': changed,
}
(OUT/'frozen_rejected_changed_claim_counterexample.json').write_text(json.dumps(changed_artifact, indent=2)+'\n')
print(json.dumps(result))
