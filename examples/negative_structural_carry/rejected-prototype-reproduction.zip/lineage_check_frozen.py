"""Copy of lineage_check.py using the frozen reconstructed rejected prototype."""
import json
import runpy
from pathlib import Path

OUT=Path(__file__).resolve().parent
ns=runpy.run_path(str(OUT/'boundary_check_frozen.py'))
from cami.index import build_index, compare_indexes
from cami.models import PolicyConfig
from cami.policies import SelectionContext, advance_state, select_claims
from cami.validation import ValidationContext, validate_claim
from scripts.check_structural_carry import snapshot
from rejected_prototype import select_negative_carry

claim,prov=ns['claim'],ns['prov']
t0,idx0,st0=ns['before'],ns['old_index'],ns['previous']
t1=snapshot('def f(x=1):\n    return x\n')
idx1=build_index(t1)
# Genuine production state carrying a truthful historical mismatch over an unvalidated recovery.
keep=PolicyConfig(id='keep_all')
selection,=select_claims(SelectionContext(t1.revision,(claim,),(prov,),(st0,),compare_indexes(idx0,idx1,t0,t1),protocol_version='1.1'),keep)
st1=advance_state(st0,selection,keep,None,True)
t2=snapshot('def f(x=1):\n    return x\n# unrelated comment\n')
idx2=build_index(t2)
policy=PolicyConfig(id='symbol_validate')
selection,=select_claims(SelectionContext(t2.revision,(claim,),(prov,),(st1,),compare_indexes(idx1,idx2,t1,t2),protocol_version='1.1'),policy)
decision=select_negative_carry(claim,prov,st1,selection,t1,t2,idx1,idx2)
fresh=validate_claim(claim,ValidationContext(t2,idx2,prov,OUT,OUT))
assert decision.suppressed and fresh.verdict=='supported'
result={'claim_unchanged':True,'provenance_unchanged':True,'parser_roots_validator_unchanged':True,
 'prior_negative_genuine_production_validation':True,'intermediate_policy':'keep_all',
 'current_policy':'symbol_validate','current_selection_reasons':selection.reasons,
 'suppressed':decision.suppressed,'fresh_verdict':fresh.verdict,
 'previous_last_verdict':st1.last_verdict,
 'missing_precondition':'Previous state must be bound to before witness, or have an uninterrupted verified carry lineage from its last check.'}
(OUT/'frozen_rejected_lineage_counterexample.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
