"""Private fixed evaluator. Only candidate package source is admitted into frozen tests."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_tasks(expected):
    path = ROOT / "tasks.json"
    if sha(path) != expected:
        raise ValueError("Frozen task manifest hash mismatch")
    return json.loads(path.read_bytes())


def verify(path, expected):
    if not path.is_file() or path.is_symlink() or sha(path) != expected:
        raise ValueError("Frozen evaluator asset mismatch")


def extract_archive(path, out):
    out.mkdir(parents=True, exist_ok=False)
    with tarfile.open(path, "r:gz") as archive:
        for member in archive.getmembers():
            rel = Path(member.name)
            if rel.is_absolute() or ".." in rel.parts or ".git" in rel.parts or not member.isfile():
                raise ValueError("Nonregular/history/unsafe source archive entry")
        archive.extractall(out, filter="data")


def evaluate(task_id, workspace, out, python, task_sha, checks):
    tasks = load_tasks(task_sha)
    matches = [t for t in tasks["tasks"] if t["task_id"] == task_id]
    if len(matches) != 1:
        raise ValueError("Unknown fixed task ID")
    task = matches[0]
    out.mkdir(parents=True, exist_ok=False)
    verify(ROOT / task["base_archive"]["path"], task["base_archive"]["sha256"])
    oracle = ROOT / task["private_evaluator_root"]
    for name, expected in task["oracle_hashes"].items():
        verify(oracle / name, expected)
    target = out / "evaluation-workspace"
    extract_archive(ROOT / task["base_archive"]["path"], target)
    candidate = workspace / "src/packaging"
    package = target / "src/packaging"
    if not candidate.is_dir() or candidate.is_symlink():
        raise ValueError("Candidate package source unavailable")
    accepted = {}
    for path in candidate.rglob("*"):
        if path.is_symlink():
            raise ValueError("Candidate package symlinks are not admitted")
        if path.is_file() and "__pycache__" not in path.parts:
            accepted[str(path.relative_to(candidate))] = sha(path)
    shutil.rmtree(package)
    shutil.copytree(candidate, package, ignore=shutil.ignore_patterns("__pycache__"))
    # Candidate tests, pytest config, root hooks and extra top-level modules cannot weaken the evaluator.
    tests = target / "tests"
    if tests.exists():
        shutil.rmtree(tests)
    shutil.copytree(oracle / "tests", tests)
    env = {
        **os.environ,
        "PYTHONPATH": str(target / "src"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
    }
    env.pop("PYTEST_ADDOPTS", None)
    results = []
    selected = ["acceptance", "regression"] if checks == "all" else [checks]
    for check in selected:
        names = (
            task["acceptance_node_ids"] if check == "acceptance" else [task["regression_test_path"]]
        )
        command = [
            str(python),
            "-m",
            "pytest",
            "-q",
            "-c",
            "/dev/null",
            "--confcutdir",
            str(tests),
            "-p",
            "no:cacheprovider",
            *names,
        ]
        tick = time.monotonic()
        try:
            result = subprocess.run(command, cwd=target, env=env, capture_output=True, timeout=300)
            stdout, stderr, code = result.stdout, result.stderr, result.returncode
            failure = None
        except subprocess.TimeoutExpired as error:
            stdout, stderr, code = error.stdout or b"", error.stderr or b"", 124
            failure = "timeout"
        log = out / (check + ".log")
        log.write_bytes(stdout + stderr)
        results.append(
            {
                "check": check,
                "argv": [str(x) for x in command],
                "exit_code": code,
                "failure": failure,
                "wall_seconds": time.monotonic() - tick,
                "log": log.name,
                "log_sha256": sha(log),
            }
        )
    report = {
        "task_id": task_id,
        "status": "pass" if all(x["exit_code"] == 0 for x in results) else "fail",
        "task_manifest_sha256": task_sha,
        "candidate_package_files": accepted,
        "candidate_scope": "src/packaging only",
        "frozen_tests_restored": True,
        "evaluator_source_hashes": task["oracle_hashes"],
        "results": results,
        "model_calls": 0,
        "environment_isolation": "Caller must isolate evaluator network/processes; preflight uses Linux unshare --net.",
    }
    (out / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--tasks-sha256", required=True)
    parser.add_argument("--checks", choices=["all", "acceptance", "regression"], default="all")
    args = parser.parse_args()
    report = evaluate(
        args.task,
        args.workspace.resolve(),
        args.out.resolve(),
        args.python.absolute(),
        args.tasks_sha256,
        args.checks,
    )
    print(
        json.dumps(
            {"task_id": args.task, "status": report["status"], "checks": len(report["results"])}
        )
    )
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
