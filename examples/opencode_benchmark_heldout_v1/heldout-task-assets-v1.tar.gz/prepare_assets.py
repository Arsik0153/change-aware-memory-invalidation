"""Freeze the two preselected task fixtures; never invokes a task model or network."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
CORPUS = None
ENV = {**os.environ, "GIT_NO_LAZY_FETCH": "1", "GIT_TERMINAL_PROMPT": "0"}
COMMANDS = []


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def git(commit, *args):
    allowed = set(SELECTION["bases"] + SELECTION["gold_commits"])
    if commit not in allowed:
        raise ValueError("Snapshot outside preselected task envelope")
    argv = [
        "git",
        "--no-replace-objects",
        "--no-optional-locks",
        "-c",
        "protocol.allow=never",
        "-C",
        str(CORPUS),
        *args,
    ]
    result = subprocess.run(argv, capture_output=True, env=ENV, timeout=30)
    COMMANDS.append(
        {
            "snapshot_context": commit,
            "argv": argv,
            "exit_code": result.returncode,
            "stdout_sha256": digest(result.stdout),
        }
    )
    result.check_returncode()
    return result.stdout


def snapshot(commit):
    files = {}
    for item in git(commit, "ls-tree", "-rz", "--full-tree", commit).split(b"\0"):
        if not item:
            continue
        meta, raw_path = item.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        name = raw_path.decode("utf-8")
        if kind != "blob" or mode not in {"100644", "100755"} or ".git" in Path(name).parts:
            raise ValueError("Unsupported canonical task snapshot entry")
        raw = git(commit, "cat-file", "blob", oid)
        if hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() != oid:
            raise ValueError("Git blob identity mismatch")
        files[name] = {
            "raw": raw,
            "mode": int(mode, 8) & 0o777,
            "git_oid": oid,
            "sha256": digest(raw),
        }
    return files


def archive(path, files):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    with (
        path.open("xb") as stream,
        gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as zipped,
        tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as tar,
    ):
        for name, row in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(row["raw"])
            info.mode = row["mode"]
            info.mtime = info.uid = info.gid = 0
            info.uname = info.gname = ""
            tar.addfile(info, io.BytesIO(row["raw"]))
    return {
        "path": str(path.relative_to(ROOT)),
        "sha256": digest(path.read_bytes()),
        "bytes": path.stat().st_size,
        "file_count": len(files),
        "history_exposed": False,
        "git_metadata_included": False,
    }


def materialize(path, files):
    path.mkdir(parents=True, exist_ok=False)
    for name, row in files.items():
        dst = path / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(row["raw"])
        dst.chmod(row["mode"])


SELECTION = json.loads((ROOT / "selection.json").read_bytes())
TASKS = [
    {
        "id": "packaging-epoch-prefix",
        "issue": 712,
        "acceptance": ["tests/test_specifiers.py::TestSpecifier::test_specifiers"],
        "prompt": """Fix version-prefix matching with epochs in Packaging.

Wildcard equality specifiers must compare release components with zero padding without losing the epoch distinction. Reproduce through the public API:

- Specifier("==2!1.0.0.0.*").contains("2!1.0.0") must be True.
- Specifier("==1.0.0.*").contains("2!1.0") must be False.
- Specifier("==2!1.0.0.*").contains("1.0") must be False.

Preserve the existing public API and behavior of the other specifier operators, including compatible-release matching. Make the production fix and add suitable regression coverage. Work only in this checkout; do not retrieve upstream patches or history. Report the changes and tests you ran. The external evaluator restores its frozen upstream test suite, so weakening checkout tests cannot satisfy evaluation.
""",
    },
    {
        "id": "packaging-prerelease-bounds",
        "issue": 794,
        "acceptance": [
            "tests/test_specifiers.py::TestSpecifier::test_specifiers",
            "tests/test_specifiers.py::TestSpecifier::test_specifier_prereleases_detection",
            "tests/test_specifiers.py::TestSpecifier::test_specifier_filter",
        ],
        "prompt": """Fix implicit prerelease admission for strict version bounds in Packaging.

When the bound itself is a prerelease or development release, strict greater-than and less-than specifiers must participate in prerelease detection and filtering consistently with the public API contract. Examples:

- Specifier(">1.0.dev1").prereleases and Specifier("<1.0.dev1").prereleases must be True.
- Specifier(">3.0.0a7").contains("3.0.0a8") and Specifier("<3.0.0a8").contains("3.0.0a7") must be True.
- list(Specifier(">2.0a1").filter(["2.0a1", "3.0a2", "3.0"])) must equal ["3.0a2", "3.0"].

Excluding a prerelease with != must not implicitly enable prereleases. Preserve explicit prerelease overrides and ordinary non-prerelease comparisons. Make the production fix and add suitable regression coverage. Work only in this checkout; do not retrieve upstream patches or history. Report the changes and tests you ran. The external evaluator restores its frozen upstream test suite, so weakening checkout tests cannot satisfy evaluation.
""",
    },
]


def main():
    if (ROOT / "tasks.json").exists():
        raise FileExistsError("Task assets already frozen")
    record = []
    cache = {}
    for i, task in enumerate(TASKS):
        base, gold = SELECTION["bases"][i], SELECTION["gold_commits"][i]
        before = snapshot(base)
        after = snapshot(gold)
        cache[base] = before
        cache[gold] = after
        public = ROOT / "agent-fixtures" / task["id"]
        public.mkdir(parents=True, exist_ok=False)
        (public / "prompt.md").write_text(task["prompt"])
        base_archive = archive(public / "source.tar.gz", before)
        private = ROOT / "private" / f"task{i + 1}"
        gold_archive = archive(private / "gold-source.tar.gz", after)
        oracle = private / "evaluator"
        oracle.mkdir(exist_ok=False)
        test_files = {name: row for name, row in after.items() if name.startswith("tests/")}
        materialize(
            oracle / "tests", {name[len("tests/") :]: row for name, row in test_files.items()}
        )
        # Desired upstream test expectations are fixed even where the bug fix changes old assertions.
        row = {
            "task_id": task["id"],
            "ordinal": i + 1,
            "project": "packaging",
            "upstream_issue_or_pr": task["issue"],
            "base_commit": base,
            "gold_commit": gold,
            "prompt_path": str((public / "prompt.md").relative_to(ROOT)),
            "base_archive": base_archive,
            "gold_archive": gold_archive,
            "private_evaluator_root": str(oracle.relative_to(ROOT)),
            "acceptance_node_ids": task["acceptance"],
            "regression_test_path": "tests",
            "evaluator_test_source": "Unmodified complete gold upstream tests; intentional changed expectations supersede base expectations.",
            "evaluated_candidate_scope": "Regular files under src/packaging only, overlaid into canonical base; all tests/configuration restored from frozen evaluator inputs.",
            "base_source_files": {
                name: {k: v for k, v in d.items() if k != "raw"}
                for name, d in sorted(before.items())
            },
            "gold_source_files": {
                name: {k: v for k, v in d.items() if k != "raw"}
                for name, d in sorted(after.items())
            },
            "oracle_hashes": {
                str(p.relative_to(oracle)): digest(p.read_bytes())
                for p in sorted(oracle.rglob("*"))
                if p.is_file()
            },
        }
        write(private / "source-bindings.json", row)
        record.append(row)
    first, second = SELECTION["bases"]
    changed = sorted(
        name
        for name in cache[first].keys() | cache[second].keys()
        if name not in cache[first]
        or name not in cache[second]
        or cache[first][name]["sha256"] != cache[second][name]["sha256"]
    )
    write(
        ROOT / "tasks.json",
        {
            "schema_version": 1,
            "status": "assets_frozen_before_task_model_runs",
            "task_outcome_heldout_only": True,
            "source_exposure": SELECTION["source_exposure"],
            "tasks": record,
            "sequence": [
                {
                    "stage": 1,
                    "task_id": TASKS[0]["id"],
                    "canonical_source": record[0]["base_archive"]["path"],
                    "mode": "local_cold",
                },
                {
                    "stage": 2,
                    "task_id": TASKS[0]["id"],
                    "canonical_source": record[0]["base_archive"]["path"],
                    "mode": "repeat",
                },
                {
                    "stage": 3,
                    "task_id": TASKS[1]["id"],
                    "canonical_source": record[1]["base_archive"]["path"],
                    "mode": "after_canonical_upstream_changes",
                },
                {
                    "stage": 4,
                    "task_id": TASKS[1]["id"],
                    "canonical_source": record[1]["base_archive"]["path"],
                    "mode": "repeat",
                },
            ],
            "canonical_transition": {
                "from": first,
                "to": second,
                "changed_file_count": len(changed),
                "private_changed_path_inventory": "private/canonical-transition.json",
            },
            "memory_origin_seed": "memory-origin/seed-spec.json",
            "memory_origin_freeze": "origin-memory-freeze.json",
            "model_calls": 0,
            "repetitions": 3,
            "arms": ["plain", "static_memory", "cami_memory"],
            "independent_model_measurements": 0,
        },
    )
    write(
        ROOT / "private/canonical-transition.json",
        {"from": first, "to": second, "changed_paths": changed},
    )
    write(ROOT / "private/task-source-read-commands.json", COMMANDS)
    print(
        json.dumps(
            {
                "task_assets": 2,
                "agent_archives": 2,
                "private_gold_archives": 2,
                "prompt_files": 2,
                "canonical_stages": 4,
                "source_reads_local_only": True,
                "model_calls": 0,
            }
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, required=True)
    args = parser.parse_args()
    CORPUS = args.corpus.resolve()
    main()
