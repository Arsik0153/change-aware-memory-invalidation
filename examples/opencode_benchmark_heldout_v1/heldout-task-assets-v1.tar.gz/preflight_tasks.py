"""Only base/gold evaluator preflight; no task models or adaptive task selection."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    tasks = json.loads((ROOT / "tasks.json").read_bytes())
    task_sha = sha(ROOT / "tasks.json")
    records = []
    for task in tasks["tasks"]:
        for state in ["base", "gold"]:
            entry = task[state + "_archive"]
            archive = ROOT / entry["path"]
            if sha(archive) != entry["sha256"]:
                raise ValueError("Source archive hash mismatch")
            work = out / "fixtures" / (task["task_id"] + "-" + state)
            work.mkdir(parents=True)
            with tarfile.open(archive, "r:gz") as tar:
                tar.extractall(work, filter="data")
            dest = out / (task["task_id"] + "-" + state)
            argv = [
                "unshare",
                "--net",
                sys.executable,
                str(ROOT / "evaluate_task.py"),
                "--task",
                task["task_id"],
                "--workspace",
                str(work),
                "--out",
                str(dest),
                "--python",
                str(args.python.absolute()),
                "--tasks-sha256",
                task_sha,
                "--checks",
                "acceptance" if state == "base" else "all",
            ]
            result = subprocess.run(
                argv,
                capture_output=True,
                timeout=700,
                env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
            )
            (out / (task["task_id"] + "-" + state + "-driver.log")).write_bytes(
                result.stdout + result.stderr
            )
            report = (
                json.loads((dest / "report.json").read_bytes())
                if (dest / "report.json").exists()
                else {"status": "infrastructure_failure", "results": []}
            )
            expected = 1 if state == "base" else 0
            assertion_failures = 0
            for check in report["results"]:
                text = (dest / check["log"]).read_text(errors="replace")
                assertion_failures += sum(int(n) for n in re.findall(r"(\d+) failed", text[-1600:]))
            ok = result.returncode == expected and (state == "gold" or assertion_failures > 0)
            records.append(
                {
                    "task_id": task["task_id"],
                    "state": state,
                    "argv": argv,
                    "exit_code": result.returncode,
                    "expected_exit_code": expected,
                    "matches_expected": ok,
                    "assertion_failure_count": assertion_failures,
                    "evaluation_report": str((dest / "report.json").relative_to(out)),
                    "evaluation_report_sha256": sha(dest / "report.json")
                    if (dest / "report.json").exists()
                    else None,
                    "checks": report["results"],
                }
            )
    summary = {
        "status": "pass"
        if all(x["matches_expected"] for x in records)
        else "failed_preflight_no_substitute",
        "model_calls": 0,
        "task_count": 2,
        "base_must_fail": 2,
        "gold_must_pass": 2,
        "network_isolation": "actual Linux unshare --net",
        "task_manifest_sha256": task_sha,
        "evaluator_sha256": sha(ROOT / "evaluate_task.py"),
        "python": str(args.python.absolute()),
        "results": records,
    }
    (out / "report.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "status": summary["status"],
                "tasks": 2,
                "cases": len(records),
                "expected_matched": sum(x["matches_expected"] for x in records),
                "model_calls": 0,
            }
        )
    )
    return 0 if summary["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
