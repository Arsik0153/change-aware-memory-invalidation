Fix implicit prerelease admission for strict version bounds in Packaging.

When the bound itself is a prerelease or development release, strict greater-than and less-than specifiers must participate in prerelease detection and filtering consistently with the public API contract. Examples:

- Specifier(">1.0.dev1").prereleases and Specifier("<1.0.dev1").prereleases must be True.
- Specifier(">3.0.0a7").contains("3.0.0a8") and Specifier("<3.0.0a8").contains("3.0.0a7") must be True.
- list(Specifier(">2.0a1").filter(["2.0a1", "3.0a2", "3.0"])) must equal ["3.0a2", "3.0"].

Excluding a prerelease with != must not implicitly enable prereleases. Preserve explicit prerelease overrides and ordinary non-prerelease comparisons. Make the production fix and add suitable regression coverage. Work only in this checkout; do not retrieve upstream patches or history. Report the changes and tests you ran. The external evaluator restores its frozen upstream test suite, so weakening checkout tests cannot satisfy evaluation.
