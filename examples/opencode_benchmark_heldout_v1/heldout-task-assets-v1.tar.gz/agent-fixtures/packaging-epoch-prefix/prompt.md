Fix version-prefix matching with epochs in Packaging.

Wildcard equality specifiers must compare release components with zero padding without losing the epoch distinction. Reproduce through the public API:

- Specifier("==2!1.0.0.0.*").contains("2!1.0.0") must be True.
- Specifier("==1.0.0.*").contains("2!1.0") must be False.
- Specifier("==2!1.0.0.*").contains("1.0") must be False.

Preserve the existing public API and behavior of the other specifier operators, including compatible-release matching. Make the production fix and add suitable regression coverage. Work only in this checkout; do not retrieve upstream patches or history. Report the changes and tests you ran. The external evaluator restores its frozen upstream test suite, so weakening checkout tests cannot satisfy evaluation.
