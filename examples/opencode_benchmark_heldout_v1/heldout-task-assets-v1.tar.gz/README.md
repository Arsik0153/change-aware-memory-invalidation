# Frozen task/outcome-held-out Packaging task assets

This package prepares the two upstream fixes selected in the study draft before any task-model measurements. Packaging source was previously used for structural research. The held-out claim concerns these task instances and task-agent outcomes; it does not claim an unseen project, unknown training exposure or model-error independence. No task-agent/provider API calls were made by these preparation or preflight scripts.

Two tasks define four canonical stages: first task cold and repeat on the first base, then second task and repeat on the second base after canonical upstream changes. Each stage resets source to its frozen base archive. Model-produced patches must never become subsequent stage inputs. Three repetitions and three arms belong to the outer study protocol; this package does not run them or tune CAMI, its adapter or memory selection.

## Roles and leakage boundary

- `agent-fixtures/` contains only the two base-source archives and their frozen task prompts. Materialize only the selected task's archive into the agent checkout and pass that task's prompt. Do not mount the complete preparation directory into the agent runtime.
- `memory-origin/seed-spec.json` is the identical origin-source note catalog for the two memory arms. It has 75 notes from all 14 origin modules under the fixed source root. All75 note keys are unique. The copied generic generator is byte-identical to the corrected development generator. It ran before future-fix source inspection in this preparation; notes, identities and selection were not changed after that inspection. Plain receives no memory catalog.
- `private/` contains gold source archives, complete frozen evaluator tests, source bindings and acquisition provenance. Keep it outside all task-agent mounts and tool access. `tasks.json` and evaluator scripts are controller-side assets, not agent checkout files.
- `environment/requirements.lock` pins all six installed distributions. `environment/identity.json` records CPython3.12.3, binary/metadata hashes and dependency acquisition. The initial offline install missed pretend; the separately recorded authorized dependency install completed. No project Git fetch occurred.

Base/gold archives contain canonical regular source files only, with no `.git` object store, refs or history. Their sorted USTAR/gzip serialization uses zero timestamps and owner IDs. Normal tracked source configuration such as `.gitignore` and `.github` remains source content. Active package paths are relative to this directory. The source-acquisition script accepts an explicit equivalent local corpus path via `--corpus`; no Git network is used.

Preparation timing and preflight are infrastructure evidence, not experimental measurements. Future sequence timing must still include common source extraction and each arm's actual memory construction, capture, durability, maintenance, retrieval and cleanup as specified in the outer protocol; these costs are not prepaid by this package.

## Evaluator contract

`evaluate_task.py` starts from the frozen base archive, overlays only candidate regular files under `src/packaging`, and restores the complete fixed gold upstream tests. Agent tests, root hooks and pytest configuration cannot replace the evaluator. Gold expectations intentionally supersede old base assertions changed by an upstream fix. No source byte-equality requirement is imposed on a candidate solution.

Both acceptance and full regression checks must pass. Acceptance uses unchanged upstream gold test methods covering the registered behaviour; regressions use the entire frozen upstream test tree for that task. Cases overlap and are not independent task samples. The caller supplies isolated process/network execution. Actual preflight ran inside Linux `unshare --net`; a Docker evaluator may provide equivalent external network isolation.

```sh
python evaluate_task.py --task TASK_ID --workspace CANDIDATE_CHECKOUT \
  --python /absolute/path/to/pinned/venv/bin/python \
  --tasks-sha256 TASKS_JSON_SHA256 --out NEW_RESULT_DIRECTORY
```

`--checks acceptance` or `--checks regression` is available for preflight; candidate quality uses the default `all`. Exit0 means all requested checks passed; exit1 records a test failure. New output paths are mandatory. Inspect the JSON and logs to distinguish assertion failures from infrastructure errors; a failed base preflight must contain actual assertion failures.

```sh
python preflight_tasks.py --python /absolute/path/to/pinned/venv/bin/python \
  --out NEW_PREFLIGHT_DIRECTORY
```

No task substitution is implemented. An unusable task produces failed preflight evidence and stops the task set.

## Frozen preflight evidence

`preflight-v2/report.json` records both base acceptance failures, both gold acceptance passes and both full gold regression passes, with no skipped task or replacement. First-task gold acceptance has159passes and its full regression suite26828passes; second-task gold acceptance has185passes and its full regression suite26857passes. Base acceptance has respectively1 and4 assertion failures. All4 base/gold state checks matched their fixed expectations.

`test-restoration-control/report.json` confirms that replacing candidate tests with an always-pass file and injecting a root pytest hook still leaves both unfixed base packages rejected by the frozen evaluator. The control does not establish safety against arbitrary malicious production code.

The initial `preflight-v1` did not run pytest tests: resolving the virtualenv interpreter symlink selected system Python without pytest. It is preserved with its failed freeze. V2 corrected interpreter-path handling while retaining the same task selection, source archives, prompts, tests and task manifest. Final asset-freeze v3 additionally parameterizes the acquisition script's local corpus path and binds environment/reproducibility documentation; evaluator decisions are unchanged from successful v2 preflight. Every version is prepared before task-model measurements, with no outcome-based task replacement.
