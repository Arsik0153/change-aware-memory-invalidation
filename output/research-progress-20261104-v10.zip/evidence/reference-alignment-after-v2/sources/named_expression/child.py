def f(x):
    return x
(f := 1)
