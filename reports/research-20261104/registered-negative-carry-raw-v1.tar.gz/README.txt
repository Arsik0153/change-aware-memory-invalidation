run/ preserves the complete authored result, local Git databases and fixture symlinks.
implementation/ preserves the sealed runtime, protocol and seal. No real corpus is included.
Extract into a NEW directory. Audit the published file mirror using --git-fixtures NEW/run/git-fixtures.
Historical source verification also uses this research repository's recorded Git commit.
The original manifest excludes .git internals and dangling symlinks; this raw archive preserves them too.
