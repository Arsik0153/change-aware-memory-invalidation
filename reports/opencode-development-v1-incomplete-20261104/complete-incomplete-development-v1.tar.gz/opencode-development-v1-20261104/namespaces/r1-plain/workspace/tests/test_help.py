import pytest

import click


@pytest.fixture(params=["automatic", "decorator", "class"])
def help_command(request):
    def make_command(names=()):
        cmd = click.Command(
            "cli",
            callback=lambda required: click.echo(required),
            params=[click.Option(["--required"], required=True)],
            help="Command help.",
        )

        if request.param == "automatic":
            if names:
                cmd.context_settings["help_option_names"] = list(names)
        elif request.param == "decorator":
            click.help_option(*names)(cmd)
        else:
            cmd.params.append(click.HelpOption(names))

        return cmd

    return make_command


def test_help_defaults(runner, help_command):
    cmd = help_command()
    ctx = click.Context(cmd, info_name="cli")
    options = [p for p in cmd.get_params(ctx) if isinstance(p, click.HelpOption)]
    assert len(options) == 1
    option = options[0]
    assert isinstance(option, click.Option)
    assert option.opts == ["--help"]
    assert option.is_flag
    assert option.is_eager
    assert not option.expose_value
    assert option.help == "Show this message and exit."

    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert result.output == ctx.get_help() + "\n"

    result = runner.invoke(cmd, ["--required", "ran"])
    assert result.exit_code == 0
    assert result.output == "ran\n"


@pytest.mark.parametrize("name", ["-h", "--assist"])
def test_custom_names(runner, help_command, name):
    cmd = help_command(("-h", "--assist"))
    ctx = click.Context(cmd, info_name="cli", **cmd.context_settings)
    result = runner.invoke(cmd, [name])
    assert result.exit_code == 0
    assert result.output == ctx.get_help() + "\n"
    assert "-h, --assist" in result.output


@pytest.mark.parametrize("args", [[], ["--help"]])
def test_resilient_parsing(runner, help_command, args):
    cmd = help_command()
    with runner.isolation() as streams:
        with cmd.make_context("cli", args, resilient_parsing=True) as ctx:
            assert "help" not in ctx.params
        assert streams[0].getvalue() == b""


@pytest.mark.parametrize("color", [False, True])
def test_help_color(runner, help_command, color):
    cmd = help_command()
    cmd.help = click.style("Command help.", fg="green")
    cmd.context_settings["color"] = color
    result = runner.invoke(cmd, ["--help"], color=True)
    assert result.exit_code == 0
    assert ("\x1b[32m" in result.output) is color
    assert "Command help." in result.output


@pytest.mark.parametrize(
    "attrs",
    [{"add_help_option": False}, {"context_settings": {"help_option_names": []}}],
)
def test_automatic_help_disabled(runner, attrs):
    cmd = click.Command("cli", **attrs)
    assert cmd.get_help_option(click.Context(cmd, **cmd.context_settings)) is None
    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 2
    assert "No such option: --help" in result.output


def test_automatic_help_name_conflicts(runner):
    @click.command(context_settings={"help_option_names": ["--help", "--assist"]})
    @click.option("--help/--no-help")
    def cmd(help):
        click.echo(help)

    option = cmd.get_help_option(click.Context(cmd, **cmd.context_settings))
    assert isinstance(option, click.HelpOption)
    assert option.opts == ["--assist"]
    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert result.output == "True\n"
    result = runner.invoke(cmd, ["--assist"])
    assert result.exit_code == 0
    assert "Show this message and exit." in result.output

    cmd.context_settings["help_option_names"] = ["--help", "--no-help"]
    assert cmd.get_help_option(click.Context(cmd, **cmd.context_settings)) is None


class CustomOption(click.Option):
    pass


class CustomHelpOption(click.HelpOption):
    pass


@pytest.fixture(params=[click.HelpOption, CustomOption, CustomHelpOption, None, "direct"])
def make_help_option(request):
    def make_option(**attrs):
        if request.param == "direct":
            return click.HelpOption(**attrs)

        cmd = click.Command("cli")
        click.help_option(cls=request.param, **attrs)(cmd)
        option = cmd.params[0]
        assert type(option) is (request.param or click.HelpOption)
        return option

    return make_option


def test_custom_cls_names(runner):
    @click.command(add_help_option=False)
    @click.help_option("-h", "--assist", cls=CustomOption)
    def cmd():
        pass

    assert type(cmd.params[0]) is CustomOption
    assert cmd.params[0].opts == ["-h", "--assist"]
    for name in ("-h", "--assist"):
        result = runner.invoke(cmd, [name])
        assert result.exit_code == 0
        assert "-h, --assist  Show this message and exit." in result.output


def test_custom_cls_defaults(runner, make_help_option):
    cmd = click.Command("cli", params=[make_help_option()], add_help_option=False)
    option = cmd.params[0]
    assert option.opts == ["--help"]
    assert option.is_flag
    assert option.is_eager
    assert not option.expose_value
    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert result.output.endswith("--help  Show this message and exit.\n")


def test_keyword_overrides(runner, make_help_option):
    seen = []

    def callback(ctx, param, value):
        seen.append((param, value))
        return value.upper()

    option = make_help_option(
        is_flag=False,
        is_eager=False,
        expose_value=True,
        callback=callback,
        help="Custom help.",
        default="default",
        type=str,
        hidden=True,
    )
    assert not option.is_flag
    assert not option.is_eager
    assert option.expose_value
    assert option.callback is callback
    assert option.help == "Custom help."
    assert option.hidden

    cmd = click.Command(
        "cli",
        params=[option],
        callback=lambda help: click.echo(help),
        add_help_option=False,
    )
    result = runner.invoke(cmd, ["--help", "custom"])
    assert result.exit_code == 0
    assert result.output == "CUSTOM\n"
    assert seen == [(option, "custom")]

    result = runner.invoke(cmd, [])
    assert result.exit_code == 0
    assert result.output == "DEFAULT\n"


def test_callback_none(runner, make_help_option):
    option = make_help_option(callback=None)
    assert option.callback is None
    cmd = click.Command(
        "cli",
        params=[option],
        callback=lambda: click.echo("ran"),
        add_help_option=False,
    )
    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert result.output == "ran\n"
