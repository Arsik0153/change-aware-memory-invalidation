raise RuntimeError("must never import candidate runner")
