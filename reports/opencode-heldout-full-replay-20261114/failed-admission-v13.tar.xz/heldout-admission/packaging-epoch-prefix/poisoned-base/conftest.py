raise RuntimeError("must never load candidate hook")
