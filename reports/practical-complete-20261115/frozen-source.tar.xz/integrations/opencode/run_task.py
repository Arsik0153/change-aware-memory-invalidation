"""Normal OpenCode task entrypoint with automatic durable input/usage capture."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

try:
    from . import task_session
except ImportError:
    import task_session


def service_url():
    candidates = set()
    for path in Path("/proc").iterdir():
        try:
            if not path.name.isdigit() or (path / "comm").read_text().strip() != "opencode":
                continue
            if b"--service" not in (path / "cmdline").read_bytes().split(b"\0"):
                continue
            sockets = {str(p.readlink()) for p in (path / "fd").iterdir() if p.is_symlink()}
            for line in Path("/proc/net/tcp").read_text().splitlines()[1:]:
                fields = line.split()
                if (
                    fields[3] == "0A"
                    and fields[1].startswith("0100007F:")
                    and f"socket:[{fields[9]}]" in sockets
                ):
                    candidates.add("http://127.0.0.1:" + str(int(fields[1].split(":")[1], 16)))
        except OSError:
            continue
    if len(candidates) != 1:
        raise ValueError("one local OpenCode service required")
    return candidates.pop()


def forward(binary, model, prompt):
    # The shared CLI's implicit location selected the wrong root in two real
    # admission attempts. Bind the session through the same explicit API as
    # the verified container harness, before admitting any prompt.
    import base64
    import time
    import urllib.request
    import urllib.parse

    password = json.loads((Path.home() / ".config/opencode/service.json").read_text())["password"]
    auth = base64.b64encode(("opencode:" + password).encode()).decode()
    url = service_url()

    def request(method, path, payload=None):
        body = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(
            url + path,
            data=body,
            method=method,
            headers={"Authorization": "Basic " + auth, "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.load(response)

    provider, identifier = model.split("/", 1)
    identifier, _, variant = identifier.partition("#")
    expected = {
        "providerID": provider,
        "id": identifier,
        **({"variant": variant} if variant else {}),
    }
    workspace = str(Path.cwd().resolve())
    created = request(
        "POST",
        "/api/session",
        {"location": {"directory": workspace}, "model": expected, "title": "CAMI captured task"},
    )["data"]
    if created["location"]["directory"] != workspace or created["model"] != expected:
        raise ValueError("OpenCode session binding differs from captured inputs")
    sid = created["id"]
    print(
        json.dumps(
            {"type": "session_bound", "session_id": sid, "workspace": workspace, "model": expected}
        ),
        flush=True,
    )
    seen, finished = set(), set()

    def observe():
        cursor = None
        while True:
            query = {"limit": "200", **({"cursor": cursor} if cursor else {"order": "asc"})}
            page = request("GET", f"/api/session/{sid}/message?" + urllib.parse.urlencode(query))
            for message in page["data"]:
                if message.get("type") != "assistant":
                    continue
                mid = message["id"]
                if mid not in seen:
                    print(json.dumps({"type": "request_started", "id": mid}), flush=True)
                    seen.add(mid)
                if mid in finished or not message.get("time", {}).get("completed"):
                    continue
                tokens = message.get("tokens", {})
                cache = tokens.get("cache", {})
                if not message.get("error"):
                    usage = {
                        "input": tokens.get("input"),
                        "output": tokens.get("output"),
                        "reasoning": tokens.get("reasoning"),
                        "cache_read": cache.get("read"),
                        "cache_write": cache.get("write"),
                    }
                    print(
                        json.dumps({"type": "request_finished", "id": mid, "usage": usage}),
                        flush=True,
                    )
                else:
                    print(json.dumps({"type": "provider_error", "id": mid}), flush=True)
                finished.add(mid)
            cursor = page.get("cursor", {}).get("next")
            if not cursor:
                break

    try:
        request("POST", f"/api/session/{sid}/prompt", {"text": prompt})
        deadline = time.monotonic() + 850
        while time.monotonic() < deadline:
            observe()
            session = request("GET", f"/api/session/{sid}")["data"]
            if session.get("outcome") in ["succeeded", "failed", "interrupted"] and session.get(
                "time", {}
            ).get("idle"):
                observe()
                if session["location"]["directory"] != workspace or session["model"] != expected:
                    raise ValueError("session identity changed")
                return 0 if session["outcome"] == "succeeded" else 1
            time.sleep(0.25)
        request("POST", f"/api/session/{sid}/interrupt", {})
        raise TimeoutError("task deadline")
    except BaseException:
        print(
            json.dumps(
                {"type": "request_started", "id": "unknown-after-failure-" + uuid.uuid4().hex}
            ),
            flush=True,
        )
        try:
            request("POST", f"/api/session/{sid}/interrupt", {})
        except Exception:
            pass
        raise


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["_forward"]:
        return forward(*argv[1:])
    parser = argparse.ArgumentParser(prog="cami task", description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    parser.add_argument("--task-file", type=Path, required=True)
    parser.add_argument(
        "--context-file",
        type=Path,
        required=True,
        help="External inputs/toolchain identity; must describe all meaningful external state",
    )
    parser.add_argument("--grade-json", required=True, help="Fixed test argv as JSON; no shell")
    parser.add_argument(
        "--journal-root",
        type=Path,
        default=Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state")) / "cami-tasks",
    )
    parser.add_argument("--model", default="openai/gpt-6.1-sol#high")
    parser.add_argument("--opencode-binary", default="opencode")
    args = parser.parse_args(argv)
    binary = shutil.which(args.opencode_binary)
    if binary is None:
        parser.error("OpenCode binary not found")
    workspace = args.workspace.resolve()
    root = subprocess.run(
        ["git", "-C", str(workspace), "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if root.returncode or Path(root.stdout.strip()).resolve() != workspace:
        parser.error(
            "workspace must be the Git repository root; OpenCode resolves its location from Git"
        )
    args.journal_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    directory = args.journal_root / uuid.uuid4().hex
    context = json.dumps(
        {
            "external": args.context_file.read_text(),
            "model": args.model,
            "binary_sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
            "grade": json.loads(args.grade_json),
        },
        sort_keys=True,
    )
    # An argv adapter preserves OpenCode's ordinary shared-service/config behavior.
    # It does not claim visibility into retries hidden by the CLI/provider.
    result = task_session.run(
        directory,
        args.workspace,
        args.task_file.read_text(),
        context,
        [
            sys.executable,
            str(Path(__file__).resolve()),
            "_forward",
            binary,
            args.model,
            args.task_file.read_text(),
        ],
        json.loads(args.grade_json),
        request_coverage=False,
    )
    print(json.dumps({"journal": str(directory), **result}, sort_keys=True))
    return 0 if result["quality"] == "pass" and result["execution"] == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
