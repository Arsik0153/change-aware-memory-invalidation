"""Read-only bounded SQLite storage accounting; never import project code."""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'runs/opencode-source-prefix-mcp-confirmation-20261106'
MANIFEST = ROOT / 'reports/opencode-source-prefix-mcp-confirmation-20261106/manifest.json'
DECODER = json.JSONDecoder()
QUERIES = []


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def distribution(values):
    values = sorted(values)
    return {'count': len(values), 'sum': sum(values), 'min': min(values, default=0),
            'median': values[len(values) // 2] if values else 0,
            'p95_nearest_rank': values[max(0, math.ceil(len(values) * .95) - 1)] if values else 0,
            'max': max(values, default=0)}


def members(raw):
    """Yield exact JSON value substrings for an object or array, no evaluation."""
    assert raw[0] in '{['
    pos = 1
    while pos < len(raw) and raw[pos] not in '}]':
        while raw[pos].isspace() or raw[pos] == ',':
            pos += 1
        if raw[0] == '{':
            key, pos = DECODER.raw_decode(raw, pos)
            while raw[pos].isspace():
                pos += 1
            assert raw[pos] == ':'
            pos += 1
            while raw[pos].isspace():
                pos += 1
        else:
            key = '[*]'
        start = pos
        _, pos = DECODER.raw_decode(raw, pos)
        yield key, raw[start:pos]
        while pos < len(raw) and raw[pos].isspace():
            pos += 1


def fields(raw, prefix, result, depth=0):
    for key, fragment in members(raw):
        path = prefix + (key if key == '[*]' else '.' + key)
        result[path].append(len(fragment.encode('utf-8')))
        if depth < 3 and fragment[:1] in ('{', '['):
            fields(fragment, path, result, depth + 1)


def query(db, sql):
    QUERIES.append(sql)
    return db.execute(sql)


def inventory(base):
    result = {}
    for path in sorted(base.rglob('*')):
        assert not path.is_symlink(), 'symlinks refused'
        if path.is_file():
            stat = path.stat()
            result[str(path.relative_to(base))] = {
                'sha256': sha(path), 'logical_bytes': stat.st_size,
                'allocated_bytes': stat.st_blocks * 512, 'inode': stat.st_ino,
                'device': stat.st_dev, 'links': stat.st_nlink}
    return result


def inspect(name, manifest):
    namespace = BASE / 'quiet-v1' / name
    memory = namespace / 'memory'
    before = inventory(memory)
    full_namespace_files = [path for path in namespace.rglob('*') if path.is_file()]
    dbpath, = memory.rglob('memory.sqlite3')
    family = sorted(dbpath.parent.glob('memory.sqlite3*'))
    assert family == [dbpath], 'live WAL/journal present: refuse original DB'
    for rel, metadata in before.items():
        key = str((memory / rel).relative_to(BASE))
        assert manifest['files'][key] == metadata['sha256'], ('publication pin mismatch', key)
    uri = dbpath.resolve().as_uri() + '?mode=ro&immutable=1'
    result = {'namespace': str(namespace.relative_to(ROOT)),
              'database': str(dbpath.relative_to(ROOT)), 'sqlite_uri': uri,
              'live_wal_or_journal': False, 'copied_database_family': False,
              'memory_inventory': before,
              'memory_directory_logical_bytes': sum(v['logical_bytes'] for v in before.values()),
              'memory_directory_allocated_bytes': sum(v['allocated_bytes'] for v in before.values()),
              'namespace_all_files_logical_bytes': sum(p.stat().st_size for p in full_namespace_files),
              'namespace_all_files_allocated_bytes': sum(p.stat().st_blocks * 512 for p in full_namespace_files),
              'namespace_all_files_count': len(full_namespace_files)}
    groups = defaultdict(lambda: {'files': 0, 'logical_bytes': 0, 'allocated_bytes': 0})
    for path, metadata in before.items():
        kind = ('sqlite' if path.endswith('memory.sqlite3') else 'source_objects'
                if '/source-objects/' in path else 'index_generations' if '/generations/' in path
                else 'prepared' if path.startswith('prepared/') else 'seed'
                if path.startswith('seed/') else 'other')
        groups[kind]['files'] += 1
        for key in ('logical_bytes', 'allocated_bytes'):
            groups[kind][key] += metadata[key]
    result['memory_directory_groups'] = dict(groups)
    with sqlite3.connect(uri, uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('PRAGMA cache_size=-2048')
        pragma = {key: query(db, 'PRAGMA ' + key).fetchone()[0] for key in (
            'page_size', 'page_count', 'freelist_count', 'journal_mode', 'user_version')}
        result['sqlite'] = pragma
        assert pragma['page_count'] * pragma['page_size'] == dbpath.stat().st_size
        statrows = query(db, 'SELECT name,count(*) AS pages,sum(pgsize) AS bytes,'
                             'sum(payload) AS payload,sum(unused) AS unused '
                             'FROM dbstat GROUP BY name ORDER BY sum(pgsize) DESC').fetchall()
        result['dbstat'] = [dict(zip(('name', 'pages', 'bytes', 'payload_bytes', 'unused_bytes'), row))
                            for row in statrows]
        assert sum(row[2] for row in statrows) == dbpath.stat().st_size
        result['sqlite_page_accounting'] = {
            'allocated_object_bytes': sum(row[2] for row in statrows),
            'payload_bytes': sum(row[3] for row in statrows),
            'unused_bytes': sum(row[4] for row in statrows),
            'headers_pointers_and_other_bytes': sum(row[2] - row[3] - row[4] for row in statrows),
            'freelist_bytes': pragma['freelist_count'] * pragma['page_size']}
        schema = query(db, 'SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name').fetchall()
        result['schema'] = [dict(zip(('type', 'name', 'table', 'sql'), row)) for row in schema]
        tables = [row[1] for row in schema if row[0] == 'table']
        assert all(re.fullmatch('[a-z_]+', table) for table in tables)
        result['table_rows'] = {}
        result['serialized_columns'] = {}
        measured_fields = defaultdict(list)
        state_digests = {}
        scope_stats = Counter()
        edge_set_counts = Counter()
        scope_counts = []
        for table in tables:
            result['table_rows'][table] = query(db, f'SELECT count(*) FROM "{table}"').fetchone()[0]
            columns = query(db, f'PRAGMA table_info("{table}")').fetchall()
            if 'value' not in {column[1] for column in columns}:
                continue
            sizes, duplicate_hashes = [], Counter()
            selection = 'generation_id,record_id,value' if table == 'record_state' else 'value'
            for row in query(db, f'SELECT {selection} FROM "{table}"'):
                raw = row[-1]
                assert isinstance(raw, str)
                size = len(raw.encode('utf-8'))
                sizes.append(size)
                duplicate_hashes[hashlib.sha256(raw.encode('utf-8')).hexdigest()] += 1
                fields(raw, table, measured_fields)
                if table == 'record_state':
                    state_digests[(row[0], row[1])] = (hashlib.sha256(raw.encode()).hexdigest(), size)
                    value = json.loads(raw)
                    scopes = value['invalidation_scopes']
                    scope_counts.append(len(scopes))
                    edges = [item for item in scopes if item.startswith('edge:')]
                    edge_set_counts[hashlib.sha256(canonical(edges).encode()).hexdigest()] += 1
                    scope_stats['edge_items'] += len(edges)
                    scope_stats['nonedge_items'] += len(scopes) - len(edges)
                    scope_stats['edge_list_serialized_bytes'] += len(canonical(edges).encode())
                    scope_stats['whole_scopes_serialized_bytes'] += len(canonical(scopes).encode())
            result['serialized_columns'][table + '.value'] = {
                **distribution(sizes), 'distinct_full_value_hashes': len(duplicate_hashes)}
        duplicate_states = 0
        for raw, in query(db, 'SELECT value FROM memory_generation'):
            value = json.loads(raw)
            states_fragment = next(fragment for key, fragment in members(raw) if key == 'states')
            for _, state_raw in members(states_fragment):
                state = json.loads(state_raw)
                key = value['memory_generation_id'], state['record']['memory_id']
                assert state_digests[key] == (hashlib.sha256(state_raw.encode()).hexdigest(),
                                              len(state_raw.encode()))
                duplicate_states += 1
        assert duplicate_states == len(state_digests)
        result['exact_duplicate_state_representation'] = {
            'matched_state_rows': duplicate_states,
            'same_state_json_bytes_in_each_representation': sum(size for _, size in state_digests.values()),
            'same_invalidation_scope_json_bytes_in_each_representation': scope_stats['whole_scopes_serialized_bytes'],
            'scope_item_count_distribution': distribution(scope_counts),
            'edge_list_set_count': len(edge_set_counts),
            'edge_list_set_repetition_counts': sorted(edge_set_counts.values()),
            **scope_stats}
        result['serialized_field_distributions'] = {
            field: distribution(values) for field, values in sorted(measured_fields.items(),
                key=lambda pair: sum(pair[1]), reverse=True)}
    assert sorted(dbpath.parent.glob('memory.sqlite3*')) == [dbpath]
    assert inventory(memory) == before, 'original inventory changed'
    result['original_inventory_unchanged'] = True
    return result


def main():
    manifest = json.loads(MANIFEST.read_bytes())
    freeze_path = BASE / 'source-freeze.json'
    freeze = json.loads(freeze_path.read_bytes())
    assert sha(freeze_path) == manifest['files']['source-freeze.json']
    pins = {}
    for candidate in (2, 4):
        source = ROOT / freeze[f'candidate{candidate}_source_path']
        for suffix in ('product/memory/store.py', 'product/memory/validation.py',
                       'product/memory/models.py', 'product/memory/adapters.py',
                       'product/service.py', 'product/store.py'):
            path = source / 'cami' / suffix
            key = str(path.relative_to(ROOT))
            observed = sha(path)
            assert observed == freeze[f'candidate{candidate}_files']['cami/' + suffix]
            assert observed == manifest['external_readonly_dependencies'][key]
            pins[key] = observed
    results = [inspect(name, manifest) for name in ('b1-candidate2', 'b1-candidate4')]
    report = {'status': 'passed', 'scope': 'One first-block final quiet namespace per C2/C4; descriptive storage accounting, no performance benchmark.',
              'sqlite_version': sqlite3.sqlite_version, 'namespaces': results,
              'source_sha256': pins, 'publication_manifest_sha256': sha(MANIFEST),
              'source_freeze_sha256': sha(freeze_path),
              'field_measurement': 'Exact original JSON value substring UTF8 bytes; parent and nested field totals overlap and must not be summed.',
              'allocation_scope': 'Regular file st_size and st_blocks*512; excludes directory inode blocks, filesystem dedup/reflink accounting, and namespace workspace bytes from memory group totals.',
              'models': 0, 'docker_runs': 0, 'heldout_reads': 0, 'network_calls': 0,
              'project_code_executed': False, 'original_writes': False, 'database_copies': 0,
              'limits': ['Two final snapshots only; no growth or scaling estimate.',
                         'No compression, VACUUM, checkpoint, migration or benchmark.',
                         'Full suite overlap means elapsed execution times cannot support performance claims.',
                         'Serialized JSON was parsed only as untrusted data; no project code imported.']}
    save('storage-report.json', report)
    save('queries.json', list(dict.fromkeys(QUERIES)))
    print(json.dumps({'status': report['status'], 'summaries': [{
        'namespace': item['namespace'], 'sqlite': item['sqlite'],
        'memory_directory_logical_bytes': item['memory_directory_logical_bytes'],
        'page_accounting': item['sqlite_page_accounting'],
        'duplicate_states': item['exact_duplicate_state_representation']}
        for item in results]}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('failure.json', {'error': type(error).__name__ + ': ' + str(error)})
        raise
