"""Replay untouched legacy observer/stdio behavior against the committed baseline."""
from pathlib import Path
import json
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "scripts/opencode_benchmark/controller"
BASE = "f355b65613c7a220986cfc05c05a4c719c7b0c74"
sys.path.insert(0, str(HERE))
import memory_format_evidence as observer
import literal_stdio_worker as worker
from test_format_observation import fixture
from test_literal_stdio import StdioChecks


def old_module(filename):
    source = subprocess.run(["git", "show", BASE + ":scripts/opencode_benchmark/controller/" + filename],
                            cwd=ROOT, capture_output=True, text=True, check=True).stdout
    module = types.ModuleType("baseline_" + filename[:-3])
    module.__file__ = str(HERE / filename)
    exec(compile(source, filename, "exec"), module.__dict__)
    return module


def main():
    old_observer, old_worker = old_module("memory_format_evidence.py"), old_module("literal_stdio_worker.py")
    counts = {"observer_reports": 0, "stdio_reports": 0}
    for arm in ("static", "cami"):
        for mode in ("full", "compact"):
            for error in (False, True):
                messages, events = fixture(arm, mode, error)
                for actual_events in (events, []):
                    current = observer.inspect_format(messages, actual_events, arm, mode)
                    prior = old_observer.inspect_format(messages, actual_events, arm, mode)
                    assert worker.canonical(current) == worker.canonical(prior), (arm, mode, error)
                    counts["observer_reports"] += 1
            args = StdioChecks().fixture(arm, mode)
            assert worker.canonical(worker.validate_response(*args)) == worker.canonical(old_worker.validate_response(*args))
            counts["stdio_reports"] += 1
    for arm in ("plain", "static", "cami"):
        for mode in ("full", "compact"):
            assert worker.canonical(observer.inspect_format([], [], arm, mode)) == worker.canonical(old_observer.inspect_format([], [], arm, mode))
            counts["observer_reports"] += 1
    report = {"status": "passed", "baseline_commit": BASE, **counts, "model_calls": 0,
              "docker_calls": 0, "network_calls": 0}
    (Path(__file__).parent / "legacy-equivalence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
