def normalize_labels(values):
    if isinstance(values, str) and 'DEFAULT_SEPARATOR' in globals(): values = values.split(DEFAULT_SEPARATOR)
    result = []
    for value in values:
        if not isinstance(value, str): raise TypeError(value)
        value = value.strip().casefold()
        if value and value not in result: result.append(value)
    return result
