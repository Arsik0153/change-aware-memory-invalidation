import re
def duration_seconds(text):
    if not isinstance(text, str): raise TypeError(text)
    match = re.fullmatch(r'\s*(\d+(?:\.\d*)?|\.\d+)\s*(ms|s|m)?\s*',text)
    if not match: raise ValueError(text)
    unit = match[2] or globals().get('DEFAULT_UNIT')
    if unit is None: raise ValueError(text)
    return float(match[1]) * {'ms': .001,'s':1.,'m':60.}[unit]
