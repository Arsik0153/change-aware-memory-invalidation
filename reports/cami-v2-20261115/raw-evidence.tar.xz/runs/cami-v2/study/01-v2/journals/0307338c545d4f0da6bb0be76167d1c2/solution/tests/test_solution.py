from solution import normalize_labels

import pytest


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_labels_preserve_first_seen_order():
    assert normalize_labels([" B ", "a", "b", " C ", "A"]) == ["b", "a", "c"]


def test_labels_casefold_unicode():
    assert normalize_labels([" Straße ", "STRASSE"]) == ["strasse"]


def test_labels_omit_whitespace_and_empty_strings():
    assert normalize_labels(["", " \t\n", "\u2003"]) == []


def test_labels_accept_iterators():
    assert normalize_labels(iter([" A ", "a", "B"])) == ["a", "b"]
    assert normalize_labels(iter([])) == []


@pytest.mark.parametrize("value", [None, 1, False, b"label", [], {}])
def test_labels_reject_non_strings(value):
    with pytest.raises(TypeError):
        normalize_labels(["valid", value])
