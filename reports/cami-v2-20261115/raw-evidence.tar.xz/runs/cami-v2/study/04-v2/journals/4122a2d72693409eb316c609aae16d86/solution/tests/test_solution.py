import pytest

from solution import duration_seconds


def test_duration():
    assert duration_seconds("2m") == 120.0


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("250ms", 0.25),
        ("1.5s", 1.5),
        ("1.25m", 75.0),
        (" \t2.5 \nms\r\n", 0.0025),
        (".5 s", 0.5),
        ("1.s", 1.0),
        ("0m", 0.0),
        ("00.50s", 0.5),
    ],
)
def test_duration_valid(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "2", "ms", "2h", "2MS", "-1s", "-0s", "+1s",
        "NaNs", "infs", "Infinitym", "1e3s", "1_000s", ".s", "1..2s",
        "1 2s", "1 s extra", "2m s", "0x10s", "١s",
        "9" * 400 + "s", "9" * 308 + "m",
    ],
)
def test_duration_invalid(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("value", [None, 2, 1.5, True, b"2s", [], {}])
def test_duration_non_string(value):
    with pytest.raises(TypeError):
        duration_seconds(value)
