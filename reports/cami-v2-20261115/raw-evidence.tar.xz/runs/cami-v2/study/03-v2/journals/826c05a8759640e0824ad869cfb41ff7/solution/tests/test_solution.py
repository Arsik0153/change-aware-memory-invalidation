from solution import normalize_labels

import pytest


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_labels_casefold_and_preserve_order():
    assert normalize_labels([" B ", "Straße", "STRASSE", "b", "A"]) == [
        "b", "strasse", "a"
    ]


def test_labels_accept_iterables_and_omit_whitespace():
    values = (value for value in ["\t\n", " A ", "", "a", " B "])
    assert normalize_labels(values) == ["a", "b"]
    assert normalize_labels([]) == []


@pytest.mark.parametrize("value", [None, 0, False, b"a", [], {}])
def test_labels_reject_non_strings(value):
    with pytest.raises(TypeError):
        normalize_labels(["a", value])
