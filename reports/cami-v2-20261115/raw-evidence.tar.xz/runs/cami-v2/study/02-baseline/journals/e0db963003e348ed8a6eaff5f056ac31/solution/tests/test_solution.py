from solution import duration_seconds

import pytest


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("2m", 120.0),
        ("1500ms", 1.5),
        ("1.25s", 1.25),
        (" \t2.5 \n m\r\n", 150.0),
        ("0ms", 0.0),
        (".5s", 0.5),
        ("1.s", 1.0),
    ],
)
def test_duration(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "1", "s", "1h", "1MS", "-1s", "-0s", "+1s",
        "NaNs", "infs", "Infinitym", "1e3s", ".s", "1..2s", "1 2s",
        "1_000s", "1,5s", "1s extra", "1s\n2s", "9" * 400 + "m",
    ],
)
def test_invalid_duration(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("value", [None, 1, 1.5, True, b"1s", [], {}])
def test_non_string_duration(value):
    with pytest.raises(TypeError):
        duration_seconds(value)
