def duration_seconds(text):
    return float(text)
