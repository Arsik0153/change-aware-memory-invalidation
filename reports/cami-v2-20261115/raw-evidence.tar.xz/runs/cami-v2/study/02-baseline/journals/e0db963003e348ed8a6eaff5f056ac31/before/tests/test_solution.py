from solution import duration_seconds
def test_duration():
    assert duration_seconds("2m") == 120.0
