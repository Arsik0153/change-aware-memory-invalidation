import pytest

from solution import normalize_labels


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_unicode_casefold_and_first_seen_order():
    assert normalize_labels([" B ", "Straße", "STRASSE", "a", "b"]) == [
        "b", "strasse", "a"
    ]


def test_generator_and_whitespace_only_labels():
    values = (value for value in ["", " \t\n", " A ", "a", " B "])
    assert normalize_labels(values) == ["a", "b"]


def test_empty_iterable():
    assert normalize_labels([]) == []


@pytest.mark.parametrize("value", [None, 0, False, b"label", [], {}])
def test_non_string_items_raise_type_error(value):
    with pytest.raises(TypeError):
        normalize_labels(["valid", value])
