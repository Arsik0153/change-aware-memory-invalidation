import sys
sys.path.insert(0, 'src')
import solution as s
if hasattr(s, 'normalize_labels'):
    for values, expected in [([], []), ([" A ","a","", "B"], ["a","b"]), (["Straße","STRASSE"], ["strasse"]), ((x for x in [" b ","A","b"]), ["b","a"])]:
        assert s.normalize_labels(values) == expected
    for value in [None, 7, object()]:
        try: s.normalize_labels(["ok", value])
        except TypeError: pass
        else: raise AssertionError('non-string item')
    if sys.argv[1] == 'changed': assert s.normalize_labels(' A ,a, B,,') == ['a','b']
else:
    for text, expected in [('2m',120.), (' 250 ms ',.25), ('1.5s',1.5), ('0s',0.), (' .5 m ',30.)]:
        assert s.duration_seconds(text) == expected
    for text in ['-1s','NaNs','infs','1h','1','1.2.3s','s','']:
        if sys.argv[1] == 'changed' and text == '1': continue
        try: s.duration_seconds(text)
        except ValueError: pass
        else: raise AssertionError(text)
    for value in [None, 5]:
        try: s.duration_seconds(value)
        except TypeError: pass
        else: raise AssertionError('type')
    if sys.argv[1] == 'changed': assert s.duration_seconds(' 2.5 ') == 2.5
print('independent acceptance passed')
