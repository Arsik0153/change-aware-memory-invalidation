def normalize_labels(values):
    return list(values)
