def normalize_labels(values):
    labels = []
    seen = set()
    for value in values:
        if not isinstance(value, str):
            raise TypeError("labels must be strings")
        label = value.strip().casefold()
        if label and label not in seen:
            seen.add(label)
            labels.append(label)
    return labels
