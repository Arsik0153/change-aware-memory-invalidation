import pytest

from solution import normalize_labels


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_unicode_casefold_and_first_seen_order():
    assert normalize_labels([" B ", "Straße", "STRASSE", "b", "A"]) == [
        "b", "strasse", "a"
    ]


def test_generator_and_whitespace_only_labels():
    values = (value for value in ["\t\n", " A ", "", "a", " B\t"])
    assert normalize_labels(values) == ["a", "b"]


def test_empty_iterable():
    assert normalize_labels([]) == []


@pytest.mark.parametrize("value", [None, 1, False, b"a", [], {}])
def test_rejects_non_string_items(value):
    with pytest.raises(TypeError):
        normalize_labels(["a", value])
