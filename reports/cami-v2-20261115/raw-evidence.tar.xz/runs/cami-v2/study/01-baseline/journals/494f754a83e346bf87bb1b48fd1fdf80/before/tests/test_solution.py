from solution import normalize_labels
def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]
