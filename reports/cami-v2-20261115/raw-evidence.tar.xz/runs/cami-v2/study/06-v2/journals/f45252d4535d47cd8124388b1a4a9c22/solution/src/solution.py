import math
import re


def duration_seconds(text):
    """Parse a nonnegative decimal duration and return seconds."""
    if not isinstance(text, str):
        raise TypeError("duration must be a string")

    match = re.fullmatch(
        r"\s*([0-9]+(?:\.[0-9]*)?|\.[0-9]+)\s*(ms|s|m)?\s*", text
    )
    if match is None:
        raise ValueError("invalid duration")

    number, unit = match.groups()
    unit = DEFAULT_UNIT if unit is None else unit
    factors = {"ms": 0.001, "s": 1.0, "m": 60.0}
    if unit not in factors:
        raise ValueError("unknown duration unit")

    seconds = float(number) * factors[unit]
    if not math.isfinite(seconds):
        raise ValueError("duration must be finite")
    return seconds

DEFAULT_UNIT = "s"
