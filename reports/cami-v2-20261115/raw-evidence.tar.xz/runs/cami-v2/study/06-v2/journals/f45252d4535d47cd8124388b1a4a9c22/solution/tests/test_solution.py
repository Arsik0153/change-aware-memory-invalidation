import pytest

import solution
from solution import duration_seconds


def test_duration():
    assert duration_seconds("2m") == 120.0


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("250ms", 0.25),
        ("1.5s", 1.5),
        ("1.5m", 90.0),
        (" \t2.5 \nms\n", 0.0025),
        ("0m", 0.0),
        (".5s", 0.5),
        ("1.s", 1.0),
        ("001.25s", 1.25),
        (" 2.5 ", 2.5),
    ],
)
def test_valid_durations(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize("unit, expected", [("ms", 0.002), ("s", 2.0), ("m", 120.0)])
def test_default_unit(monkeypatch, unit, expected):
    monkeypatch.setattr(solution, "DEFAULT_UNIT", unit)
    assert duration_seconds("2") == expected
    assert duration_seconds("2s") == 2.0


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "s", "1h", "1MS", "-1s", "-0s", "+1s",
        "NaNs", "infs", "Infinitym", "NaN", "inf", "1e2s", "1_000s",
        ".s", "1..2s", "1 2s", "1,5s", "1s extra", "1msms",
        "9" * 400 + "s", "9" * 308 + "m",
    ],
)
def test_invalid_durations(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("value", [None, 1, 1.5, True, b"2s", [], {}])
def test_non_string_durations(value):
    with pytest.raises(TypeError):
        duration_seconds(value)
