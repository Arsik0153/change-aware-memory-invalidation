def normalize_labels(values):
    return list(values)

DEFAULT_SEPARATOR = ","
