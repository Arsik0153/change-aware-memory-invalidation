import pytest

import solution
from solution import normalize_labels


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_casefold_and_first_seen_order():
    assert normalize_labels([" B ", "Straße", "STRASSE", "a", "b"]) == [
        "b", "strasse", "a"
    ]


def test_generator_and_empty_labels():
    assert normalize_labels(value for value in [" ", "\t\n", " A ", "a"]) == ["a"]
    assert normalize_labels([]) == []


def test_delimited_string():
    assert normalize_labels(" A ,a,, B, ") == ["a", "b"]
    assert normalize_labels("") == []


def test_uses_default_separator(monkeypatch):
    monkeypatch.setattr(solution, "DEFAULT_SEPARATOR", ";")
    assert normalize_labels(" A ;a;; B") == ["a", "b"]


def test_iterable_items_are_not_split():
    assert normalize_labels([" A,B "]) == ["a,b"]


@pytest.mark.parametrize("value", [None, 1, b"label", [], {}])
def test_non_string_items_raise(value):
    with pytest.raises(TypeError):
        normalize_labels(["valid", value])
