import pytest

import solution
from solution import normalize_labels


def test_labels():
    assert normalize_labels([" A ", "a", "", "B"]) == ["a", "b"]


def test_labels_preserve_order_and_casefold():
    assert normalize_labels([" B ", "Straße", "STRASSE", "b", " A "]) == [
        "b", "strasse", "a"
    ]


def test_labels_accept_generators():
    assert normalize_labels(value for value in [" A ", "a", " B "]) == ["a", "b"]


@pytest.mark.parametrize("values", [[], (), "", " , , ", ["", " \t\n"]])
def test_empty_labels(values):
    assert normalize_labels(values) == []


@pytest.mark.parametrize("value", [None, 1, False, b"a", ["a"]])
def test_labels_reject_non_strings(value):
    with pytest.raises(TypeError):
        normalize_labels(["a", value])


def test_comma_delimited_labels():
    assert normalize_labels(" A, b, a, , STRASSE, Straße ") == ["a", "b", "strasse"]


def test_labels_use_default_separator(monkeypatch):
    monkeypatch.setattr(solution, "DEFAULT_SEPARATOR", ";")
    assert normalize_labels(" A; b; a ") == ["a", "b"]


def test_iterable_labels_are_not_split():
    assert normalize_labels([" A,B ", "a,b"]) == ["a,b"]
