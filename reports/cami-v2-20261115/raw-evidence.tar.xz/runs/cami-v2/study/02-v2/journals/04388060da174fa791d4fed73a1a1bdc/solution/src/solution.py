import math
import re


def duration_seconds(text):
    """Convert a nonnegative decimal duration in ms, s, or m to seconds."""
    if not isinstance(text, str):
        raise TypeError("duration must be a string")

    match = re.fullmatch(r"\s*([0-9]+(?:\.[0-9]*)?|\.[0-9]+)\s*(ms|s|m)\s*", text)
    if match is None:
        raise ValueError("expected a nonnegative decimal followed by ms, s, or m")

    number, unit = match.groups()
    seconds = float(number) * {"ms": 0.001, "s": 1.0, "m": 60.0}[unit]
    if not math.isfinite(seconds):
        raise ValueError("duration must be finite")
    return seconds
