import pytest

from solution import duration_seconds


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("2m", 120.0),
        ("250ms", 0.25),
        ("1.5s", 1.5),
        (" \t2.5 \n m\r\n", 150.0),
        (".5s", 0.5),
        ("2.s", 2.0),
        ("0ms", 0.0),
        ("00.25m", 15.0),
    ],
)
def test_duration(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "2", "2h", "2S", "ms", "-2s", "-0s", "+2s",
        "NaNs", "infs", "Infinitym", ".s", "1.2.3s", "1e3s",
        "1_000s", "1 2s", "1m s", "2s extra", "2s\n3s", "١s",
        "9" * 400 + "s", "9" * 308 + "m",
    ],
)
def test_duration_invalid(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("value", [None, 2, 1.5, True, b"2s", [], {}])
def test_duration_requires_string(value):
    with pytest.raises(TypeError):
        duration_seconds(value)
