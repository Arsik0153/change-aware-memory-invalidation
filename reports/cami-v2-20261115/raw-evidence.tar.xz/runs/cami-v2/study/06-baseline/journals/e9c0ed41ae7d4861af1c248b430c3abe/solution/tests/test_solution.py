import pytest

import solution
from solution import duration_seconds


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("2m", 120.0),
        ("250ms", 0.25),
        ("1.5s", 1.5),
        (" \t2.5 \n m\t", 150.0),
        ("0ms", 0.0),
        (".5s", 0.5),
        ("1.s", 1.0),
        (" 2.5 ", 2.5),
    ],
)
def test_duration(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize("unit, expected", [("ms", 0.002), ("m", 120.0)])
def test_default_unit(monkeypatch, unit, expected):
    monkeypatch.setattr(solution, "DEFAULT_UNIT", unit)
    assert duration_seconds("2") == pytest.approx(expected)
    assert duration_seconds("2s") == 2.0


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "s", "1h", "1MS", "-1s", "-0s", "NaN", "nan s",
        "inf", "Infinitym", "1..2s", ".s", "1 2s", "1e3s", "1_000s",
        "1s extra", "1s2", "9" * 400 + "s", "9" * 308 + "m",
    ],
)
def test_invalid_duration(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("value", [None, 1, 1.5, True, b"2s", [], {}])
def test_non_string_duration(value):
    with pytest.raises(TypeError):
        duration_seconds(value)


def test_invalid_default_unit(monkeypatch):
    monkeypatch.setattr(solution, "DEFAULT_UNIT", "h")
    with pytest.raises(ValueError):
        duration_seconds("2")
