def duration_seconds(text):
    return float(text)

DEFAULT_UNIT = "s"
