import math
import re


DEFAULT_UNIT = "s"
_UNIT_SECONDS = {"ms": 0.001, "s": 1.0, "m": 60.0}
_DURATION = re.compile(r"([0-9]+(?:\.[0-9]*)?|\.[0-9]+)\s*([a-z]+)?")


def duration_seconds(text):
    """Parse a nonnegative decimal duration, defaulting to DEFAULT_UNIT."""
    if not isinstance(text, str):
        raise TypeError("duration must be a string")

    match = _DURATION.fullmatch(text.strip())
    if match is None:
        raise ValueError("invalid duration")

    number, unit = match.groups()
    unit = DEFAULT_UNIT if unit is None else unit
    if unit not in _UNIT_SECONDS:
        raise ValueError("unknown duration unit")

    seconds = float(number) * _UNIT_SECONDS[unit]
    if not math.isfinite(seconds):
        raise ValueError("duration must be finite")
    return seconds
