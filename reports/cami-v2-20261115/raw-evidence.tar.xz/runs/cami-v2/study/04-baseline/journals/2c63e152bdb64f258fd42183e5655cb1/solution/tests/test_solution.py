import pytest

from solution import duration_seconds


@pytest.mark.parametrize(
    "text, expected",
    [
        ("2m", 120.0),
        ("250ms", 0.25),
        ("1.5s", 1.5),
        (" \t2.5 \n m\r\n", 150.0),
        ("0ms", 0.0),
        (".5s", 0.5),
        ("1.s", 1.0),
        ("0002s", 2.0),
    ],
)
def test_duration(text, expected):
    result = duration_seconds(text)
    assert isinstance(result, float)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize(
    "text",
    [
        "", " ", "2", "2h", "2MS", "-1s", "-0s", "NaNs", "infs",
        "Infinitym", ".s", "1.2.3s", "1 2s", "1e3s", "1_000s",
        "2s extra", "2s\n3s", "9" * 400 + "s", "9" * 308 + "m",
    ],
)
def test_invalid_duration(text):
    with pytest.raises(ValueError):
        duration_seconds(text)


@pytest.mark.parametrize("text", [None, 1, 1.5, True, b"2s", [], {}])
def test_non_string_duration(text):
    with pytest.raises(TypeError):
        duration_seconds(text)
