"""Versioned, worktree-bound solution records. No model reasoning is retained."""
from __future__ import annotations

import difflib
import json
from pathlib import Path

try:
    from . import task_replay as replay
except ImportError:
    import task_replay as replay


def namespace(root, workspace):
    return Path(root).resolve() / 'task-v2' / replay.digest(str(Path(workspace).resolve()).encode())


def hints(state, task, limit=2):
    words = set(task.casefold().split())
    found = []
    for path in (Path(state) / 'methods').glob('*.json'):
        value = json.loads(path.read_text())
        overlap = len(words & set(value['symptom'].casefold().split()))
        if overlap:
            found.append((-overlap, path.name, value))
    result = []
    for _, _, value in sorted(found)[:limit]:
        if len(value['patch'].encode()) > 4000:
            value = {**value, 'patch': None, 'patch_omitted': 'read verified artifact via provenance'}
        result.append(value)
    return result


def remember(directory, config, terminal):
    if not terminal['cache_eligible']:
        return False
    before, after = Path(directory) / 'before', Path(directory) / 'solution'
    patches, components = [], []
    for path in sorted(set(config['files']) | set(terminal['solution_files'])):
        if config['files'].get(path) == terminal['solution_files'].get(path):
            continue
        components.append(path)
        a = (before / path).read_text(errors='replace') if (before / path).exists() else ''
        b = (after / path).read_text(errors='replace') if (after / path).exists() else ''
        patches.extend(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile=path, tofile=path))
    value = {'schema': 'cami-verified-method/1', 'symptom': config['task'],
             'cause': None, 'cause_status': 'not independently established',
             'components': components, 'patch': ''.join(patches),
             'verification': {'argv': config['grade'], 'quality': terminal['quality'],
                              'log_sha256': replay.digest((Path(directory) / 'grade.log').read_bytes())},
             'applicability': {'exact_input_key': config['key'], 'context': config['context'],
                               'similar_tasks': 'hint only; inspect current code and verify anew'},
             'provenance': str(Path(directory).resolve())}
    target = Path(config['v2_state']) / 'methods'
    target.mkdir(parents=True, exist_ok=True)
    replay.publish(target / (config['key'] + '.json'), replay.canonical(value))
    return True
