"""Actual frozen MCP dispatch profiles in owned offline runtime; no model/source execution."""

from __future__ import annotations

import argparse
import cProfile
import importlib.metadata
import json
from pathlib import Path
import pstats
import resource
import sys
import time


def memory():
    return {
        "rss_peak_kib_self_lifetime": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "cgroup_current_bytes": int(Path("/sys/fs/cgroup/memory.current").read_text()),
        "cgroup_peak_bytes_lifetime": int(Path("/sys/fs/cgroup/memory.peak").read_text()),
    }


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def profile_rows(profile):
    statistics = pstats.Stats(profile)
    rows = []
    for (filename, line, name), (primitive, calls, own, cumulative, _) in statistics.stats.items():
        rows.append(
            {
                "filename": filename,
                "line": line,
                "function": name,
                "primitive_calls": primitive,
                "calls": calls,
                "tottime_seconds": own,
                "cumulative_seconds_nonadditive": cumulative,
            }
        )
    return {
        "total_tottime_seconds": statistics.total_tt,
        "function_count": len(rows),
        "top_cumulative_nonadditive": sorted(
            rows, key=lambda x: x["cumulative_seconds_nonadditive"], reverse=True
        )[:60],
        "top_tottime": sorted(rows, key=lambda x: x["tottime_seconds"], reverse=True)[:60],
        "all_functions": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", required=True)
    parser.add_argument("--same-process-repeat", action="store_true")
    args = parser.parse_args()
    # Trusted code only; target /workspace is never on helper import paths.
    if any("/workspace" in path for path in sys.path):
        raise ValueError("workspace import boundary violated")
    from memory_adapter import Server

    config = json.loads(Path("/check/config.json").read_bytes())
    output = Path("/check")
    report = {
        "label": args.label,
        "model_calls": 0,
        "network": "none",
        "status": "started",
        "python": sys.version,
        "pydantic": importlib.metadata.version("pydantic"),
        "cases": [],
    }
    try:
        server = Server(
            Path("/memory/prepared/binding.json"),
            output / "backend-trace.jsonl",
            response_format="compact",
        )
        server.dispatch(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {},
                    "clientInfo": {"name": "no-model-lookup-profile", "version": "1"},
                },
            }
        )
        server.dispatch({"jsonrpc": "2.0", "method": "notifications/initialized"})
        labels = [args.label] + (
            [args.label + "-same-process-repeat"] if args.same_process_repeat else []
        )
        for index, label in enumerate(labels):
            before_memory = memory()
            profiler = cProfile.Profile()
            start, cpu = time.perf_counter(), time.process_time()
            profiler.enable()
            try:
                result = server.dispatch(
                    {
                        "jsonrpc": "2.0",
                        "id": index + 2,
                        "method": "tools/call",
                        "params": {"name": "memory_lookup", "arguments": config["arguments"]},
                    }
                )
            finally:
                profiler.disable()
            wall, process_cpu = time.perf_counter() - start, time.process_time() - cpu
            after_memory = memory()
            profiler.dump_stats(str(output / (label + ".prof")))
            profile = profile_rows(profiler)
            save(output / (label + "-profile.json"), profile)
            save(output / (label + "-mcp-result.json"), result)
            value = json.loads(result["content"][0]["text"])
            if (
                result["isError"]
                or value.get("error")
                or value.get("response_format") != "research-memory-compact/1"
            ):
                raise ValueError("actual lookup failed")
            selected = [entry["id"] for entry in value["entries"] + value["withheld"]]
            if len(selected) != len(set(selected)) or value["selected_records"] != len(selected):
                raise ValueError("actual selection malformed")
            report["cases"].append(
                {
                    "label": label,
                    "before_dispatch_memory": before_memory,
                    "after_dispatch_memory": after_memory,
                    "profiled_dispatch_wall_seconds": wall,
                    "profiled_dispatch_process_cpu_seconds": process_cpu,
                    "returned_ids": [entry["id"] for entry in value["entries"]],
                    "withheld_ids": [entry["id"] for entry in value["withheld"]],
                    "profile_total_tottime_seconds": profile["total_tottime_seconds"],
                    "profile_functions": profile["function_count"],
                    "timing_scope": "cProfile active for actual Server.dispatch tools/call; includes first CAMI import/refresh/ranking/serialization/storage/trace, excludes Python+adapter import/constructor; profiler slows execution, attribution only",
                }
            )
        report["status"] = "passed"
    except BaseException as error:
        report.update(status="failed", error=type(error).__name__ + ": " + str(error))
        raise
    finally:
        save(output / "report.json", report)


if __name__ == "__main__":
    main()
