"""Read-only profile/output/state-semantic comparison across three frozen core variants."""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import pstats
import sqlite3
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ROOTS = {
    "baseline": ROOT / "runs/opencode-lookup-profile-20261106/profile-v1",
    "candidate1": ROOT / "runs/opencode-membership-candidate-20261106/profile-v1",
    "candidate2": HERE / "profile-v1",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()


def load(path):
    return json.loads(path.read_bytes())


def stats(values):
    return {
        "n": len(values),
        "min": min(values),
        "median": statistics.median(values),
        "max": max(values),
        "samples": values,
    }


def focus(path):
    profile = pstats.Stats(str(path))
    result = {
        "total_profile_tottime_seconds": profile.total_tt,
        "scan_matches_calls": 0,
        "validation_genexpr_to_pydantic_eq_calls": 0,
        "index_to_pydantic_eq_calls": 0,
        "definition_index_calls": 0,
        "transition_many_calls": 0,
    }
    for (filename, _, name), (_, calls, _, cumulative, callers) in profile.stats.items():
        if filename == "/opt/cami-src/cami/product/memory/validation.py":
            if name == "matches":
                result["scan_matches_calls"] += calls
                result["scan_matches_cumulative_seconds_nonadditive"] = cumulative
            if name == "_definition_index":
                result["definition_index_calls"] += calls
                result["definition_index_cumulative_seconds_nonadditive"] = cumulative
            if name == "transition_many":
                result["transition_many_calls"] += calls
                result["transition_many_cumulative_seconds_nonadditive"] = cumulative
        if filename.endswith("/pydantic/main.py") and name == "__eq__":
            for (caller_file, _, caller_name), value in callers.items():
                if (
                    caller_file == "/opt/cami-src/cami/product/memory/validation.py"
                    and caller_name == "<genexpr>"
                ):
                    result["validation_genexpr_to_pydantic_eq_calls"] += value[1]
                if caller_file == "/opt/cami-src/cami/index.py" and caller_name == "build_index":
                    result["index_to_pydantic_eq_calls"] += value[1]
    return result


def portable_source(source):
    return {key: value for key, value in source.items() if key != "index"}


def semantic_vectors(namespace):
    """Read SQLite in mode=ro&immutable; do not use production connection/recovery APIs."""
    databases = list((namespace / "memory/cami-state").rglob("memory.sqlite3"))
    assert len(databases) == 1
    path = databases[0]
    before = sha(path)
    binding = load(namespace / "memory/prepared/binding.json")
    reverse = {value["memory_id"]: key for key, value in binding["mapping"].items()}
    db = sqlite3.connect(path.absolute().as_uri() + "?mode=ro&immutable=1", uri=True)
    try:
        assert db.execute("PRAGMA query_only").fetchone()[0] in (0, 1)
        db.execute("PRAGMA query_only=ON")
        rows = db.execute(
            "SELECT sequence,value FROM memory_generation ORDER BY sequence"
        ).fetchall()
    finally:
        db.close()
    assert sha(path) == before
    generations, provenance = [], []
    for sequence, text in rows:
        generation = json.loads(text)
        provenance.append({key: value for key, value in generation.items() if key != "states"})
        entries = []
        for item in generation["states"]:
            record, state = item["record"], item["state"]
            payload = dict(record["payload"])
            payload["origin_source"] = portable_source(payload["origin_source"])
            check = state["check"]
            entries.append(
                {
                    "catalog_id": reverse[record["memory_id"]],
                    "record_revision": record["revision"],
                    "payload": payload,
                    "state_type": state["type"],
                    "verdict": check["verdict"],
                    "reason": check["reason"],
                    "check_record_revision": check["record_revision"],
                    "evidence": [portable_source(value) for value in check["evidence"]],
                    "equivalence_rule": state.get("equivalence", {}).get("rule"),
                    "dependency_scopes": item["dependencies"]["scopes"],
                    "dependency_certain": item["dependencies"]["certain"],
                    "invalidation_scopes": item["invalidation_scopes"],
                }
            )
        entries.sort(key=lambda row: row["catalog_id"])
        assert len(entries) in (0, 329)
        generations.append(
            {
                "sequence": sequence,
                "catalog_epoch": generation["catalog_epoch"],
                "records": entries,
                "state_counts": dict(Counter(row["state_type"] for row in entries)),
                "verdict_counts": dict(Counter(row["verdict"] for row in entries)),
            }
        )
    return {
        "sqlite_sha256": before,
        "read_mode": "sqlite3 URI mode=ro&immutable=1 plus query_only; no production recovery or writes",
        "semantic_generations": generations,
        "actual_provenance_not_compared_for_identity": provenance,
        "comparison_scope": "Portable full literal payloads, revisions, state types, verdict/reason/evidence sources, equivalence rule, dependency scopes/certainty and invalidation scopes. Fingerprints, timestamps, check/index/generation IDs retain separate actual provenance and are not fabricated equal.",
    }


def main():
    reports = {key: load(root / "report.json") for key, root in ROOTS.items()}
    for key, report in reports.items():
        assert report["status"] == "passed"
        for name, expected in report["artifact_hashes"].items():
            assert sha(ROOTS[key] / name) == expected
    comparisons = []
    for repetition in range(1, 4):
        namespace = f"r{repetition}-cami"
        selected = [row for row in reports["candidate2"]["cases"] if row["namespace"] == namespace]
        for container_case in selected:
            label = container_case["case"]
            counterparts = {
                key: next(
                    row
                    for row in report["cases"]
                    if row["namespace"] == namespace and row["case"] == label
                )
                for key, report in reports.items()
            }
            for case in container_case["report"]["cases"]:
                phase = case["label"]
                content, attribute, trace_state = {}, {}, {}
                for key, root in ROOTS.items():
                    directory = root / namespace / label
                    result = load(directory / (phase + "-mcp-result.json"))
                    assert result["isError"] is False
                    value = json.loads(result["content"][0]["text"])
                    value.pop("audit_receipt")
                    content[key] = value
                    attribute[key] = focus(directory / (phase + ".prof"))
                    events = [
                        json.loads(line)
                        for line in (directory / "backend-trace.jsonl").read_text().splitlines()
                    ]
                    events = [event for event in events if event["event"] == "memory_lookup"]
                    phases = [entry["label"] for entry in counterparts[key]["report"]["cases"]]
                    event = events[phases.index(phase)]
                    trace_state[key] = {
                        field: event.get(field)
                        for field in [
                            "selected_records",
                            "returned_records",
                            "withheld_records",
                            "states_checked_type",
                            "states_carried_type",
                            "note_states",
                        ]
                    }
                assert content["baseline"] == content["candidate1"] == content["candidate2"], (
                    namespace,
                    phase,
                    "MCP",
                )
                assert (
                    trace_state["baseline"]
                    == trace_state["candidate1"]
                    == trace_state["candidate2"]
                ), (namespace, phase, "state_counts")
                comparisons.append(
                    {
                        "namespace": namespace,
                        "case": phase,
                        "portable_mcp_and_status_exact": True,
                        "checked_carried_trace_counts_exact": True,
                        "trace_counts": trace_state["candidate2"],
                        "attribution": attribute,
                    }
                )
    vector_dir = HERE / "semantic-vectors"
    vector_dir.mkdir(exist_ok=False)
    vector_proof = []
    for repetition in range(1, 4):
        namespace = f"r{repetition}-cami"
        vectors = {key: semantic_vectors(root / namespace) for key, root in ROOTS.items()}
        assert (
            vectors["baseline"]["semantic_generations"]
            == vectors["candidate1"]["semantic_generations"]
            == vectors["candidate2"]["semantic_generations"]
        )
        for key, value in vectors.items():
            (vector_dir / f"{key}-{namespace}.json").write_text(
                json.dumps(value, sort_keys=True, indent=2) + "\n"
            )
        vector_proof.append(
            {
                "namespace": namespace,
                "full329record_semantics_exact": True,
                "sqlite_sha256": {key: value["sqlite_sha256"] for key, value in vectors.items()},
                "generation_counts": [
                    {
                        "sequence": g["sequence"],
                        "records": len(g["records"]),
                        "states": g["state_counts"],
                        "verdicts": g["verdict_counts"],
                    }
                    for g in vectors["baseline"]["semantic_generations"]
                ],
            }
        )
    changed = [row for row in comparisons if row["case"] == "changed-new-process"]
    all_keys = sorted(
        {field for row in changed for values in row["attribution"].values() for field in values}
    )
    attribution = {
        key: {
            field: stats([row["attribution"][key].get(field, 0) for row in changed])
            for field in all_keys
        }
        for key in ROOTS
    }
    freeze = load(HERE / "source-freeze.json")
    for name, expected in freeze["candidate_files"].items():
        assert sha(HERE / "candidate-source" / name) == expected
    for name, expected in freeze["controller_helper_snapshot"].items():
        assert sha(HERE / "controller-snapshot" / name) == expected
    report = {
        "status": "candidate2_attribution_and_semantics_passed",
        "actual_mcp_comparisons": len(comparisons),
        "changed_snapshot_profiles": len(changed),
        "portable_payload_and_status_exact_all15": True,
        "checked_carried_counts_exact_all15": True,
        "all329record_semantics_per_generation_exact": vector_proof,
        "changed_profile_attribution": attribution,
        "comparisons": comparisons,
        "source_freeze_sha256": sha(HERE / "source-freeze.json"),
        "candidate2_raw_report_sha256": sha(ROOTS["candidate2"] / "report.json"),
        "only_core_differences": freeze["changed_core_files"],
        "model_calls": 0,
        "heldout_reads": False,
        "original_baseline_and_candidate1_artifacts_unchanged": True,
        "semantic_limits": "These real profiles cover source_excerpt_equals only; root separately reports51 authored tests across4kinds/15views/history/model_copy/duplicates/subclasses. No all-kind claim is inferred from Click literals.",
        "timing_scope": "cProfile attribution under concurrent fullproject correctness tests; no unprofiled/end-to-end speed claim. Quiet interleaved baseline/c1/c2 A/B awaits fullsuite/archive completion.",
    }
    (HERE / "comparison.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "calls": len(comparisons),
                "generations": vector_proof,
                "attribution": attribution,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
