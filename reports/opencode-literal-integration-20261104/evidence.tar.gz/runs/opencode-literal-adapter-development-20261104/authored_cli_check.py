"""New-only authored generator/static stdio CLI check. No CAMI, model or Docker calls."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(argv, out, *, input_bytes=None):
    result = subprocess.run(
        [str(x) for x in argv], input=input_bytes, capture_output=True, timeout=10
    )
    out.write_text(
        json.dumps(
            {
                "argv": [str(x) for x in argv],
                "returncode": result.returncode,
                "stdout": result.stdout.decode(),
                "stderr": result.stderr.decode(),
            },
            indent=2,
        )
        + "\n"
    )
    if result.returncode:
        raise ValueError("authored CLI check failed; preserved command evidence")
    return result.stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.absolute()
    if out.exists() or not out.is_relative_to(HERE):
        parser.error("new output under this stage required")
    out.mkdir(parents=True)
    repo = out / "repo"
    (repo / "src/pkg").mkdir(parents=True)
    (repo / "src/pkg/m.py").write_bytes(
        'def _identity(fn):\r\n    return fn\r\n@(\r\n    _identity\r\n)\r\ndef alpha():\r\n    return "quokka😀"\r\n\r\ndef beta():\r\n    return 2\r\n'.encode()
    )
    command(
        [
            sys.executable,
            HERE / "seed_source_literals_v2.py",
            "--repo",
            repo,
            "--source-root",
            "src/pkg",
            "--out",
            out / "generator",
        ],
        out / "generate-process.json",
    )
    command(
        [
            sys.executable,
            HERE / "memory_adapter.py",
            "prepare",
            "--backend",
            "static",
            "--repo",
            repo,
            "--seed-spec",
            out / "generator/seed-spec.json",
            "--out",
            out / "prepared",
        ],
        out / "prepare-process.json",
    )
    requests = [
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {"name": "authored"},
            },
        },
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "memory_lookup", "arguments": {"query": "quokka", "limit": 1}},
        },
    ]
    incoming = b"".join(json.dumps(row).encode() + b"\n" for row in requests)
    bodies = {}
    for selected in ("full", "compact"):
        argv = [
            sys.executable,
            HERE / "memory_adapter.py",
            "serve",
            "--binding",
            out / "prepared/binding.json",
            "--trace",
            out / (selected + "-trace.jsonl"),
        ]
        if selected == "compact":
            argv += ["--response-format", "compact"]
        stdout = command(argv, out / (selected + "-process.json"), input_bytes=incoming)
        replies = [json.loads(line) for line in stdout.splitlines()]
        value = json.loads(replies[-1]["result"]["content"][0]["text"])
        entry = value["entries"][0]
        assert value["schema_version"] == 1 and entry["label"] == "origin_literal_source_assertion"
        assert (
            entry["availability"] == "unchecked_current"
            and entry["payload"]["type"] == "source_excerpt_equals"
        )
        assert entry["payload"]["expected"]["text"].startswith("@(\r\n")
        assert entry["payload"]["origin_span"]["first_line"] == 3
        assert ("response_format" in value) == (selected == "compact")
        bodies[selected] = entry["payload"]
    assert bodies["full"] == bodies["compact"]
    report = {
        "status": "passed",
        "source": "authored_only",
        "core_calls": 0,
        "model_calls": 0,
        "docker_calls": 0,
        "seed_schema": 2,
        "catalog_schema": 2,
        "wire_envelope_schema": 1,
        "literal_fields_preserved_in_both_formats": True,
        "artifact_hashes": {
            p.relative_to(out).as_posix(): digest(p) for p in out.rglob("*") if p.is_file()
        },
    }
    (out / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
