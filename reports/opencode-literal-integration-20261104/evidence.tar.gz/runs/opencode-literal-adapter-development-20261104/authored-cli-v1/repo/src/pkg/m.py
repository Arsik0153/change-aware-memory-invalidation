def _identity(fn):
    return fn
@(
    _identity
)
def alpha():
    return "quokka😀"

def beta():
    return 2
