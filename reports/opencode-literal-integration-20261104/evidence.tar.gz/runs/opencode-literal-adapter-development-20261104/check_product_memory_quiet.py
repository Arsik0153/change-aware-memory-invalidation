"""Staged authored ProductMemory integration. Default plan; run only in a quiet window."""

from __future__ import annotations

import argparse
import copy
import io
import json
from pathlib import Path
import subprocess
import sys

from memory_backend import Backend, canonical, digest, prepare, save
from seed_source_literals_v2 import build
from memory_adapter import serve

HERE = Path(__file__).resolve().parent


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def stdio_lookup(binding, trace, response_format, query):
    requests = [
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {"name": "authored-quiet-check"},
            },
        },
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "memory_lookup", "arguments": {"query": query, "limit": 1}},
        },
    ]
    incoming = io.BytesIO(b"".join(canonical(row) + b"\n" for row in requests))
    outgoing = io.BytesIO()
    kwargs = {} if response_format == "full" else {"response_format": "compact"}
    serve(binding, trace, incoming, outgoing, **kwargs)
    result = json.loads(outgoing.getvalue().splitlines()[-1])["result"]
    value = json.loads(result["content"][0]["text"])
    if ("response_format" in value) != (response_format == "compact"):
        raise AssertionError("actual stdio response format mismatch")
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run",
        action="store_true",
        help="Explicit real authored integration; not for active benchmark window",
    )
    parser.add_argument("--core-source", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(
            "Plan only: two authored functions; actual CAMI register/equal/retain/unavailable checks. Zero core calls."
        )
        return
    if not args.core_source or not args.out:
        parser.error("--run requires explicit new --out and staged --core-source")
    source = args.core_source.resolve()
    if not (source / "cami/product/memory/python_excerpt.py").is_file() or any(
        name == "cami" or name.startswith("cami.") for name in sys.modules
    ):
        parser.error("fresh process and explicit literal-capable core source required")
    out = args.out.absolute()
    if out.exists() or not out.is_relative_to(HERE):
        parser.error("new output under this development stage required")
    out.mkdir(parents=True)
    sys.path.insert(0, str(source))
    repo = out / "repo"
    repo.mkdir()
    module = repo / "m.py"
    origin = "def _identity(fn):\n    return fn\n@(\n    _identity\n)\ndef alpha():\n    return 1\n\ndef beta():\n    return 2\n"
    module.write_text(origin)
    for argv in [["git", "init", "--quiet", "--template=", str(repo)]]:
        result = subprocess.run(argv, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError("authored local Git initialization failed")
    seed, metrics = build(repo, ["."])
    save(out / "seed-spec.json", seed)
    write(out / "generation-metrics.json", metrics)
    report = {
        "status": "started",
        "model_calls": 0,
        "docker_calls": 0,
        "authored_only": True,
        "core_source": str(source),
        "tests": [],
    }
    try:
        prepare("static", repo, out / "static", spec_path=out / "seed-spec.json")
        prepare(
            "cami", repo, out / "cami", spec_path=out / "seed-spec.json", state_home=out / "state"
        )
        if (out / "static/catalog.json").read_bytes() != (out / "cami/catalog.json").read_bytes():
            raise AssertionError("same-origin literal catalogs differ")
        static, cami = Backend(out / "static/binding.json"), Backend(out / "cami/binding.json")
        first, _ = cami.lookup("alpha", 1)
        if len(first["entries"]) != 1 or first["entries"][0]["label"] != "validated_literal_source":
            raise AssertionError("actual new literal predicate not initially supported")
        report["tests"].append("server-derived registration equals frozen literal catalog")
        catalog = json.loads((out / "cami/catalog.json").read_bytes())
        selected = next(
            row for row in catalog["records"] if row["payload"]["subject"]["qualname"] == "alpha"
        )
        observations = []
        for arm in ("static", "cami"):
            for response_format in ("full", "compact"):
                value = stdio_lookup(
                    out / arm / "binding.json",
                    out / f"{arm}-{response_format}-initial.jsonl",
                    response_format,
                    "_identity",
                )
                if [row["id"] for row in value["entries"]] != [selected["id"]]:
                    raise AssertionError("literal-content ranking differs between arms/formats")
                if value["entries"][0]["payload"] != selected["payload"]:
                    raise AssertionError(
                        "literal expected/source/span lost in actual MCP projection"
                    )
                budget = value["selection_budget"]
                if (
                    budget["origin_record_bytes"] != 16384
                    or budget["used_bytes"] != len(canonical(selected))
                    or budget["ranking_before_availability"] is not True
                ):
                    raise AssertionError("origin selection budget changed")
                observations.append(
                    {
                        "backend": arm,
                        "format": response_format,
                        "id": selected["id"],
                        "label": value["entries"][0]["label"],
                    }
                )
        report["stdio_initial_observations"] = observations
        report["tests"].append(
            "actual static/CAMI full/compact stdio content retrieval and origin budget agree"
        )
        bad = copy.deepcopy(seed)
        bad["records"][0]["expected"]["text"] = "tampered frozen text"
        save(out / "tampered-seed.json", bad)
        try:
            prepare(
                "cami",
                repo,
                out / "tampered-prepare",
                spec_path=out / "tampered-seed.json",
                state_home=out / "must-not-exist",
            )
        except ValueError:
            if (out / "must-not-exist").exists():
                raise AssertionError("tampered expected reached backend state construction")
        else:
            raise AssertionError("tampered frozen expected accepted")
        report["tests"].append("frozen expected tamper denied before real CAMI state construction")
        note = {
            "schema_version": 1,
            "source_roots": ["."],
            "excluded_paths": [],
            "records": [
                {
                    "id": "legacy-note",
                    "kind": "note",
                    "selector": "m.py:alpha",
                    "subject": selected["payload"]["subject"],
                    "note_key": "legacy-manual-note",
                    "text": "Authored old manual note; not converted.",
                }
            ],
        }
        save(out / "legacy-seed.json", note)
        prepare("static", repo, out / "legacy-static", spec_path=out / "legacy-seed.json")
        prepare(
            "cami",
            repo,
            out / "legacy-cami",
            spec_path=out / "legacy-seed.json",
            state_home=out / "legacy-state",
        )
        if (out / "legacy-static/catalog.json").read_bytes() != (
            out / "legacy-cami/catalog.json"
        ).read_bytes():
            raise AssertionError("schema1 static/CAMI catalogs differ")
        manual = Backend(out / "legacy-cami/binding.json")
        manual_initial, _ = manual.lookup("legacy-note", 1)
        if (
            manual_initial["entries"][0]["payload"]["type"] != "note"
            or manual_initial["entries"][0]["label"] != "manual_assertion"
        ):
            raise AssertionError("legacy note converted or relabeled")
        # Shift lines and edit only another function. Literal alpha remains equal.
        module.write_text("\n\n" + origin.replace("return 2", "return 99"))
        unchanged, _ = cami.lookup("alpha", 1)
        if len(unchanged["entries"]) != 1:
            raise AssertionError("unchanged literal after unrelated edit was not retained")
        report["tests"].append("unrelated edit and physical-line shift retain literal")
        manual_changed, _ = manual.lookup("legacy-note", 1)
        if manual_changed["entries"] or not manual_changed["withheld"]:
            raise AssertionError("legacy manual note policy changed")
        report["tests"].append(
            "schema1 note unchanged and still requires review after same-file edit"
        )
        module.write_text(origin.replace("@(\n", "@ (\n"))
        changed, _ = cami.lookup("alpha", 1)
        unchecked, _ = static.lookup("alpha", 1)
        if (
            changed["entries"]
            or len(changed["withheld"]) != 1
            or unchecked["entries"][0]["availability"] != "unchecked_current"
        ):
            raise AssertionError(
                "changed decorator opening not withheld or static relabeled current"
            )
        if "payload" in changed["withheld"][0]:
            raise AssertionError("withheld historical payload leaked")
        report["tests"].append(
            "changed only lexical decorator opening withheld with no history; static remains unchecked"
        )
        for response_format in ("full", "compact"):
            value = stdio_lookup(
                out / "cami/binding.json",
                out / f"cami-{response_format}-withheld.jsonl",
                response_format,
                "alpha",
            )
            if (
                value["entries"]
                or [row["id"] for row in value["withheld"]] != [selected["id"]]
                or "payload" in value["withheld"][0]
            ):
                raise AssertionError(
                    "withheld actual MCP response leaked historical context or substituted another result"
                )
        report["tests"].append(
            "actual full/compact unavailable responses preserve withheld ID without history"
        )
        report.update(
            status="passed",
            seed_sha256=digest(seed),
            result_bytes={
                "first": len(canonical(first)),
                "unrelated_edit": len(canonical(unchanged)),
                "changed": len(canonical(changed)),
            },
        )
    except BaseException as error:
        report.update(status="failed", failure=type(error).__name__ + ": " + str(error))
        raise
    finally:
        write(out / "report.json", report)


if __name__ == "__main__":
    main()
