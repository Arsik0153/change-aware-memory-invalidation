# Explicit literal-source adapter and generator v2 (staging)

This stage adds a new source-only catalog path. It does not convert manual notes, change old study assets, edit tracked/frozen files, run models/Docker, or read task gold/heldout data. Useful retained source context is the goal; no latency/token/quality/billing win is presumed.

## Shape and trust boundary

Seed2 keeps the four policy fields (`schema_version:2`, source roots, exclusions, records). Each record has `id`, `kind:source_excerpt_equals`, exact selector/subject, frozen `expected:{format:python.definition-prefix/1,text,truncated}`, portable `origin_source:{path,sha256,size}` and `origin_span:{first_line,last_line}`. Those expected values are **comparison-only fixture data**. Catalog2 wraps the same typed payload plus its source binding. Notes and other schema1 records are rejected in schema2; schema1 remains a separate unchanged path.

Before constructing either backend, common stdlib code reauthenticates exact origin bytes, direct syntactic subject, physical span, prefix text and truncation. It prepares each module once, retains only one prepared module at a time, and performs one final source recheck per distinct module. A tampered expected tuple fails before CAMI state/backend creation.

CAMI gets context through `context_many`; one certain exact Python fact and ready certificate are required. Registration constructs `RememberInput(kind,query,context,request_id)` only. It NEVER supplies expected, text, note_key, span or source as registration fields. The core derives its payload from authenticated context/CAS; after registration the adapter compares the complete server-derived payload with the frozen catalog. Portable normalization drops **only** `origin_source.index`; path/hash/size, expected and origin span remain intact.

Static preparation has no CAMI imports. Static results remain `unchecked_current` with `origin_literal_source_assertion`. Supported CAMI literal records use `validated_literal_source`; withheld summaries contain no historical payload. Ranking is shared before availability: same exact ID/selector priority, identity weight4/content weight1, stable ID tie-break and16KiB original-record budget. Literal content tokens come from `payload.expected.text`; schema1 still uses unchanged `payload.text/note_key`. No unavailable record is replaced with another result.

Binding and model-wire envelope remain schema1, independently of seed/catalog2. Optional compact projection is copied from the reviewed candidate, defaults to full, and preserves all new payload fields (expected text/truncation, source path/hash/size and span). Full/compact share the same origin-record selection budget.

The shared new-version TOOL description explicitly distinguishes unchecked/manual/literal scope, certifies only the displayed prefix and truncation under the verified readset, says “not behavior”, and recommends native tools for missing code/context. This metadata change applies equally to both memory arms and is **not** backward-identical v3 model behavior. Legacy note payload bytes, meaning/ranking and default-full lookup response remain unchanged.

## Literal extraction and selection

`seed_source_literals_v2.py` is a new stdlib-only generator. It enumerates the same direct public functions/methods plus `__init__/__call__`, excludes ambiguous duplicate direct names and skips vendor/symlink/special/oversize inputs. It does not inspect outcomes or execute source. This is syntactic candidate enumeration, not an independent production-binding oracle; CAMI preflight must accept every frozen exact subject or the cohort fails closed. No automatic outcome-based replacement/subset selection is provided.

Strict UTF8 only: BOM and non-UTF8 encoding cookies are unsupported, including ASCII-only Latin1-cookie files. Cookie detection examines the first two physical CRLF/LF/CR byte lines. Raw physical text is preserved; exotic separators remain characters. The region includes the lexical opening `@` of the first decorator through the full definition end physical line, including indentation/comments/terminator. Prefix length is2400 Python Unicode characters and comparison includes `truncated`.

Parenthesized decorators require lexical association: AST decorator lineno can start after `@(`. The scanner tokenizes one normalized-newline view per module solely for coordinates, associates leading decorator statements with headers/suites, rejects inconsistent counts, and extracts from untouched physical lines. Strings/matrix `@` and class decorators cannot leak into function starts. Old generator1/analyzer semantics remain unchanged. The core v2 producer independently matched30 authored tuple/span variants (LF/CRLF/CR); its report pins this exact `literal_source.py`.

The new tuple is literal source evidence only. It does not establish full-body equivalence when truncated, semantic/behavioral/API compatibility, effects of changed globals, or model causal reliance.

## Use and verification

Install all six runtime/generator files together beside the adapter: `memory_adapter.py`, `memory_backend.py`, `compact_response.py`, `literal_source.py`, `literal_catalog.py`, `seed_source_literals_v2.py`. Existing frozen bundles are not edited.

```sh
python seed_source_literals_v2.py --repo CANONICAL_ORIGIN --source-root src/pkg --out NEW_SEED_DIR
python memory_adapter.py prepare --backend static --repo CANONICAL_ORIGIN --seed-spec NEW_SEED_DIR/seed-spec.json --out NEW_STATIC
python memory_adapter.py prepare --backend cami --repo CANONICAL_ORIGIN --seed-spec NEW_SEED_DIR/seed-spec.json --state-home NEW_STATE --out NEW_CAMI
python memory_adapter.py serve --binding NEW_CAMI/binding.json --trace NEW_TRACE.jsonl
# Optional, explicit common choice for both memory arms in a future study:
python memory_adapter.py serve --binding NEW_CAMI/binding.json --trace NEW_TRACE.jsonl --response-format compact
```

Twenty-seven fast authored stdlib/fake-core controls pass in about0.06seconds; Ruff passes. They cover exact Unicode boundaries, truncation tamper, all newline forms and lexical decorators, imports/limits/policy, content ranking and budget, identical catalogs/server-derived registration comparison, withholding, schema1 golden bytes and real static stdio.

`authored-cli-v1/report.json` passes the actual new generator→static preparation→full/compact stdio path on an authored CRLF parenthesized-decorator source. No CAMI/core calls occur there.

After root opened a quiet correctness window, real staged core-v2 integration passed in isolated `product-memory-check-v1` and expanded `product-memory-check-v2` (both retained). Expanded v2 records seven groups: same catalog bytes and literal label; actual both-arm full/compact content retrieval and16KiB budget; frozen expected tamper denied before CAMI state creation; unrelated edit/line shift retention; unchanged schema1 manual-note policy; decorator-opening-only change withheld while static stays unchecked; full/compact withheld responses preserve IDs without historical content. No source under test is executed; no model/Docker/heldout use. These are correctness checks, not performance measurements, especially while other correctness tests overlap.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s runs/opencode-literal-adapter-development-20261104 -p test_literal_adapter.py -v
.venv/bin/ruff check runs/opencode-literal-adapter-development-20261104/*.py
# Default prints a plan and performs zero core calls:
python check_product_memory_quiet.py
# Explicit authored real core integration, new output, only in a quiet window:
python check_product_memory_quiet.py --run --core-source ABS_CORE_V2_SRC --out NEW_STAGE_DIR
```

The first pure budget fixture incorrectly expected one matched record: the common `literal` ID token also matches a second record. Exact match still sorted first and budget withholding was correct. That authored fixture failure is preserved separately and corrected; no measured trial was retried.

See `protocol-changes.json` for required future driver/seed/format/reference changes. `reviewable.patch` is an exact applicable source patch; `semantic-review.patch` normalizes AST formatting for review only. `handoff-manifest.json` pins implementation, baseline, actual checks and external core/extractor evidence.
