def _identity(fn):
    return fn
@ (
    _identity
)
def alpha():
    return 1

def beta():
    return 2
