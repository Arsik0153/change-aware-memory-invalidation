"""Independent pure overlay controls; no real bundle, outcomes, model or Docker."""

import copy
import importlib.machinery
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = next(p for p in Path(__file__).resolve().parents if (p / "src/cami").is_dir())
STAGE = ROOT / "runs/opencode-literal-controller-development-20261104"
BASELINE = ROOT / "scripts/opencode_benchmark/controller"
sys.path[:0] = [str(STAGE), str(BASELINE)]
import preparation_worker as worker  # noqa: E402
import study_schema as schema  # noqa: E402
import study_runtime as runtime  # noqa: E402
from memory_seed_schema import literal_catalog  # noqa: E402
from study_common import digest, read  # noqa: E402


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")))


class ReviewControls(unittest.TestCase):
    def test_actual_import_resolution_uses_adapter_helper_for_prepare(self):
        commands, environments = worker.preparation_commands(
            "static", ["src/pkg"], 2, {"PYTHONPATH": "/workspace", "PYTHONSAFEPATH": "0"}
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            generator, adapter = root / "generator", root / "adapter"
            generator.mkdir()
            adapter.mkdir()
            for directory in (generator, adapter):
                (directory / "literal_source.py").write_text(
                    'raise RuntimeError("must not execute fixture")\n'
                )
            paths = {"/opt/literal-generator": str(generator), "/opt/memory-adapter": str(adapter)}
            resolved = []
            for environment in environments:
                search = [paths.get(p, p) for p in environment["PYTHONPATH"].split(":")]
                spec = importlib.machinery.PathFinder.find_spec("literal_source", search)
                resolved.append(Path(spec.origin).parent)
                self.assertEqual(environment["PYTHONSAFEPATH"], "1")
                self.assertNotIn("/workspace", environment["PYTHONPATH"])
            self.assertEqual(resolved, [generator, adapter])
            self.assertNotIn("--state-home", commands[1])

    def test_new_helper_tamper_denies_frozen_execute_validation(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            controller, harness, production, adapter, bundle = (
                root / name for name in ["controller", "harness", "production", "adapter", "bundle"]
            )
            for directory in (controller, harness, production, adapter, bundle):
                directory.mkdir()
            for name in [
                "study_controller",
                "study_schema",
                "study_common",
                "study_workspace",
                "study_runtime",
                "study_ledger",
                "preparation_worker",
                "fixed_grader",
                "memory_seed_schema",
                "memory_format_evidence",
            ]:
                (controller / (name + ".py")).write_text("# authored controlled source\n")
            for name in [
                "container_session",
                "container_worker",
                "container_common",
                "evidence_safety",
                "trial_guards",
            ]:
                (harness / (name + ".py")).write_text("# authored controlled source\n")
            (harness / "boundary-sentinel.txt").write_text("authored")
            (production / "__init__.py").write_text("")
            (adapter / "memory_adapter.py").write_text("# authored\n")
            binary = root / "binary"
            binary.write_bytes(b"not executed")
            pins = {
                key: {"root": str(path), "files": function(path)}
                for key, path, function in [
                    ("controller", controller, schema.controller_files),
                    ("harness", harness, schema.harness_files),
                    ("production", production, schema.runtime_files),
                    ("adapter", adapter, schema.runtime_files),
                ]
            }
            normalized = {"asset_hashes": {}}
            study = {
                "schema_version": 1,
                "arms": list(schema.ARMS),
                "repetitions": 3,
                "model": schema.MODEL,
                "timeout_seconds": 900,
                "max_steps": 20,
                "reported_token_budget": 1000000,
                "image": "sha256:" + "a" * 64,
                "execution_authorized": True,
                "binary_path": str(binary),
                "binary_sha256": digest(binary),
                "bundle_path": str(bundle),
                "bundle_kind": "authored",
                "normalized": normalized,
                "pins": pins,
                "memory_response_format": "full",
            }
            manifest = root / "runtime.json"
            save(
                manifest,
                {
                    "image_id": study["image"],
                    "binary_sha256": study["binary_sha256"],
                    "cami_files": pins["production"]["files"],
                    "adapter_files": pins["adapter"]["files"],
                },
            )
            study.update(
                runtime_manifest_path=str(manifest), runtime_manifest_sha256=digest(manifest)
            )
            with patch.object(schema, "normalize", return_value=normalized):
                schema.validate(study, execute=True)
                (controller / "memory_seed_schema.py").write_text("# changed helper\n")
                with self.assertRaisesRegex(ValueError, "sealed file mismatch"):
                    schema.validate(study, execute=True)

    def test_rehashed_literal_expectation_and_legacy_note_conversion_denied(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            bundle, memory = root / "bundle", root / "memory"
            subject = {
                "language": "python",
                "path": "src/pkg/m.py",
                "qualname": "f",
                "node_kind": "function",
            }
            source = {"path": subject["path"], "sha256": "a" * 64, "size": 20}
            seed = {
                "schema_version": 2,
                "source_roots": ["src/pkg"],
                "excluded_paths": [],
                "records": [
                    {
                        "id": "f-id",
                        "kind": "source_excerpt_equals",
                        "selector": "src/pkg/m.py:f",
                        "subject": subject,
                        "expected": {
                            "format": "python.definition-prefix/1",
                            "text": "def f(): return 1\n",
                            "truncated": False,
                        },
                        "origin_source": source,
                        "origin_span": {"first_line": 1, "last_line": 1},
                    }
                ],
            }
            policy = {
                "schema_version": 2,
                "seed": "seed.json",
                "generator": "seed_source_literals_v2.py",
                "helpers": ["literal_source.py"],
                "payload_kind": "source_excerpt_equals",
                "extractor_format": "python.definition-prefix/1",
            }
            study = {
                "bundle_path": str(bundle),
                "normalized": {"seed": "seed.json", "memory_source": policy},
            }
            save(bundle / "seed.json", seed)
            save(memory / "seed/seed-spec.json", seed)
            original = literal_catalog(seed)
            binding = {
                "backend": "static",
                "repo": "/workspace",
                "catalog_path": "/memory/prepared/catalog.json",
                "state_home": None,
            }

            def bind(catalog):
                save(memory / "prepared/catalog.json", catalog)
                value = json.dumps(
                    catalog,
                    sort_keys=True,
                    ensure_ascii=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ).encode()
                save(
                    memory / "prepared/binding.json",
                    dict(binding, catalog_sha256=runtime.hashlib.sha256(value).hexdigest()),
                )

            bind(original)
            runtime.verify_memory(study, memory, "static")
            for transform in ("text", "span", "note"):
                altered = copy.deepcopy(original)
                if transform == "text":
                    altered["records"][0]["payload"]["expected"]["text"] = "forged literal"
                elif transform == "span":
                    altered["records"][0]["payload"]["origin_span"]["first_line"] = 2
                else:
                    altered["records"][0]["payload"]["type"] = "note"
                bind(altered)
                with self.assertRaisesRegex(ValueError, "schema2 catalog differs"):
                    runtime.verify_memory(study, memory, "static")
            self.assertEqual(read(bundle / "seed.json"), seed)

    def test_schema1_commands_keep_original_generator_and_backend_state_boundary(self):
        commands, environments = worker.preparation_commands("static", ["src/pkg"], 1, {})
        self.assertEqual(commands[0][1], "/opt/seed_source_notes.py")
        self.assertEqual(environments[0], environments[1])
        self.assertNotIn("/opt/literal-generator", environments[1]["PYTHONPATH"])
        self.assertNotIn("--state-home", commands[1])
        cami, _ = worker.preparation_commands("cami", ["src/pkg"], 1, {})
        self.assertEqual(cami[1][-2:], ["--state-home", "/memory/cami-state"])


if __name__ == "__main__":
    assert all(
        Path(module.__file__).resolve().parent == STAGE for module in (worker, schema, runtime)
    )
    unittest.main()
