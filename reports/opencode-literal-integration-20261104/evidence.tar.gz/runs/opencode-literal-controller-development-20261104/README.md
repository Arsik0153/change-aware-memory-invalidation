# Literal source catalog2 controller staging

This directory contains a four-module overlay on the installed format-selection stage5 controller. It adds explicit catalog2 generation and exact frozen tuple verification. It preserves the absent-policy schema1 route and the frozen full/compact selector and actual published-format observer. Nothing here launches a model.

Install only `study_runtime.py`, `study_schema.py`, `preparation_worker.py`, and new `memory_seed_schema.py` into `scripts/opencode_benchmark/controller/`. `controller-schema2.patch` is based on the exact installed hashes in `baseline-pins.json`. The focused `test_literal_controller.py` may be installed alongside the existing tests. The separate correctness runner and worker may stay here; they are not study runtime modules.

The schema2 memory policy lives in `devbundle-v2/memory-source.json`. The bundle preserves all 15 original development assets byte-for-byte, including the unused schema1 generator and seed. Only the explicit policy selects the new versioned generator, helper, and seed. The new seed has 329 literal records from 16 modules at the exact original first-stage source archive. `devbundle-manifest.json` binds every file, original-asset preservation, generator, and seed. This is a new development package, not a reinterpretation of completed v3 results. No model results or held-out source informed these changes.

Generation mounts only the named script and helper read-only, with trusted imports and safe-path enabled. Adapter preparation receives a distinct trusted environment without the generator directory, so its own pinned helper is executed. Generation must reproduce the complete frozen seed byte hash before preparation. Schema2 verification compares the entire portable catalog to the frozen seed: literal text/truncated tuple, subject, source path/hash/size, span, and source policy. Caller expected/text is never passed as registration input; adapter/core derive and authenticate it separately.

## Fast authored checks

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s runs/opencode-literal-controller-development-20261104 -p 'test_literal*.py'
.venv/bin/ruff check runs/opencode-literal-controller-development-20261104/{study_runtime.py,study_schema.py,preparation_worker.py,memory_seed_schema.py,literal_stdio_worker.py,verify_literal_containers.py,test_literal_controller.py,test_literal_stdio.py}
```

Nineteen focused checks cover the two schema routes, exact catalog2/CAMI mapping and rehashed expected/source/span/kind mutations, safe command/import routing and mounts, unchanged old normalization/assets, and actual wire-response validation controls. `existing-controller-compatibility.json` records the separate 23 legacy controller checks against this overlay. All checks are authored or operate only on the already frozen development bundle; none calls a container, model, or held-out evaluator.

## Actual configured-container correctness

Default is a pure plan with no controller import, writes, or Docker:

```sh
.venv/bin/python runs/opencode-literal-controller-development-20261104/verify_literal_containers.py
```

After root installs the overlay and builds a study JSON pinning the installed schema2 controller, core, adapter, runtime, and new development bundle:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python runs/opencode-literal-controller-development-20261104/verify_literal_containers.py \
  --run --study /ABSOLUTE/PATH/TO/PINNED-SCHEMA2-STUDY.json \
  --controller-dir "$PWD/scripts/opencode_benchmark/controller" \
  --out "$PWD/runs/opencode-literal-configured-containers-20261104-v1"
```

The output must be NEW under `runs/`; no prior attempt is deleted or reused. The runner verifies the complete study pins without requiring model authorization, materializes the exact original base archive as a fresh one-commit repository independently for static and CAMI, and runs the installed `origin_memory` preparation. It checks global catalog byte parity and exercises the exact MCP command/environment produced by the pinned harness configuration for static/CAMI × full/compact. The mounted stdlib worker sends initialize, initialized, tools/list, and a deterministic ID lookup via actual stdio, checks labels and literal payload preservation, shared 16KiB origin-record budget, one joined backend event, actual format markers, and exact unsanitized compact audit receipts. Preparation/container/cgroup/cleanup records, raw stdio, backend traces, and all hashes are retained.

This checks configured MCP transport and preparation, not an OpenCode model conversation, task quality, speed, or behavioral correctness. The runner never invokes OpenCode, auth, model APIs, task tests, or gold fixtures. Its four probes use one deterministic origin record; full-population parity and schema verification cover all 329 catalog records. Costs are correctness evidence only and may overlap other work. Failed attempts remain intact. Do not use this runner during a source snapshot that root says must remain untouched; it writes only its new ignored output directory.
