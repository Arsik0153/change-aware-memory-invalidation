"""Independent pure selector review controls. No Docker, authentication, or models."""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'src/cami').is_dir())
STAGE = ROOT / 'runs/opencode-format-selection-development-20261104'
sys.path[:0] = [str(STAGE / 'controller'), str(STAGE / 'harness')]
import study_runtime as runtime  # noqa:E402
import study_schema as schema  # noqa:E402
import study_controller as controller  # noqa:E402
import container_session as harness  # noqa:E402


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def acceptance_control(selected):
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        out = root / 'session'
        (out / 'evidence').mkdir(parents=True)
        # All evidence is authored. Wrong model-visible format, correct declared
        # selection/config, demonstrates precisely what the selector checks.
        payload = {'schema_version': 1, 'backend': 'static', 'entries': [], 'withheld': []}
        if selected == 'full':
            payload.update(response_format='research-memory-compact/1', audit_receipt='a' * 64)
        else:
            payload['catalog_sha256'] = 'b' * 64
        messages = [{'type': 'assistant', 'content': [{'type': 'tool', 'name': 'research_memory_memory_lookup',
                     'state': {'status': 'completed', 'content': [{'type': 'text', 'text': json.dumps(payload)}]}}]}]
        (out / 'evidence/messages.json').write_text(json.dumps(messages))
        config = harness.configuration('static', 'prepared/binding.json', selected)
        (out / 'effective-input-config.json').write_text(json.dumps(config))
        manifest = {'status': 'passed', 'image_id': 'authored', 'model_requested': True,
                    'memory_response_format': selected,
                    'artifact_hashes': {'evidence/messages.json': digest(out / 'evidence/messages.json'),
                                        'effective-input-config.json': digest(out / 'effective-input-config.json')}}
        (out / 'manifest.json').write_text(json.dumps(manifest))
        study = {'harness': 'never-executed', 'runtime_manifest_path': 'never-read', 'reported_token_budget': 1000000,
                 'image': 'authored', 'cami_source': 'never-read', 'adapter': 'never-read', 'model': config['model'],
                 'memory_response_format': selected}
        with patch.object(runtime, 'command', return_value={'returncode': 0, 'timeout': False, 'stdout': '', 'stderr': ''}):
            accepted = runtime.session(study, {'arm': 'static'}, root, root, root, out)
        return {'selected_format': selected, 'model_visible_format': 'compact' if selected == 'full' else 'full',
                'accepted': accepted['status'] == 'passed', 'evidence_hashes_valid': True,
                'scope': 'pure forged-evidence control, not an observed production adapter defect'}


def main():
    output = Path(__file__).parent
    findings = {'wrong_wire_format_controls': [acceptance_control(x) for x in ['full', 'compact']],
                'imports_completed': ['study_schema', 'study_runtime', 'study_controller', 'container_session'],
                'legacy_default': schema.memory_response_format({}), 'model_calls': 0, 'docker_calls': 0, 'auth_calls': 0}
    # Run existing authored controller contracts against the staged modules,
    # avoiding import/discovery accidentally selecting installed runtime code.
    spec = importlib.util.spec_from_file_location('existing_controller_review_contracts', ROOT / 'scripts/opencode_benchmark/controller/test_controller.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    findings['existing_controller_contracts'] = {'tests': result.testsRun, 'passed': result.wasSuccessful(), 'log': stream.getvalue(),
        'resolved_runtime': runtime.__file__, 'resolved_schema': schema.__file__, 'resolved_controller': controller.__file__}
    with (output / 'review-controls.json').open('x') as handle:
        json.dump(findings, handle, indent=2, sort_keys=True)
        handle.write('\n')
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
