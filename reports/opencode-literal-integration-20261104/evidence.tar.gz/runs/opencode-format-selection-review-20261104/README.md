# Independent frozen response-format selector review

Reviewed only the staged selector and relevant interface source. No staged/installed/frozen source bytes were changed, and no Docker, models, authentication, heldout source or heldout outcomes were accessed. Output is confined to this ignored review directory.

**Verdict:** routing is coherent; one material response-evidence gap remains before a future compact study. This is a missing validation path demonstrated with authored evidence, not an observed production adapter misformatting defect.

## F1 — Actual completed MCP format is not verified (medium)

`controller/study_runtime.py:221` validates the memory command in the harness-written `effective-input-config.json`; `session()` at lines275–284 checks the declared manifest and that file. It does not inspect completed MCP results in published `evidence/messages.json` or reconcile their format with backend lookup trace evidence.

`review_controls.py` preserves two pure authored controls with valid artifact hashes: selected compact + full-format MCP text is accepted, and selected full + compact-marked MCP text is accepted. See `review-controls.json`. No real subprocess/session/model/container was launched by those controls.

The existing `controller/authored_integration.py` at lines95–105 creates its default-full study, and lines134–159 call the harness without a response-format argument. Its no-model sessions start/connect MCP but issue no memory lookup. Consequently that unchanged integration can preserve legacy compatibility but cannot establish that the compact choice reaches an actual model-facing response. The staged handoff already acknowledges a future real integration prerequisite.

Minimal correction: keep the frozen common selector and exact command check, then separately verify and record **observed** completed-response format from published messages + backend lookup trace. Do not label configuration intent as observed response evidence. Zero completed lookups must be explicit `not_observed`, distinct from a positive format match; errored/unparseable/truncated lookups must remain explicit too.

## Concrete pinned API/schema expectations

The pinned aggregated OpenCode API uses an array of messages. Memory observations are assistant `content` parts with `type:"tool"`, name `memory_lookup` or a name ending `_memory_lookup`, and `state.status:"completed"`. A complete result has one text block in `state.content`; parse its `text` JSON. `state.metadata.truncated:true` prevents authenticating a complete result. Keep the part's unique `id` as the call identity. A transport truncation flag differs from the memory payload's legitimate selection-budget `truncated` flag.

The optional adapter candidate's compact payload always has `response_format:"research-memory-compact/1"` and a64-hex `audit_receipt`, including compact error responses. Its corresponding backend `event:"memory_lookup"` row has `response_format:"compact"` and `response_audit.receipt_sha256` matching that marker receipt; `receipt_payload.format` names the same compact schema. The full branch preserves legacy model bytes and trace shape: no compact marker/receipt in the payload and no compact format/audit fields on the lookup event. Check a valid memory envelope (`schema_version`, returned/withheld collections or explicit error shape), rather than treating arbitrary JSON without a marker as proof of full format.

Backend `query_sha256` binds canonical **complete tool arguments**, including an explicit limit when supplied; it is not SHA(query text). Compact receipts provide a direct correlation key. Do not rely on unqualified message order for associating concurrent/repeated calls.

Marker verification and exact receipt verification are separate claims. Publication scrubbing can change note/error text after receipt generation. A marker/receipt-reference match does not prove that published text still has its pre-scrub digest. Preserve `receipt_verification:not_checked_after_scrub` or an equivalent explicit result; do not silently rebind hashes or blindly fail an authorized scrub. The exact receipt audit retains the complete MCP result including `isError`; that is a different boundary from checking the selected wire-format marker.

A useful small result shape is requested format, completed-observation count, per-call visible/trace markers and match status, overall `matched`/`mismatch`/`not_observed`/`unsupported`, plus a separate receipt-integrity status. Plain remains not applicable to external-memory responses.

Minimal additional pure controls: compact/full mismatch in both directions; missing/malformed/truncated observation; zero completed calls; both memory arms; compact error response; marker evidence that remains valid when published text was scrubbed, without claiming pre-scrub receipt verification. After v3 finishes, a separately owned no-model integration should run an actual lookup through each configured full/compact server command for static and CAMI and verify markers. That proves routing/format mechanics, not OpenCode model benefit, tokens, quality or speed.

## Checks that passed

- All24 staged handoff inventory hashes match, and exactly the four declared runtime files differ from baseline pins (`source-checks.json`).
- All25 staged selector tests pass on independent rerun (0.13 seconds).
- All23 existing authored controller contracts pass against the staged runtime/schema/controller modules (`review-controls.json`,0.8seconds including temporary local Git fixtures).
- The new import graph is acyclic: runtime → schema → common; controller → runtime/schema. Existing positional `make_study` calls retain full defaults.
- One common frozen field feeds every controller session; loaded-study CLI attempts are rejected before reading study/source files. Both memory arms receive the same format. Plain's configuration stays unchanged; its manifest records the common requested setting, not an observed plain memory response.
- Runtime source inventories still bind the entire adapter directory. A future installed compact adapter must include/pin `compact_response.py` and a corresponding new runtime manifest; the current frozen v3 runtime remains untouched.

No other material routing or compatibility defect was found. The two earlier authored-test fixture failures documented in the staged handoff remain preserved and were not mistaken for successful runs.
