"""Independent authored API controls; no ProductMemory, Git or target execution."""
import builtins
import copy
import hashlib
import importlib.util
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[2]
STAGE = ROOT / "runs/opencode-literal-adapter-development-20261104"
sys.path.insert(0, str(STAGE))
import memory_backend as candidate  # noqa: E402
from literal_catalog import catalog_from_seed2, reauthenticate  # noqa: E402
from seed_source_literals_v2 import build  # noqa: E402


def fixture(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "m.py").write_text("# authored only\n@(\n decorator\n)\ndef f():\n    return 1\n")
    seed, _ = build(repo, ["."])
    assert len(seed["records"]) == 1
    return repo, seed


@pytest.mark.parametrize("field", ["expected_text", "truncated", "span", "source_hash", "source_size", "node_kind"])
def test_forged_comparison_refused_before_cami_import_and_state_creation(tmp_path, monkeypatch, field):
    repo, seed = fixture(tmp_path)
    item = seed["records"][0]
    if field == "expected_text":
        item["expected"]["text"] += "forged"
    elif field == "truncated":
        item["expected"]["truncated"] = True
    elif field == "span":
        item["origin_span"]["first_line"] += 1
    elif field == "source_hash":
        item["origin_source"]["sha256"] = "0" * 64
    elif field == "source_size":
        item["origin_source"]["size"] += 1
    else:
        item["subject"]["node_kind"] = "method"
    spec = tmp_path / "seed.json"
    candidate.save(spec, seed)
    original = builtins.__import__
    def blocked(name, *args, **kwargs):
        if name == "cami" or name.startswith("cami."):
            raise AssertionError("CAMI import before rejecting a forged tuple")
        return original(name, *args, **kwargs)
    monkeypatch.setattr(builtins, "__import__", blocked)
    state = tmp_path / "state"
    with pytest.raises(ValueError):
        candidate.prepare("cami", repo, tmp_path / "out", spec_path=spec, state_home=state)
    assert not state.exists()


def test_schema2_rejects_note_conversion_or_full_index_from_caller(tmp_path):
    repo, seed = fixture(tmp_path)
    changed = copy.deepcopy(seed)
    changed["records"][0]["kind"] = "note"
    with pytest.raises(ValueError):
        catalog_from_seed2(changed)
    changed = copy.deepcopy(seed)
    changed["records"][0]["origin_source"]["index"] = {"untrusted": "caller"}
    with pytest.raises(ValueError):
        reauthenticate(repo, changed, seed=True)
    catalog, _ = reauthenticate(repo, seed, seed=True)
    assert catalog["records"][0]["payload"]["expected"]["text"].startswith("@(\n")


def test_schema1_full_lookup_bytes_equal_frozen_batch_v2_baseline(tmp_path):
    repo, _ = fixture(tmp_path)
    raw = (repo / "m.py").read_bytes()
    source = {"path": "m.py", "sha256": hashlib.sha256(raw).hexdigest(), "size": len(raw)}
    payload = {"type": "note", "subject": {"language": "python", "path": "m.py", "qualname": "f", "node_kind": "function"},
               "note_key": "unchanged-key", "text": "Complete arbitrary manual prose π\n@header remains prose.", "sources": [source]}
    catalog = {"schema_version": 1, "source_roots": ["."], "excluded_paths": [],
               "records": [{"id": "legacy-note", "payload": payload, "source": source}]}
    path = tmp_path / "catalog.json"
    candidate.save(path, catalog)
    baseline_path = ROOT / "runs/opencode-runtime-development-20261104/batch-v2/extracted/integrations/opencode/memory_backend.py"
    assert baseline_path.is_file(), "frozen baseline required for this explicit compatibility control"
    spec = importlib.util.spec_from_file_location("review_legacy_backend", baseline_path)
    baseline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(baseline)
    responses = []
    for name, module in [("baseline", baseline), ("candidate", candidate)]:
        output = tmp_path / name
        module.prepare("static", repo, output, catalog_path=path)
        response, _ = module.Backend(output / "binding.json").lookup("legacy-note", 1)
        responses.append(module.canonical(response))
    assert responses[0] == responses[1]
