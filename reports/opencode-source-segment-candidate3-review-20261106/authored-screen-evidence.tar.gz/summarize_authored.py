"""Verify retained diagnostic versions and apply the prospective resource/time rules."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
CASES = ["early_function_large_multiline_literal", "early_function_blank_tail"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def stats(values):
    return {
        "n": len(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "range": max(values) - min(values),
        "samples": values,
    }


def comparison(before, after, memory=False):
    a, b = stats(before), stats(after)
    increase = b["median"] - a["median"]
    noise = max(a["range"], b["range"])
    row = {
        "candidate2": a,
        "candidate3": b,
        "median_increase": increase,
        "relative_median_increase": increase / a["median"],
        "paired_candidate3_minus_candidate2": [y - x for x, y in zip(before, after, strict=True)],
        "noise_threshold": noise,
    }
    if memory:
        row["material_memory_regression"] = (
            increase > max(1048576, noise) and increase >= 0.05 * a["median"]
        )
        row["material_threshold_bytes"] = max(1048576, noise)
    else:
        row["classification"] = (
            "no_measurable_difference"
            if abs(increase) <= noise
            else "slower_candidate3_in_authored_diagnostic"
            if all(y > x for x, y in zip(before, after, strict=True))
            else "inconclusive_nonuniform_deltas"
        )
    return row


def main():
    original, repaired = (
        read(HERE / "authored-screen-v1/report.json"),
        read(HERE / "authored-screen-v2/report.json"),
    )
    assert (
        original["status"] == "failures_preserved"
        and len(original["failures"]) == len(original["attempts"]) == 20
    )
    assert all(row["result"]["error"] == "TypeError: frozenset" for row in original["attempts"])
    assert (
        repaired["status"] == "passed"
        and len(repaired["attempts"]) == 20
        and not repaired["failures"]
    )
    for name, report in [("authored-screen-v1", original), ("authored-screen-v2", repaired)]:
        for path, expected in report["artifact_hashes"].items():
            assert sha(HERE / name / path) == expected
    repair = read(HERE / "repair-check-v2/result.json")
    assert repair["status"] == "passed" and len(repair["cases"]) == 2
    expected_digest = {row["case"]: row["complete_module_sha256"] for row in repair["cases"]}
    plan = read(HERE / "prospective-authored-plan.json")
    outcome = {}
    for case in CASES:
        fixture = HERE / "authored-screen-v1/fixtures" / (case + ".py")
        raw = fixture.read_bytes()
        assert (
            sha(fixture) == plan["cases"][case]["sha256"]
            and len(raw) == plan["cases"][case]["bytes"]
        )
        tree = ast.parse(raw)
        assert sum(1 for _ in ast.walk(tree)) == plan["cases"][case]["expected_total_ast_nodes"]
        assert (
            sum(
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) for node in ast.walk(tree)
            )
            == 1
        )
        selected = {
            variant: [
                next(
                    row["result"]
                    for row in repaired["attempts"]
                    if row["block"] == block and row["case"] == case and row["variant"] == variant
                )
                for block in range(1, 6)
            ]
            for variant in ["candidate2", "candidate3"]
        }
        assert all(
            row["complete_module_sha256"] == expected_digest[case]
            and row["input_sha256"] == sha(fixture)
            for rows in selected.values()
            for row in rows
        )
        resources = {}
        for name, key in [
            ("parse_return_cgroup_peak_bytes", "cgroup_peak_bytes_lifetime"),
            ("parse_return_process_rss_peak_bytes", "rss_peak_kib_self_lifetime"),
        ]:
            multiplier = 1024 if "rss" in name else 1
            resources[name] = comparison(
                [row["at_parse_return_memory"][key] * multiplier for row in selected["candidate2"]],
                [row["at_parse_return_memory"][key] * multiplier for row in selected["candidate3"]],
                memory=True,
            )
        for key in ["parse_wall_seconds", "parse_cpu_seconds"]:
            resources[key] = comparison(
                [row[key] for row in selected["candidate2"]],
                [row[key] for row in selected["candidate3"]],
            )
        resources["post_gc_current_bytes_descriptive"] = {
            variant: stats(
                [row["after_explicit_gc_memory"]["cgroup_current_bytes"] for row in rows]
            )
            for variant, rows in selected.items()
        }
        outcome[case] = {
            "input_sha256": sha(fixture),
            "input_bytes": len(raw),
            "complete_module_sha256": expected_digest[case],
            "expected_ast_nodes_verified": sum(1 for _ in ast.walk(tree)),
            "all_complete_module_fields_equal": True,
            "metrics": resources,
        }
    material = any(
        row["metrics"][key]["material_memory_regression"]
        for row in outcome.values()
        for key in ["parse_return_cgroup_peak_bytes", "parse_return_process_rss_peak_bytes"]
    )
    assert material
    freeze = read(HERE / "source-freeze.json")
    for variant in ["candidate2", "candidate3"]:
        for name, expected in freeze[variant + "_files"].items():
            assert sha(HERE / (variant + "-source") / name) == expected
    summary = {
        "status": "candidate3_material_authored_regression_confirmed",
        "decision": "STOP_candidate3_real_MCP_profiles_and_quiet_study_as_predeclared",
        "candidate3_functional_evidence_preserved": True,
        "candidate3_code_sha256": freeze["candidate3_files"]["cami/index.py"],
        "candidate2_code_sha256": freeze["candidate2_files"]["cami/index.py"],
        "outcomes": outcome,
        "accepted_measurements": {
            "version": "v2",
            "attempts": 20,
            "passed": 20,
            "failures": 0,
            "same_inputs_order_limits_thresholds": True,
        },
        "original_failed_measurements": {
            "version": "v1",
            "attempts": 20,
            "failed": 20,
            "eligible_passed_measurements": 0,
            "reason": "Post-parse completeModule JSON serializer omitted frozenset; metrics retained as secondary failed-verification observations only, not pooled.",
        },
        "untimed_repair_check": {
            "containers": 1,
            "complete_module_cases": 2,
            "nonempty_frozenset_control": "passed",
        },
        "total_diagnostic_containers_all_versions": 41,
        "real_MCP_candidate3_containers": 0,
        "plans": {
            "v1_sha256": sha(HERE / "prospective-authored-plan.json"),
            "v2_sha256": sha(HERE / "prospective-authored-plan-v2.json"),
        },
        "raw_reports": {
            "v1_sha256": sha(HERE / "authored-screen-v1/report.json"),
            "v2_sha256": sha(HERE / "authored-screen-v2/report.json"),
        },
        "published_candidate2_source_admission": repaired["published_baseline_admission"],
        "interpretation": [
            "Authored near-cap cases are not Click/heldout population estimates; they expose a valid below2MiB input regression.",
            "CPython3.12 source-segment helper bounds line collection to node end (may pull one extra regex match); candidate3 caches entire module.",
            "Phase memory observations precede digest/serialization; full-lifetime outer peaks remain in raw resources. RSS and cgroup peak are distinct nonadditive scopes.",
            "Post-GC memory observations do not prove allocator pages return to the OS or imply a RAM improvement.",
            "Complete Module fields match; this is resource/performance regression, not a semantic mismatch. Producer127tests and4Click index equivalence are preserved separately.",
            "A bounded incremental prefix buffer is a separate candidate; no candidate4 measurement or model call is admitted here.",
        ],
        "model_calls": 0,
        "target_source_executed": False,
        "tracked_edits_by_this_agent": False,
    }
    (HERE / "authored-verdict.json").write_text(
        json.dumps(summary, sort_keys=True, indent=2) + "\n"
    )
    print(json.dumps({"status": summary["status"], "outcomes": outcome}, indent=2))


if __name__ == "__main__":
    main()
