"""Untimed same-image complete-Module serializer/equality check; no target execution."""

import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

from authored_worker_v2 import encode
import cami.index as baseline
from cami.repository import Blob

spec = importlib.util.spec_from_file_location(
    "candidate3_repair_reference", "/candidate3/cami/index.py"
)
candidate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = candidate
spec.loader.exec_module(candidate)
results = []
for path in sorted(Path("/fixtures").glob("*.py")):
    raw = path.read_bytes()
    assert len(raw) == 1835008
    blob = Blob("authored.py", hashlib.sha256(raw).hexdigest(), "100644", raw, None)
    outputs = []
    for module in [baseline, candidate]:
        value = module.parse_module(blob, "authored")
        assert value.limitation is None and len(value.definitions) == 1
        normalized = json.dumps(
            dataclasses.asdict(value),
            sort_keys=True,
            ensure_ascii=True,
            separators=(",", ":"),
            default=encode,
        ).encode()
        outputs.append(hashlib.sha256(normalized).hexdigest())
    assert outputs[0] == outputs[1]
    results.append(
        {
            "case": path.stem,
            "input_sha256": hashlib.sha256(raw).hexdigest(),
            "complete_module_sha256": outputs[0],
            "all_fields_equal": True,
        }
    )
assert len(results) == 2
assert json.loads(json.dumps(frozenset({"b", "a"}), default=encode)) == {
    "__frozenset__": ["a", "b"]
}
Path("/check/result.json").write_text(
    json.dumps(
        {
            "status": "passed",
            "cases": results,
            "frozenset_nonempty_control": "passed",
            "model_calls": 0,
            "target_source_executed": False,
            "timing_scope": "untimed correctness only",
        },
        indent=2,
    )
    + "\n"
)
