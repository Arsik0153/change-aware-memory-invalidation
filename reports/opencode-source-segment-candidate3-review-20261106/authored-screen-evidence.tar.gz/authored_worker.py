"""One fresh-process authored parse diagnostic; timed phase excludes digest/serialization."""

from __future__ import annotations

import argparse
import dataclasses
import gc
import hashlib
import json
from pathlib import Path
import resource
import time


def observe():
    return {
        "rss_peak_kib_self_lifetime": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "cgroup_current_bytes": int(Path("/sys/fs/cgroup/memory.current").read_text()),
        "cgroup_peak_bytes_lifetime": int(Path("/sys/fs/cgroup/memory.peak").read_text()),
    }


def encode(value):
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError(type(value).__name__)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    args = parser.parse_args()
    from cami.index import parse_module
    from cami.repository import Blob

    report = {"status": "started", "model_calls": 0, "target_source_executed": False}
    try:
        before_input = time.perf_counter()
        raw = Path("/input.py").read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert len(raw) == 1835008 and len(raw) < 2 * 1024**2
        blob = Blob("authored.py", digest, "100644", raw, None)
        gc.collect()
        report.update(
            case=args.case,
            input_sha256=digest,
            input_bytes=len(raw),
            input_read_hash_setup_seconds=time.perf_counter() - before_input,
            before_parse_memory=observe(),
        )
        started, cpu = time.perf_counter(), time.process_time()
        result = parse_module(blob, "authored")
        report.update(
            parse_wall_seconds=time.perf_counter() - started,
            parse_cpu_seconds=time.process_time() - cpu,
            at_parse_return_memory=observe(),
        )
        assert result.limitation is None and len(result.definitions) == 1
        after_parse = time.perf_counter()
        collected = gc.collect()
        report.update(
            post_parse_gc_seconds=time.perf_counter() - after_parse,
            gc_collected_objects=collected,
            after_explicit_gc_memory=observe(),
        )
        # Complete field digest after phase memory observations. No body copy is saved.
        started = time.perf_counter()
        normalized = json.dumps(
            dataclasses.asdict(result),
            sort_keys=True,
            ensure_ascii=True,
            separators=(",", ":"),
            default=encode,
        ).encode()
        report.update(
            complete_module_sha256=hashlib.sha256(normalized).hexdigest(),
            complete_module_json_bytes=len(normalized),
            module_field_names=[field.name for field in dataclasses.fields(result)],
            digest_verification_seconds=time.perf_counter() - started,
            after_digest_memory=observe(),
            definition_source_sha256=hashlib.sha256(
                result.definitions[0].source.encode()
            ).hexdigest(),
            status="passed",
        )
    except BaseException as error:
        report.update(status="failed", error=type(error).__name__ + ": " + str(error))
        raise
    finally:
        Path("/check/result.json").write_text(
            json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n"
        )


if __name__ == "__main__":
    main()
