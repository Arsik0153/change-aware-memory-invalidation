"""Deterministic near-cap parse-only diagnostics, never executed as target Python."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

TARGET_BYTES = 1835008  # 1.75MiB, below the frozen2MiB module input cap.
HEADER = b"def early():\n    return 1\n"


def cases():
    tail = b"# " + b"x" * 58 + b"\n"
    count, remainder = divmod(TARGET_BYTES - len(HEADER), len(tail))
    comments = HEADER + tail * count + (b"#" * (remainder - 1) + b"\n" if remainder else b"")
    assert len(comments) == TARGET_BYTES
    open_literal, close_literal = b'PAYLOAD = """\n', b'"""\n'
    body_size = TARGET_BYTES - len(HEADER) - len(open_literal) - len(close_literal)
    body_line = b"x" * 60 + b"\n"
    count, remainder = divmod(body_size, len(body_line))
    body = body_line * count + b"x" * remainder
    literal = HEADER + open_literal + body + close_literal
    blank = HEADER + b"\n" * (TARGET_BYTES - len(HEADER))
    late = tail * ((TARGET_BYTES - len(HEADER)) // len(tail))
    late += b"#" * (TARGET_BYTES - len(HEADER) - len(late) - 1) + b"\n"
    late += HEADER
    assert len(literal) == len(blank) == len(late) == TARGET_BYTES
    return {
        "early_function_many_short_comments": comments,
        "early_function_large_multiline_literal": literal,
        "early_function_blank_tail": blank,
        "late_function_comment_prefix_control": late,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    rows = {
        name: {
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "physical_lf_count": raw.count(b"\n"),
            "scope": "authored diagnostic only; not Click/heldout population",
        }
        for name, raw in cases().items()
    }
    if args.out:
        args.out.mkdir(parents=True, exist_ok=False)
        for name, raw in cases().items():
            (args.out / (name + ".py")).write_bytes(raw)
        (args.out / "manifest.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n")
    else:
        print(
            json.dumps(
                {"status": "metadata_only_no_target_parse_or_execution", "cases": rows}, indent=2
            )
        )


if __name__ == "__main__":
    main()
