"""Prospective small C2/C3 authored screening; requires explicit root fullsuite release."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CASES = ["early_function_large_multiline_literal", "early_function_blank_tail"]
ORDERS = [
    ["candidate2", "candidate3"] if index % 2 == 0 else ["candidate3", "candidate2"]
    for index in range(5)
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def admit_published_baseline(freeze):
    # Decompression/admission occurs only after explicit fullsuite release.
    archive = ROOT / freeze["candidate2_public_archive_path"]
    assert sha(archive) == freeze["candidate2_public_archive_sha256"]
    expected = freeze["candidate2_files"]
    with tarfile.open(archive, "r:gz") as stream:
        members = {member.name: member for member in stream.getmembers() if member.isfile()}
        prefixes = [
            name[: -len("cami/index.py")] for name in members if name.endswith("/cami/index.py")
        ]
        proven = None
        for prefix in prefixes:
            if all(prefix + name in members for name in expected):
                if all(
                    hashlib.sha256(stream.extractfile(members[prefix + name]).read()).hexdigest()
                    == value
                    for name, value in expected.items()
                ):
                    proven = prefix
                    break
        assert proven, "Published archive must contain complete exact candidate2 core prefix"
    return {
        "archive_sha256": sha(archive),
        "candidate2_complete_source_prefix": proven,
        "core_files_verified": len(expected),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument(
        "--root-release",
        help="Required explicit root release reference; elapsed time alone is not authorization",
    )
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(
            json.dumps(
                {
                    "status": "plan_only",
                    "containers": 20,
                    "cases": CASES,
                    "orders": ORDERS,
                    "requires": "root fullsuite release",
                    "model_calls": 0,
                }
            )
        )
        return
    if (
        not args.root_release
        or not args.out
        or args.out.exists()
        or not args.out.resolve().is_relative_to(HERE)
    ):
        parser.error("explicit --root-release and NEW output under stage required")
    if shutil.disk_usage(ROOT).free < 5 * 1024**3:
        raise ValueError("requires5GiB free disk")
    freeze = json.loads((HERE / "source-freeze.json").read_bytes())
    for variant in ["candidate2", "candidate3"]:
        for name, value in freeze[variant + "_files"].items():
            assert sha(HERE / (variant + "-source") / name) == value
    for name, value in freeze["controller_helper_snapshot"].items():
        assert sha(HERE / "controller-snapshot" / name) == value
    for name, value in freeze["adapter_snapshot"].items():
        assert sha(HERE / "frozen-adapter" / name) == value
    sys.path.insert(0, str(HERE / "controller-snapshot"))
    from study_common import bytes_used, chown, file_hashes
    from study_runtime import container
    from build_authored_cases import cases

    output = args.out.resolve()
    output.mkdir()
    report = {
        "status": "started",
        "root_release": args.root_release,
        "attempts": [],
        "failures": [],
        "model_calls": 0,
    }
    try:
        report["published_baseline_admission"] = admit_published_baseline(freeze)
        fixtures = output / "fixtures"
        fixtures.mkdir()
        raw_cases = cases()
        for name in CASES:
            (fixtures / (name + ".py")).write_bytes(raw_cases[name])
        save(
            output / "plan.json",
            {
                "root_release": args.root_release,
                "source_freeze_sha256": sha(HERE / "source-freeze.json"),
                "orders": ORDERS,
                "cases": {
                    name: {"bytes": len(raw_cases[name]), "sha256": sha(fixtures / (name + ".py"))}
                    for name in CASES
                },
                "worker_sha256": sha(HERE / "authored_worker.py"),
                "runner_sha256": sha(Path(__file__)),
                "timing_scope": "parse_module CPU/wall only; input/import/setup, digest/serialization/cleanup separately observed. Full container resources retain both phase and lifecycle peaks.",
                "memory_flag": "Candidate median rise>max(1MiB,within-side ranges) AND>=5%baseline for phase cgrouppeak or processRSS; do not infer RAM gain from fewer scans.",
                "proceed_to_MCP": "Only after root reviews authored screen; any material regression stops candidate3 MCP measurement.",
                "storage": "inputs stored once; no repeated source/module bodies per attempt; free>=5GiB and observed owned-stage target2GiB",
                "model_calls": 0,
            },
        )
        for block, order in enumerate(ORDERS, 1):
            for name in CASES:
                for variant in order:
                    case = output / f"b{block}-{name}-{variant}"
                    case.mkdir()
                    chown(case)
                    record = {"block": block, "case": name, "variant": variant, "status": "started"}
                    try:
                        result = container(
                            {"image": freeze["runtime_image"]},
                            [
                                (HERE / (variant + "-source"), "/opt/cami-src", True),
                                (HERE / "authored_worker.py", "/opt/authored_worker.py", True),
                                (fixtures / (name + ".py"), "/input.py", True),
                                (case, "/check", False),
                            ],
                            ["python", "/opt/authored_worker.py", "--case", name],
                            case / "container",
                            timeout=180,
                        )
                        record["container_status"] = result["status"]
                        record["result"] = json.loads((case / "result.json").read_bytes())
                        assert result["status"] == record["result"]["status"] == "passed"
                        record["status"] = "passed"
                    except BaseException as error:
                        record.update(
                            status="failed", error=type(error).__name__ + ": " + str(error)
                        )
                        report["failures"].append(record.copy())
                    report["attempts"].append(record)
                    save(output / "progress.json", report)
                    print(
                        json.dumps(
                            {
                                "block": block,
                                "case": name,
                                "variant": variant,
                                "status": record["status"],
                            }
                        ),
                        flush=True,
                    )
        assert len(report["attempts"]) == 20
        for block in range(1, 6):
            for name in CASES:
                pair = [
                    row
                    for row in report["attempts"]
                    if row["block"] == block and row["case"] == name
                ]
                if all(row["status"] == "passed" for row in pair):
                    assert (
                        pair[0]["result"]["complete_module_sha256"]
                        == pair[1]["result"]["complete_module_sha256"]
                    )
        report.update(
            status="passed" if not report["failures"] else "failures_preserved",
            owned_output_bytes=bytes_used(output),
            free_disk_bytes_after=shutil.disk_usage(ROOT).free,
        )
        assert (
            report["free_disk_bytes_after"] >= 5 * 1024**3
            and report["owned_output_bytes"] <= 2 * 1024**3
        )
    except BaseException as error:
        report.update(
            status="failed_preserved", fatal_error=type(error).__name__ + ": " + str(error)
        )
        raise
    finally:
        report["artifact_hashes"] = file_hashes(output)
        save(output / "report.json", report)


if __name__ == "__main__":
    main()
