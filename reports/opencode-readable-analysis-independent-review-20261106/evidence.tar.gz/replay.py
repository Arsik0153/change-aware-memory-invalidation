"""Derived format-only offline check of the complete sealed public24-call roster."""
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/opencode_benchmark/analysis'))
sys.path.insert(0, str(ROOT / 'scripts/opencode_benchmark/controller'))
from classify_literal_calls import authenticate_response, canonical, classify
from readable_receipts import verify_readable_result
from summarize_literal_staleness import load_controls


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(name, value):
    (OUT / name).write_bytes(canonical(value) + b'\n')


def main():
    roster_path = ROOT / 'runs/opencode-v6-independent-audit-20261106/memory-packet-roster.json'
    producer = ROOT / 'runs/opencode-readable-response-implementation-20261106/packets-final'
    previous_path = ROOT / 'runs/opencode-development-v6-final-staleness-20261106/report.json'
    previous = read(previous_path)
    inputs = {str(path.relative_to(ROOT)): sha(path) for path in [roster_path, previous_path]}
    catalog_path = Path(previous['inputs']['catalog_path'])
    catalog = read(catalog_path)
    inputs[str(catalog_path.relative_to(ROOT))] = sha(catalog_path)
    trees = [Path(path) for path in previous['inputs']['canonical_tree_sha256']]
    origin = next(path for path in trees if path.name == 'origin-and-stage1')
    stage3 = next(path for path in trees if path.name == 'stage3')
    controls = load_controls(ROOT / 'scripts/opencode_benchmark/analysis/summarize_terminal_staleness.py')
    before = {str(path): controls.inventory(path) for path in trees}
    spec = importlib.util.spec_from_file_location('readable_offline_normalizer', ROOT / 'scripts/analyze_opencode_staleness.py')
    analyzer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analyzer)
    roster = read(roster_path)['roster']
    assert len(roster) == 24
    observations = []
    totals = Counter()
    unique_obsolete = set()
    for number, row in enumerate(roster):
        packet_path = producer / f'packet-{number:03}.json'
        packet = read(packet_path)
        assert packet['source_roster_row'] == row
        messages_path, trace_path = ROOT / row['messages_path'], ROOT / row['backend_trace_path']
        for path, expected in [(messages_path, row['messages_sha256']),
                               (trace_path, row['backend_trace_sha256'])]:
            assert sha(path) == expected
            inputs[str(path.relative_to(ROOT))] = expected
        inputs[str(packet_path.relative_to(ROOT))] = sha(packet_path)
        messages = read(messages_path)
        events = [json.loads(line) for line in trace_path.read_bytes().splitlines() if line.strip()]
        event_index = row['backend_lookup_jsonl_line_one_based'] - 1
        event = events[event_index]
        full = event['response_audit']['full_result']
        assert digest(full) == row['full_result_sha256']
        assert packet['audit']['full_result'] == full
        original = json.loads(full['content'][0]['text'])
        assert verify_readable_result(packet['model_result'], packet['audit']) == original
        rows = analyzer.message_rows(messages)
        call = next(item['part'] for item in rows if item.get('type') == 'tool_use'
                    and item['part']['id'] == row['call_id'])
        assert digest(call['state']['input']) == row['arguments_sha256'] == event['query_sha256']
        assert authenticate_response(call['state']['output'], event)[0] == original
        stage = int(row['trial_id'].split('-s')[-1])
        current = origin if stage in (1, 2) else stage3
        old = classify(analyzer, rows, catalog, origin, current, row['arm'], events)
        assert not old['unsupported_calls']
        derived_rows, derived_events = copy.deepcopy(rows), copy.deepcopy(events)
        derived_call = next(item['part'] for item in derived_rows if item.get('type') == 'tool_use'
                            and item['part']['id'] == row['call_id'])
        derived_call['state']['output'] = packet['model_result']['content'][0]['text']
        derived_event = derived_events[event_index]
        derived_event.update(response_format='readable', response_audit=packet['audit'],
                             response_bytes=len(canonical(packet['model_result'])))
        # Every argument, timestamp and non-display tool field is retained.
        checked_call = copy.deepcopy(derived_call)
        checked_call['state']['output'] = call['state']['output']
        assert checked_call == call
        checked_event = copy.deepcopy(derived_event)
        for key in ('response_format', 'response_audit', 'response_bytes'):
            checked_event[key] = event[key]
        assert checked_event == event
        recovered, marker = authenticate_response(derived_call['state']['output'], derived_event)
        assert recovered == original and marker == 'readable_verified'
        new = classify(analyzer, derived_rows, catalog, origin, current, row['arm'], derived_events)
        assert not new['unsupported_calls']
        assert old['records'] == new['records'] and old['counts'] == new['counts']
        assert old['backend_crosscheck'] == new['backend_crosscheck']
        frozen_trial = next(trial for trial in previous['trials'] if trial['trial']['id'] == row['trial_id'])
        assert old['records'] == frozen_trial['records']
        for record in new['records']:
            totals[(row['arm'], record['channel'], record['assessment'])] += 1
            if record['assessment'] == 'obsolete_literal_tuple':
                unique_obsolete.add(record['record_id'])
        save(f'packet-{number:03}.json', {
            'scope': 'DERIVED FORMAT-ONLY OFFLINE VERIFICATION; not actual model output',
            'original_roster_row': row, 'derived_event': derived_event,
            'derived_model_result': packet['model_result'],
            'original_classification': old, 'derived_classification': new,
            'query_and_timestamps_unchanged': True,
        })
        observations.append({'trial_id': row['trial_id'], 'arm': row['arm'],
                             'returned_records': len(original['entries']),
                             'withheld_records': len(original['withheld']),
                             'exact_original_json_equal': True, 'classification_equal': True})
    assert len(unique_obsolete) == 2
    assert totals == Counter({('static', 'returned', 'same_literal_tuple'): 49,
                              ('static', 'returned', 'obsolete_literal_tuple'): 11,
                              ('cami', 'returned', 'same_literal_tuple'): 48,
                              ('cami', 'withheld', 'obsolete_literal_tuple'): 12})
    assert {str(path): controls.inventory(path) for path in trees} == before
    assert all(sha(ROOT / path) == expected for path, expected in inputs.items())
    save('input-hashes.json', inputs)
    save('source-inventories.json', before)
    result = {'status': 'passed', 'packets': len(roster), 'observations': observations,
              'scope': 'DERIVED FORMAT-ONLY OFFLINE VERIFICATION; modified tool texts/events are not actual model output',
              'essential_records_and_staleness_equal': True, 'source_inventories_unchanged': True,
              'input_hashes_unchanged': True, 'unique_obsolete_record_ids': sorted(unique_obsolete),
              'counts': [{'arm': a, 'channel': c, 'assessment': s, 'observations': n}
                         for (a, c, s), n in sorted(totals.items())],
              'model_calls': 0, 'heldout_reads': 0, 'docker_runs': 0, 'network_calls': 0,
              'effect_claims': 'No token, time, quality, or model-behavior effect inferred.'}
    save('replay-report.json', result)
    print(json.dumps({key: value for key, value in result.items() if key != 'observations'}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('replay-failure.json', {'error': type(error).__name__ + ': ' + str(error)})
        raise
