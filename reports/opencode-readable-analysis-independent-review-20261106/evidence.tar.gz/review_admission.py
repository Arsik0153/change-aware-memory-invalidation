"""Read-only explicit version/tier/cohort admission checks using public inputs."""
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/opencode_benchmark/analysis'))
import aggregate_study as aggregate
from service_tier_evidence import TIER_POLICY, V6_STUDY_ID


def refuses(call):
    try:
        call()
    except ValueError:
        return True
    return False


study = json.loads((ROOT / 'runs/opencode-development-v6-20261106/frozen-study.json').read_bytes())
supported = aggregate.read(aggregate.HERE / 'supported_rules.json')
protocol = aggregate.read(ROOT / 'reports/opencode-study-design-v6-20261106/protocol.json')
assert aggregate.admit_protocol(protocol, supported) == V6_STUDY_ID
aggregate.admit_study_cohort(V6_STUDY_ID, study)
readable = copy.deepcopy(study)
readable['memory_response_format'] = 'readable'
assert refuses(lambda: aggregate.admit_study_cohort(V6_STUDY_ID, readable))
aggregate.admit_study_cohort(aggregate.V7_STUDY_ID, readable)
assert refuses(lambda: aggregate.admit_study_cohort(aggregate.V7_STUDY_ID, study))
v7_protocol = copy.deepcopy(protocol)
v7_protocol['study_id'] = aggregate.V7_STUDY_ID
assert aggregate.admit_protocol(v7_protocol, supported) == aggregate.V7_STUDY_ID
assert {key: v7_protocol[key] for key in supported if key != 'study_id'} == {
    key: supported[key] for key in supported if key != 'study_id'}
for key in TIER_POLICY:
    mutated = copy.deepcopy(v7_protocol)
    del mutated['service_tier'][key]
    assert refuses(lambda: aggregate.admit_protocol(mutated, supported))
for key, value in [('memory_response_format', 'full'), ('bundle_kind', 'heldout'),
                   ('service_tier', 'default'), ('service_tier', None)]:
    mutated = copy.deepcopy(readable)
    mutated[key] = value
    assert refuses(lambda: aggregate.admit_study_cohort(aggregate.V7_STUDY_ID, mutated))
report = {'status': 'passed', 'v6_compact_admitted': True, 'v6_readable_refused': True,
          'v7_readable_development_schema2_admitted': True, 'v7_compact_full_refused': True,
          'v7_nonpriority_heldout_refused': True, 'unchanged_frozen_success_cost_rules': True,
          'all_required_priority_high_policy_keys_enforced': True,
          'scope': 'Read-only admission functions on copies of frozen public inputs; no model study executed.'}
(OUT / 'admission-review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2))
