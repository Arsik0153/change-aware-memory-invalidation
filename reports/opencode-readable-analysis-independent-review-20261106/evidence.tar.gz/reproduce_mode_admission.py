"""Authored minimal summary fixture: compact declared, readable observed."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/opencode_benchmark/analysis'))
import test_literal_staleness as fixtures
from summarize_literal_staleness import summarize


def save(path, value):
    path.write_bytes(fixtures.canonical(value) + b'\n')


case_root = OUT / 'admission-authored-fixture'
case_root.mkdir()
origin, current, catalog, _ = fixtures.case.__wrapped__(case_root)
controls = fixtures.load_controls(fixtures.CONTROLS)
run = case_root / 'run'
(run / 'trials').mkdir(parents=True)
sequence = ['task-a', 'task-a', 'task-b', 'task-b']
save(run / 'frozen-study.json', {
    'bundle_kind': 'development', 'arms': ['plain', 'static', 'cami'],
    'memory_response_format': 'compact', 'normalized': {'sequence': sequence}})
plan = [{'id': f'r{rep}-{arm}-s{stage}', 'repetition': rep, 'arm': arm,
         'stage': stage, 'task': sequence[stage - 1]}
        for rep in range(1, 4) for arm in ('plain', 'static', 'cami') for stage in range(1, 5)]
save(run / 'plan.json', {'trials': plan})
catalog_path = case_root / 'catalog.json'
save(catalog_path, catalog)
trial = next(row for row in plan if row['id'] == 'r1-static-s1')
directory = run / 'trials' / trial['id']
(directory / 'session/evidence').mkdir(parents=True)
save(directory / 'canonical-reset.json', {'canonical_files': controls.inventory(current)})
save(directory / 'memory-before.json', {'prepared/catalog.json': controls.sha(catalog_path)})
rows, events = fixtures.readable_wire(catalog)
state = rows[0]['part']['state']
messages = [{'id': 'm1', 'type': 'assistant', 'content': [{
    'id': 'lookup', 'type': 'tool', 'name': 'memory_lookup',
    'time': {'created': 2, 'completed': 3}, 'state': {
        'status': 'completed', 'input': state['input'],
        'content': [{'type': 'text', 'text': state['output']}]}}]}]
save(directory / 'session/evidence/messages.json', messages)
(directory / 'session/evidence/memory-backend-trace.jsonl').write_bytes(
    b''.join(fixtures.canonical(event) + b'\n' for event in events))
artifacts = {name: value['sha256'] for name, value in controls.inventory(directory).items()}
save(directory / 'terminal.json', {'trial': trial, 'status': 'passed',
     'artifact_hashes': artifacts, 'immutable_memory': {'prepared/catalog.json': controls.sha(catalog_path)}})
report = summarize(run, catalog_path, origin, current, current, fixtures.CONTROLS, fixtures.ANALYZER)
save(OUT / 'mode-admission-before-fix.json', report)
classifier = ROOT / 'scripts/opencode_benchmark/analysis/summarize_literal_staleness.py'
proof = {'declared_format': 'compact', 'observed_event_format': 'readable',
         'status': report['trials'][0]['status'], 'calls': report['trials'][0]['memory_calls'],
         'helper_pinned': any(path.endswith('readable_receipts.py')
                              for path in report['inputs']['implementation_sha256']),
         'summary_source_sha256': hashlib.sha256(classifier.read_bytes()).hexdigest()}
save(OUT / 'mode-admission-proof.json', proof)
print(json.dumps(proof, indent=2))
