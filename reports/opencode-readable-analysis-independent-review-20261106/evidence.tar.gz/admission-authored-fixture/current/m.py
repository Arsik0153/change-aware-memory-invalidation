@(
 deco
)
def a():
    return 1
