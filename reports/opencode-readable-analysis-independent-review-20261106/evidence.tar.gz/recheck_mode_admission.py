"""Recheck preserved authored mismatch, plus a separately copied matching study."""
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/opencode_benchmark/analysis'))
import summarize_literal_staleness as summary


def assess(case):
    return summary.summarize(
        case / 'run', case / 'catalog.json', case / 'origin', case / 'current', case / 'current',
        ROOT / 'scripts/opencode_benchmark/analysis/summarize_terminal_staleness.py',
        ROOT / 'scripts/analyze_opencode_staleness.py')


original = OUT / 'admission-authored-fixture'
called = False
real_classify = summary.classify


def refused_classify(*args, **kwargs):
    global called
    called = True
    raise AssertionError('format mismatch reached classifier')


summary.classify = refused_classify
rejected = assess(original)
summary.classify = real_classify
assert not called
assert rejected['trials'][0]['status'] == 'unsupported_or_integrity_error'
assert 'format differs from frozen study' in rejected['trials'][0]['reason']
assert rejected['trials'][0]['terminal_status'] == 'passed'
assert not rejected['trials'][0]['records']
matching = OUT / 'admission-authored-matched'
shutil.copytree(original, matching)
study_path = matching / 'run/frozen-study.json'
study = json.loads(study_path.read_bytes())
study['memory_response_format'] = 'readable'
study_path.write_text(json.dumps(study) + '\n')
accepted = assess(matching)
assert accepted['trials'][0]['status'] == 'assessed'
assert accepted['trials'][0]['memory_calls'][0]['response_format'] == 'readable_verified'
assert any(path.endswith('readable_receipts.py') for path in accepted['inputs']['implementation_sha256'])
for name, report in [('mode-admission-after-fix.json', rejected),
                     ('mode-admission-matched-readable.json', accepted)]:
    (OUT / name).write_bytes(summary.canonical(report) + b'\n')
print(json.dumps({'status': 'passed', 'mismatch_classifier_not_called': not called,
                  'mismatch_terminal_outcome_retained': True,
                  'matching_readable_authenticated_and_helper_pinned': True}, indent=2))
