raise RuntimeError('candidate cannot replace trusted runner')
