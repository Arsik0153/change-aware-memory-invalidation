import subprocess,sys
def test_child_subject_import():
    result = subprocess.run([sys.executable,"-c","import authored; print(authored.VALUE)"],capture_output=True,text=True)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "42"
