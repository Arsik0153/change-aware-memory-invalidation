"""Explicit offline check of all24 sealed v6 packets; never part of normal tests."""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "integrations/opencode"))
from compact_response import compact_result  # noqa: E402
from memory_backend import canonical, digest  # noqa: E402
from readable_response import FORMAT, readable_result  # noqa: E402

ROSTER_SHA = "c7bcc97e81f8ff1a02a6f8fbab0206242f3a7110f543e1381403d3fedc61d7f5"


def file_hash(path):
    import hashlib

    return hashlib.sha256(path.read_bytes()).hexdigest()


def pointer(value, path):
    for token in path.split("/")[1:]:
        token = token.replace("~1", "/").replace("~0", "~")
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location(
        "readable_authored_checks", ROOT / "tests/test_opencode_readable_response.py"
    )
    checks = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checks)
    roster_path = ROOT / "runs/opencode-v6-independent-audit-20261106/memory-packet-roster.json"
    assert file_hash(roster_path) == ROSTER_SHA
    roster = json.loads(roster_path.read_bytes())["roster"]
    assert len(roster) == 24 and Counter(row["arm"] for row in roster) == {"static": 12, "cami": 12}
    rows, inputs = [], {}
    for number, row in enumerate(roster):
        trace_path, messages_path = ROOT / row["backend_trace_path"], ROOT / row["messages_path"]
        for path, sha in [
            (trace_path, row["backend_trace_sha256"]),
            (messages_path, row["messages_sha256"]),
        ]:
            assert file_hash(path) == sha
            inputs[str(path.relative_to(ROOT))] = sha
        event = json.loads(
            trace_path.read_bytes().splitlines()[row["backend_lookup_jsonl_line_one_based"] - 1]
        )
        original = pointer(event, row["full_result_pointer_within_trace_event"])
        text = pointer(json.loads(messages_path.read_bytes()), row["model_text_json_pointer"])
        old_result, old_audit = compact_result(original)
        assert old_result["content"][0]["text"] == text
        assert digest(original) == row["full_result_sha256"]
        assert digest(old_result) == row["model_result_sha256"]
        assert old_audit["receipt_sha256"] == row["receipt_sha256"]
        result, audit = readable_result(original)
        assert audit["effective_format"] == FORMAT and audit["fallback_reason"] is None
        value = json.loads(original["content"][0]["text"])
        checks.assert_essential_fields(result, value)
        checks.assert_readable_receipt(result, audit)
        packet = args.out / f"packet-{number:03d}.json"
        packet.write_bytes(
            canonical({"source_roster_row": row, "model_result": result, "audit": audit}) + b"\n"
        )
        rows.append(
            {
                "trial_id": row["trial_id"],
                "call_id": row["call_id"],
                "arm": row["arm"],
                "effective_format": audit["effective_format"],
                "returned_records": len(value["entries"]),
                "withheld_records": len(value["withheld"]),
                "essential_fields_exact": True,
                "physical_prefix_bytes_exact": True,
                "receipt_verified": True,
                "original_compact_text_bytes": len(text.encode()),
                "readable_text_bytes": len(result["content"][0]["text"].encode()),
                "artifact_sha256": file_hash(packet),
            }
        )
    for path, sha in inputs.items():
        assert file_hash(ROOT / path) == sha
    report = {
        "status": "passed",
        "roster_sha256": ROSTER_SHA,
        "packets": 24,
        "source_inputs_unchanged": True,
        "model_calls": 0,
        "production_wiring": False,
        "scope": "Offline exact-field/source/receipt check only, no token/quality/latency claim.",
        "source_pins": {
            name: file_hash(ROOT / name)
            for name in [
                "integrations/opencode/readable_response.py",
                "tests/test_opencode_readable_response.py",
                "integrations/opencode/compact_response.py",
                "integrations/opencode/memory_backend.py",
                "integrations/opencode/literal_catalog.py",
            ]
        },
        "rows": rows,
    }
    (args.out / "report.json").write_bytes(canonical(report) + b"\n")
    print(
        json.dumps(
            {
                "status": "passed",
                "packets": 24,
                "report_sha256": file_hash(args.out / "report.json"),
            }
        )
    )


if __name__ == "__main__":
    main()
