import pytest
from authored import value
def test_regression():
    assert value() > 0
@pytest.mark.skip(reason='known synthetic platform allowance')
def test_known_skip():
    assert False
