raise RuntimeError('authored candidate must not replace trusted pytest')
