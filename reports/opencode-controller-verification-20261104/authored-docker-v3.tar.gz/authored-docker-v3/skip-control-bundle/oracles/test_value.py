import pytest
@pytest.mark.skip(reason='authored skip control')
def test_acceptance():
    assert False
