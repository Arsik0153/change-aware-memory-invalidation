from authored import value
def test_acceptance():
    assert value() in (1, 2)
