from authored import value
def test_regression():
    assert value() > 0
