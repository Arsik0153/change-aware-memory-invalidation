"""Installed-binary request serialization control; synthetic OAuth, network-none only."""
import json
import http.server
import threading
import os
from pathlib import Path
import sys
import time
import urllib.parse

sys.path.insert(0, '/harness')
from container_common import PrivateServer, EXPECTED_BINARY_SHA, sha, BINARY

out = Path('/proof/proof-02')
out.mkdir(exist_ok=False)
workspace = out / 'workspace'
workspace.mkdir()
plugin = out / 'plugin'
plugin.mkdir()
(plugin / 'package.json').write_text(json.dumps({'name': 'synthetic-tier-wire-proof', 'type': 'module', 'exports': './index.js'}))
(plugin / 'index.js').write_text('''import {writeFileSync} from "node:fs";
export default {id:"research.synthetic-tier-proof",setup:async(e)=>{
  await e.session.hook("http.request",async(q)=>{
    const b=await q.request.clone().json();
    writeFileSync("/proof/proof-02/wire-selected.json",JSON.stringify({
      request_origin:new URL(q.request.url).origin,request_path:new URL(q.request.url).pathname,
      model:b.model,reasoning:b.reasoning,service_tier:b.service_tier,
      authorization_present:q.request.headers.has("authorization"),
      originator:q.request.headers.get("originator"),
      never_forwarded_to_external_network:true,synthetic_auth_only:true}));
    q.request=new Request("http://127.0.0.1:17891/synthetic",q.request);
  });
}};
''')
config = {'model': 'openai/gpt-6.1-sol#high', 'update': 'disable', 'share': 'disabled', 'warming': False,
          'snapshots':False,'compaction':{'auto':False},'plugins':[str(plugin)],
          'agents':{'research':{'mode':'primary','steps':1,'system':'Authored request serialization control only.'}},
          'providers':{'openai':{'settings':{'transport':'http','encoding':'none'},'models':{'gpt-6.1-sol':{
              'modelID':'gpt-6.1-sol','package':'@opencode/ai/providers/openai/responses',
              'settings':{'serviceTier':'priority'},'variants':[{'id':'high','settings':{'reasoningEffort':'high'}}],
              'capabilities':{'tools':True,'input':['text'],'output':['text'],'reasoning':{'supported':True,'effort':['high']}}}}}}}
env=dict(os.environ)
for key in list(env):
    if key.startswith(('OPENCODE_', 'OPENAI_', 'CODEX_', 'ANTHROPIC_')):
        env.pop(key)
for key,suffix in [('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('OPENCODE_TEST_HOME','home')]:
    path=Path('/tmp/tier-proof')/suffix;path.mkdir(parents=True,exist_ok=True);env[key]=str(path)
env.update(OPENCODE_DB='/tmp/tier-proof/only-synthetic.sqlite3',OPENCODE_CONFIG_PROJECT_DISABLE='1',OPENCODE_DISABLE_MODELS_FETCH='1',OPENCODE_DISABLE_CLAUDE_CODE='1',OPENCODE_DISABLE_AUTOUPDATE='1')
config_path=Path(env['XDG_CONFIG_HOME'])/'opencode/opencode.json';config_path.parent.mkdir();config_path.write_text(json.dumps(config))
private=Path('/tmp/tier-proof/private');private.mkdir()
assert sha(BINARY)==EXPECTED_BINARY_SHA
class Stub(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length','0')))
        message={'type':'message','id':'msg_synthetic','role':'assistant','status':'completed','content':[{'type':'output_text','text':'SYNTHETIC_TRANSPORT_ONLY','annotations':[]}]}
        response={'id':'resp_synthetic','object':'response','created_at':int(time.time()),'status':'completed','model':'gpt-6.1-sol','output':[message],'service_tier':'priority','usage':{'input_tokens':1,'output_tokens':1,'input_tokens_details':{'cached_tokens':0},'output_tokens_details':{'reasoning_tokens':0}}}
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
        events=[{'type':'response.created','response':{**response,'status':'in_progress','output':[]}},
                {'type':'response.output_item.added','output_index':0,'item':{**message,'status':'in_progress','content':[]}},
                {'type':'response.content_part.added','item_id':'msg_synthetic','output_index':0,'content_index':0,'part':{'type':'output_text','text':'','annotations':[]}},
                {'type':'response.output_text.delta','item_id':'msg_synthetic','output_index':0,'content_index':0,'delta':'SYNTHETIC_TRANSPORT_ONLY'},
                {'type':'response.output_text.done','item_id':'msg_synthetic','output_index':0,'content_index':0,'text':'SYNTHETIC_TRANSPORT_ONLY'},
                {'type':'response.output_item.done','output_index':0,'item':message},
                {'type':'response.completed','response':response}]
        for event in events:self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode())
        self.wfile.flush()
httpd=http.server.HTTPServer(('127.0.0.1',17891),Stub)
threading.Thread(target=httpd.serve_forever,daemon=True).start()
server=PrivateServer(env,workspace,private)
try:
    server.wait_ready()
    # Authored non-secret sentinel credentials never leave this network-none container.
    server.request('POST','/api/credential',{'integrationID':'openai','value':{'type':'oauth','methodID':'chatgpt-headless','refresh':'SYNTHETIC_REFRESH_NOT_A_CREDENTIAL','access':'SYNTHETIC_ACCESS_NOT_A_CREDENTIAL','expires':4102444800000},'activate':True})
    location='?'+urllib.parse.urlencode({'location[directory]':str(workspace)})
    models=server.request('GET','/api/model'+location)['data']
    selected=next(m for m in models if m['id']=='gpt-6.1-sol' and m['providerID']=='openai')
    (out/'configured-model-selected.json').write_text(json.dumps({k:selected[k] for k in ['id','modelID','providerID','package','settings','variants']},indent=2)+'\n')
    session=server.request('POST','/api/session',{'location':{'directory':str(workspace)},'title':'Synthetic tier proof','agent':'research','model':{'providerID':'openai','id':'gpt-6.1-sol','variant':'high'}})['data']
    server.request('POST',f"/api/session/{session['id']}/prompt",{'text':'Authored serialization sentinel. Never execute tools.'})
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        final=server.request('GET',f"/api/session/{session['id']}")['data']
        if final.get('outcome') in ['succeeded','failed','interrupted'] and final.get('time',{}).get('idle'):break
        time.sleep(.1)
    messages=server.request('GET',f"/api/session/{session['id']}/message?limit=100&order=asc")['data']
    found=[]
    def tiers(value,path):
        if isinstance(value,dict):
            for k,v in value.items():
                if k in ['serviceTier','service_tier']:found.append({'path':path+'/'+k,'value':v})
                elif k not in ['text','content']:tiers(v,path+'/'+k)
        elif isinstance(value,list):
            for i,v in enumerate(value):tiers(v,path+'/'+str(i))
    for i,message in enumerate(messages):tiers(message,'/messages/'+str(i))
    result={'status':'passed','outcome':final.get('outcome'),'assistant_top_level_keys':[list(m) for m in messages if m.get('type')=='assistant'],'service_tier_fields':found,'real_model_calls':0,'real_credentials_read':False,'external_network':'none','scope':'Authored local provider SSE response, never real served-priority evidence.'}
    (out/'response-metadata-shape.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

except BaseException as error:
    (out/'failure.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error)},indent=2)+'\n')
    # Log contains only generated server password and synthetic sentinels, never host auth.
    raw=(private/'server.log').read_text(errors='replace').replace(server.password,'[REDACTED_SERVER_PASSWORD]')
    (out/'synthetic-server-log.txt').write_text(raw)
    raise
finally:
    server.stop()
