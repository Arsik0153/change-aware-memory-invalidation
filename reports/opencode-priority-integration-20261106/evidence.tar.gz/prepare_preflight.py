"""Prepare fresh authored workspaces only; never a benchmark task or model call."""
import json
import os
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent/'preflight-04'
out.mkdir(exist_ok=False)
spec={'schema_version':1,'source_roots':['.'],'excluded_paths':[], 'records':[{'id':'stable-exists','kind':'note','note_key':'authored-stable','text':'Authored fixture declares stable_value.','selector':'fixture.py:stable_value','subject':{'language':'python','path':'fixture.py','qualname':'stable_value','node_kind':'function'}}]}
(out/'seed-spec.json').write_text(json.dumps(spec)+'\n')
for arm in ['plain','static','cami']:
 p=out/arm;p.mkdir();w=p/'workspace';w.mkdir();m=p/'memory';m.mkdir()
 (w/'fixture.py').write_text('def stable_value():\n    return 7\n')
 for argv in [['git','init','-q',str(w)],['git','-C',str(w),'add','fixture.py'],['git','-C',str(w),'-c','user.email=authored@example.invalid','-c','user.name=Authored','commit','-qm','Authored initial fixture']]:subprocess.run(argv,check=True,stdout=subprocess.DEVNULL)
 for d in [p,w,m]:
  d.chmod(0o777)
  os.chown(d,65534,65534)
 for f in w.rglob('*'):os.chown(f,65534,65534)
 for f in w.rglob('*'):
  if f.is_file():f.chmod(0o666)
  elif f.is_dir():f.chmod(0o777)
 if arm!='plain':
  argv=['docker','--host=unix:///var/run/docker.sock','run','--rm','--network=none','--user=65534:65534','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--memory=2g','--cpus=2','--tmpfs','/tmp:rw,size=256m','--env','PYTHONPATH=/opt/memory-adapter:/opt/cami-src:/opt/cami-deps','--env','PYTHONSAFEPATH=1','--env','PYTHONDONTWRITEBYTECODE=1',
   '-v',str(root/'src')+':/opt/cami-src:ro','-v',str(root/'integrations/opencode')+':/opt/memory-adapter:ro','-v',str(w)+':/workspace:rw','-v',str(m)+':/memory:rw','-v',str(out/'seed-spec.json')+':/seed.json:ro','--workdir','/','--entrypoint','python','sha256:3e5f5aee66022082251b8cc1fb5c3ea9399ec9589ab98ba3d190a8b0ab46b387','/opt/memory-adapter/memory_adapter.py','prepare','--backend',arm,'--repo','/workspace','--seed-spec','/seed.json','--out','/memory/prepared']
  if arm=='cami':argv+=['--state-home','/memory/cami-state']
  result=subprocess.run(argv,capture_output=True,timeout=60)
  (p/'prepare.stdout.txt').write_bytes(result.stdout);(p/'prepare.stderr.txt').write_bytes(result.stderr)
  (p/'prepare.json').write_text(json.dumps({'argv':argv,'returncode':result.returncode,'model_calls':0})+'\n')
  assert result.returncode==0,arm
print('three authored workspaces ready; two memory preparations passed')
