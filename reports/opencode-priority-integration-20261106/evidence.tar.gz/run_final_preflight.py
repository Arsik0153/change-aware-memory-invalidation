"""One final no-model configuration check per arm, same stable source pins."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[2]
stage=Path(__file__).resolve().parent
files=['scripts/opencode_benchmark/harness/'+n+'.py' for n in ['container_common','container_session','container_worker']]
files+=['scripts/opencode_benchmark/controller/'+n+'.py' for n in ['study_schema','study_runtime','study_controller','test_service_tier']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p:sha(root/p) for p in files}
(stage/'final-preflight-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
rows=[]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
for arm in ['plain','static','cami']:
 p=stage/'preflight-04'/arm
 argv=[sys.executable,str(root/'scripts/opencode_benchmark/harness/container_session.py'),'--workspace',str(p/'workspace'),'--memory-dir',str(p/'memory'),'--state-dir',str(p/'final-private-state'),'--out',str(p/'final-session'),'--arm',arm,'--no-model','--service-tier','priority','--image','sha256:3e5f5aee66022082251b8cc1fb5c3ea9399ec9589ab98ba3d190a8b0ab46b387']
 if arm!='plain':argv+=['--binding-relative','prepared/binding.json']
 result=subprocess.run(argv,env=env,capture_output=True,timeout=180)
 (p/'final-session.stdout.txt').write_bytes(result.stdout);(p/'final-session.stderr.txt').write_bytes(result.stderr)
 record={'arm':arm,'argv':argv,'returncode':result.returncode};rows.append(record)
 (stage/'final-preflight-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert result.returncode==0,arm
 m=json.loads((p/'final-session/manifest.json').read_bytes());w=json.loads((p/'final-session/evidence/manifest.json').read_bytes());t=json.loads((p/'final-session/evidence/service-tier.json').read_bytes())
 assert m['status']==w['status']=='passed' and m['state_removed'] and not (p/'final-private-state').exists()
 assert not m['model_requested'] and w['model_session_launches']==0
 assert t['requested']==t['configured']=='priority' and t['reasoning_effort']=='high' and t['actual_served'] is None
 record.update(status='passed',state_removed=True,model_session_launches=0,service_tier=t,session_manifest_sha256=sha(p/'final-session/manifest.json'))
after={p:sha(root/p) for p in files};assert before==after
(stage/'final-preflight.json').write_text(json.dumps({'status':'passed','source_before_after_equal':True,'source_sha256':after,'trials':rows,'real_model_calls':0,'real_account_auth_read':False,'limits':'Configuration/startup/MCP connectivity only. No performance result or paid model smoke.'},indent=2)+'\n')
print('final stable-source no-model priority checks passed all3arms')
