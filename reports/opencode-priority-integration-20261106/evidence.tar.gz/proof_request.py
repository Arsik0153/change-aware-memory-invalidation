"""Installed-binary request serialization control; synthetic OAuth, network-none only."""
import json
import os
from pathlib import Path
import sys
import time
import urllib.parse

sys.path.insert(0, '/harness')
from container_common import PrivateServer, EXPECTED_BINARY_SHA, sha, BINARY

out = Path('/proof/proof-01')
out.mkdir(exist_ok=False)
workspace = out / 'workspace'
workspace.mkdir()
plugin = out / 'plugin'
plugin.mkdir()
(plugin / 'package.json').write_text(json.dumps({'name': 'synthetic-tier-wire-proof', 'type': 'module', 'exports': './index.js'}))
(plugin / 'index.js').write_text('''import {writeFileSync} from "node:fs";
export default {id:"research.synthetic-tier-proof",setup:async(e)=>{
  await e.session.hook("http.request",async(q)=>{
    const b=await q.request.clone().json();
    writeFileSync("/proof/proof-01/wire-selected.json",JSON.stringify({
      request_origin:new URL(q.request.url).origin,request_path:new URL(q.request.url).pathname,
      model:b.model,reasoning:b.reasoning,service_tier:b.service_tier,
      authorization_present:q.request.headers.has("authorization"),
      originator:q.request.headers.get("originator"),
      never_forwarded_to_network:true,synthetic_auth_only:true}));
    throw new Error("SYNTHETIC_PROOF_STOP_BEFORE_TRANSPORT");
  });
}};
''')
config = {'model': 'openai/gpt-6.1-sol#high', 'update': 'disable', 'share': 'disabled', 'warming': False,
          'snapshots':False,'compaction':{'auto':False},'plugins':[str(plugin)],
          'agents':{'research':{'mode':'primary','steps':1,'system':'Authored request serialization control only.'}},
          'providers':{'openai':{'settings':{'transport':'http','encoding':'none'},'models':{'gpt-6.1-sol':{
              'modelID':'gpt-6.1-sol','package':'@opencode/ai/providers/openai/responses',
              'settings':{'serviceTier':'priority'},'variants':[{'id':'high','settings':{'reasoningEffort':'high'}}],
              'capabilities':{'tools':True,'input':['text'],'output':['text'],'reasoning':{'supported':True,'effort':['high']}}}}}}}
env=dict(os.environ)
for key in list(env):
    if key.startswith(('OPENCODE_', 'OPENAI_', 'CODEX_', 'ANTHROPIC_')):
        env.pop(key)
for key,suffix in [('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('OPENCODE_TEST_HOME','home')]:
    path=Path('/tmp/tier-proof')/suffix;path.mkdir(parents=True,exist_ok=True);env[key]=str(path)
env.update(OPENCODE_DB='/tmp/tier-proof/only-synthetic.sqlite3',OPENCODE_CONFIG_PROJECT_DISABLE='1',OPENCODE_DISABLE_MODELS_FETCH='1',OPENCODE_DISABLE_CLAUDE_CODE='1',OPENCODE_DISABLE_AUTOUPDATE='1')
config_path=Path(env['XDG_CONFIG_HOME'])/'opencode/opencode.json';config_path.parent.mkdir();config_path.write_text(json.dumps(config))
private=Path('/tmp/tier-proof/private');private.mkdir()
assert sha(BINARY)==EXPECTED_BINARY_SHA
server=PrivateServer(env,workspace,private)
try:
    server.wait_ready()
    # Authored non-secret sentinel credentials never leave this network-none container.
    server.request('POST','/api/credential',{'integrationID':'openai','value':{'type':'oauth','methodID':'chatgpt-headless','refresh':'SYNTHETIC_REFRESH_NOT_A_CREDENTIAL','access':'SYNTHETIC_ACCESS_NOT_A_CREDENTIAL','expires':4102444800000},'activate':True})
    location='?'+urllib.parse.urlencode({'location[directory]':str(workspace)})
    models=server.request('GET','/api/model'+location)['data']
    selected=next(m for m in models if m['id']=='gpt-6.1-sol' and m['providerID']=='openai')
    (out/'configured-model-selected.json').write_text(json.dumps({k:selected[k] for k in ['id','modelID','providerID','package','settings','variants']},indent=2)+'\n')
    session=server.request('POST','/api/session',{'location':{'directory':str(workspace)},'title':'Synthetic tier proof','agent':'research','model':{'providerID':'openai','id':'gpt-6.1-sol','variant':'high'}})['data']
    server.request('POST',f"/api/session/{session['id']}/prompt",{'text':'Authored serialization sentinel. Never execute tools.'})
    deadline=time.monotonic()+20
    while time.monotonic()<deadline and not (out/'wire-selected.json').exists():time.sleep(.1)
    assert (out/'wire-selected.json').exists(),'wire capture missing'
    wire=json.loads((out/'wire-selected.json').read_bytes())
    assert wire['service_tier']=='priority' and wire['reasoning']['effort']=='high'
    assert wire['request_origin']=='https://chatgpt.com' and wire['request_path'].endswith('/codex/responses')
    (out/'result.json').write_text(json.dumps({'status':'passed','binary_sha256':EXPECTED_BINARY_SHA,'real_model_calls':0,'real_credentials_read':False,'network_mode':'none','source':'actual pinned binary serialized HTTP request before transport','actual_served_tier':None,'actual_served_reason':'No server response in synthetic transport-abort control.'},indent=2)+'\n')
    print(json.dumps(wire))
except BaseException as error:
    (out/'failure.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error)},indent=2)+'\n')
    # Log contains only generated server password and synthetic sentinels, never host auth.
    raw=(private/'server.log').read_text(errors='replace').replace(server.password,'[REDACTED_SERVER_PASSWORD]')
    (out/'synthetic-server-log.txt').write_text(raw)
    raise
finally:
    server.stop()
