import {writeFileSync} from "node:fs";
export default {id:"research.synthetic-tier-proof",setup:async(e)=>{
  await e.session.hook("http.request",async(q)=>{
    const b=await q.request.clone().json();
    writeFileSync("/proof/proof-02/wire-selected.json",JSON.stringify({
      request_origin:new URL(q.request.url).origin,request_path:new URL(q.request.url).pathname,
      model:b.model,reasoning:b.reasoning,service_tier:b.service_tier,
      authorization_present:q.request.headers.has("authorization"),
      originator:q.request.headers.get("originator"),
      never_forwarded_to_external_network:true,synthetic_auth_only:true}));
    q.request=new Request("http://127.0.0.1:17891/synthetic",q.request);
  });
}};
