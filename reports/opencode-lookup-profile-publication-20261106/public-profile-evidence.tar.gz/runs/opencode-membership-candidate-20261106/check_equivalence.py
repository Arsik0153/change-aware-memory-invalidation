"""Exact CodeIndex field comparison, frozen baseline vs one-file candidate; no target execution."""

from __future__ import annotations

import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / "runs/opencode-runtime-literal-v5-20261104/extracted/src"
CANDIDATE = HERE / "candidate-source"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def normalize(value):
    if dataclasses.is_dataclass(value):
        return {
            "dataclass": type(value).__name__,
            "fields": [
                [field.name, normalize(getattr(value, field.name))]
                for field in dataclasses.fields(value)
            ],
        }
    if hasattr(value, "model_dump"):
        return {"model": type(value).__name__, "value": value.model_dump(mode="json")}
    if isinstance(value, tuple):
        return {"tuple": [normalize(item) for item in value]}
    if isinstance(value, frozenset):
        return {"frozenset": sorted([normalize(item) for item in value], key=canonical)}
    if isinstance(value, dict):
        return {str(key): normalize(item) for key, item in value.items()}
    return value


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def main():
    study = json.loads(
        (ROOT / "runs/opencode-development-v5-20261104/frozen-study.json").read_bytes()
    )
    pin = study["pins"]["production"]
    if CANDIDATE.exists():
        raise ValueError("candidate snapshot must be new")
    CANDIDATE.mkdir()
    for name, expected in pin["files"].items():
        assert sha(BASE / name) == expected
        target = CANDIDATE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(BASE / name, target)
    shutil.copyfile(ROOT / "src/cami/index.py", CANDIDATE / "cami/index.py")
    changes = [name for name, expected in pin["files"].items() if sha(CANDIDATE / name) != expected]
    assert changes == ["cami/index.py"], changes
    original = (BASE / "cami/index.py").read_text()
    expected = original.replace(
        "    for module in modules:\n        local = ",
        "    for module in modules:\n        module_unresolved = frozenset(module.unresolved)\n        local = ",
    ).replace(" in module.unresolved:\n", " in module_unresolved:\n")
    assert (CANDIDATE / "cami/index.py").read_text() == expected
    sys.path.insert(0, str(BASE))
    baseline = module("membership_baseline_index", BASE / "cami/index.py")
    candidate = module("membership_candidate_index", CANDIDATE / "cami/index.py")
    from cami.repository import Blob, Snapshot

    cases = []
    trees = ROOT / "runs/opencode-development-v3-staleness-20261104"
    for label, tree in [
        ("click-origin", trees / "origin-and-stage1"),
        ("click-stage3", trees / "stage3"),
    ]:
        files = {
            p.relative_to(tree).as_posix(): p.read_bytes()
            for p in sorted((tree / "src/click").rglob("*.py"))
        }
        cases.append((label, files, ("src/click",)))
    authored = {
        "duplicate-functions": "def target(): pass\ndef target(): return 2\ndef caller(): return target()\n",
        "class-global-shadow": "def target(): pass\nclass Outer:\n class Inner:\n  global target\n  target = lambda: 3\ndef caller(): return target()\n",
        "import-collision": "from missing import target\ndef target(): pass\nif flag:\n import other as target\ndef caller(): return target()\n",
        "local-global-nonlocal": "def target(): pass\ndef outer():\n target = lambda: 1\n def inner():\n  nonlocal target\n  return target()\n return inner()\ndef caller():\n global target\n return target()\n",
        "loop-except-match-walrus": 'def target(): pass\nfor target in things: pass\ntry: pass\nexcept Error as target: pass\nmatch value:\n case {"key": target}: pass\nif (target := value): pass\ndef caller(): return target()\n',
        "duplicate-classes-methods": "class A:\n def target(self): pass\nclass A:\n def target(self): return 2\ndef caller(a): return a.target()\n",
        "decorators-comprehension": "@decorator(target())\ndef caller(arg=target()):\n values = [target() for target in things]\n return target()\n",
        "async-binding": "async def target(): pass\nasync def caller():\n target = external\n return await target()\n",
    }
    cases.extend((label, {"m.py": text.encode()}, (".",)) for label, text in authored.items())
    results = []
    for label, files, roots in cases:
        input_hashes = {path: hashlib.sha256(raw).hexdigest() for path, raw in files.items()}
        snapshot = Snapshot(
            "owned-equivalence",
            hashlib.sha256(canonical(input_hashes)).hexdigest(),
            tuple(
                Blob(path, hashlib.sha256(raw).hexdigest(), "100644", raw, None)
                for path, raw in sorted(files.items())
            ),
        )
        before, after = [], []
        for engine, destination in [(baseline, before), (candidate, after)]:
            cache = {}
            for mode in ["cold", "cache-hit"]:
                index = engine.build_index(snapshot, engine.IndexConfig(source_roots=roots), cache)
                destination.append(normalize(index))
        assert before == after, label
        results.append(
            {
                "case": label,
                "input_sha256": input_hashes,
                "module_count": len(before[0]["fields"][1][1]["tuple"]),
                "codeindex_all_fields_equal": True,
                "cold_and_cache_hit_equal": True,
                "canonical_output_sha256": hashlib.sha256(canonical(before)).hexdigest(),
            }
        )
    # Same cached Module, including duplicate unresolved Nodes, exercises exact membership semantics.
    raw = b"def target(): pass\ndef caller(): return target()\n"
    blob = Blob("m.py", hashlib.sha256(raw).hexdigest(), "100644", raw, None)
    snapshot = Snapshot("owned-equivalence", "duplicate-unresolved", (blob,))
    parsed = baseline.parse_module(blob, "m")
    from cami.models import Node

    nodes = (
        Node(path="m.py", qualname="target"),
        Node(path="m.py"),
        Node(path="m.py", qualname="target"),
    )
    modified = dataclasses.replace(parsed, unresolved=nodes)
    key = (blob.object_id, sys.version, baseline.INDEX_VERSION, "m.py", "m")
    old = baseline.build_index(snapshot, baseline.IndexConfig(), {key: modified})
    new = candidate.build_index(snapshot, candidate.IndexConfig(), {key: modified})
    assert normalize(old) == normalize(new)
    results.append(
        {
            "case": "cached-duplicate-unresolved-nodes",
            "codeindex_all_fields_equal": True,
            "unresolved_tuple_preserved": True,
            "canonical_output_sha256": hashlib.sha256(canonical(normalize(old))).hexdigest(),
        }
    )
    report = {
        "status": "passed",
        "changed_source_files": changes,
        "baseline_index_sha256": sha(BASE / "cami/index.py"),
        "candidate_index_sha256": sha(CANDIDATE / "cami/index.py"),
        "candidate_files": {name: sha(CANDIDATE / name) for name in pin["files"]},
        "baseline_files": pin["files"],
        "all_other_core_files_byte_identical": True,
        "cases": results,
        "models": 0,
        "target_source_executed": False,
        "comparison": "All CodeIndex dataclass fields recursively, including nested Module/Definition fields, Pydantic model JSON, tuple order and frozenset values; cold and independent module-cache hits.",
    }
    (HERE / "equivalence.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"status": "passed", "cases": len(results)}))


if __name__ == "__main__":
    main()
