"""Fresh-owned-copy no-model profile matrix; uses only local frozen runtime image."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(
            json.dumps(
                {
                    "status": "plan_only",
                    "new_preparations": 3,
                    "profiled_lookups": 15,
                    "model_calls": 0,
                    "network": "none",
                }
            )
        )
        return
    if (
        not args.out
        or args.out.exists()
        or not args.out.resolve().is_relative_to(
            ROOT / "runs/opencode-membership-candidate-20261106"
        )
    ):
        parser.error("new output directory under profile stage required")
    output = args.out.resolve()
    if shutil.disk_usage(ROOT).free < 5 * 1024**3:
        raise ValueError("study requires5GiB minimum free storage")
    sys.path.insert(0, str(ROOT / "scripts/opencode_benchmark/controller"))
    from study_common import chown, file_hashes
    from study_runtime import container, origin_memory
    from study_workspace import create_namespace, reset

    study_path = ROOT / "runs/opencode-development-v5-20261104/frozen-study.json"
    study = json.loads(study_path.read_bytes())
    for name in ("production", "adapter"):
        pin = study["pins"][name]
        if any(
            sha(Path(pin["root"]) / path) != expected for path, expected in pin["files"].items()
        ):
            raise ValueError("frozen runtime source changed")
    equivalence = json.loads((HERE / "equivalence.json").read_bytes())
    candidate_source = HERE / "candidate-source"
    for name, expected in equivalence["candidate_files"].items():
        if sha(candidate_source / name) != expected:
            raise ValueError("candidate frozen source changed")
    assert equivalence["changed_source_files"] == ["cami/index.py"]
    study["cami_source"] = str(candidate_source)
    study["pins"]["production"] = {
        "root": str(candidate_source),
        "files": equivalence["candidate_files"],
    }
    bundle = Path(study["bundle_path"])
    original_tasks = study["normalized"]["tasks"]
    tasks = [original_tasks[0], original_tasks[1]]
    message_path = (
        ROOT
        / "runs/opencode-development-v5-20261104/trials/r1-cami-s1/session/evidence/messages.json"
    )
    messages = json.loads(message_path.read_bytes())
    arguments = next(
        part["state"]["input"]
        for message in messages
        for part in message.get("content", [])
        if part.get("name", "").endswith("_memory_lookup")
    )
    output.mkdir(parents=True)
    save(
        output / "profile-plan.json",
        {
            "status": "frozen_before_profile_execution",
            "study_sha256": sha(study_path),
            "image": study["image"],
            "arguments": arguments,
            "argument_source_sha256": sha(message_path),
            "repetitions": 3,
            "backends": ["cami"],
            "cases_per_namespace": [
                "origin-cold",
                "origin-cold-same-process-repeat",
                "origin-unchanged-new-process",
                "changed-new-process",
                "changed-unchanged-new-process",
            ],
            "profiled_lookup_scope": "actual compact MCP dispatch; profiler overhead explicit; no inference of model task quality or speedup",
            "host_concurrency": "parent broader correctness tests may overlap; attribution only, not quiet timing confirmation",
            "source_pins": {name: study["pins"][name] for name in ("production", "adapter")},
            "preparation_worker_sha256": sha(
                ROOT / "scripts/opencode_benchmark/controller/preparation_worker.py"
            ),
            "worker_sha256": sha(HERE / "profile_worker.py"),
            "orchestrator_sha256": sha(Path(__file__)),
            "model_calls": 0,
            "network": "none",
        },
    )
    summary = {
        "status": "started",
        "cases": [],
        "model_calls": 0,
        "Docker_calls": 0,
        "fresh_namespaces": 3,
        "original_v5_namespace_mutations": False,
    }
    try:
        for repetition in range(1, 4):
            for backend in ("cami",):
                namespace = output / f"r{repetition}-{backend}"
                create_namespace(namespace, sha(study_path))
                reset_record = reset(
                    namespace,
                    bundle / tasks[0]["archive"],
                    tasks[0]["archive_sha256"],
                    sha(study_path),
                )
                save(namespace / "origin-reset.json", reset_record)
                workspace, memory = namespace / "workspace", namespace / "memory"
                origin_memory(study, workspace, memory, namespace / "preparation", backend)
                summary["Docker_calls"] += 1
                for label in [
                    "origin-cold",
                    "origin-unchanged-new-process",
                    "changed-new-process",
                    "changed-unchanged-new-process",
                ]:
                    if label == "changed-new-process":
                        save(
                            namespace / "changed-reset.json",
                            reset(
                                namespace,
                                bundle / tasks[1]["archive"],
                                tasks[1]["archive_sha256"],
                                sha(study_path),
                            ),
                        )
                        chown(workspace)
                    case = namespace / label
                    case.mkdir()
                    save(case / "config.json", {"arguments": arguments})
                    chown(case)
                    command = ["python", "/opt/profile_worker.py", "--label", label]
                    if label == "origin-cold":
                        command += ["--same-process-repeat"]
                    result = container(
                        study,
                        [
                            (workspace, "/workspace", False),
                            (memory, "/memory", False),
                            (Path(study["cami_source"]), "/opt/cami-src", True),
                            (Path(study["adapter"]), "/opt/memory-adapter", True),
                            (HERE / "profile_worker.py", "/opt/profile_worker.py", True),
                            (case, "/check", False),
                        ],
                        command,
                        case / "container",
                        timeout=300,
                        pythonpath="/opt/memory-adapter:/opt/cami-src:/opt/cami-deps",
                    )
                    summary["Docker_calls"] += 1
                    report = json.loads((case / "report.json").read_bytes())
                    if result["status"] != "passed" or report["status"] != "passed":
                        raise ValueError("profile case failed, original outputs preserved")
                    summary["cases"].append(
                        {
                            "namespace": namespace.name,
                            "backend": backend,
                            "repetition": repetition,
                            "case": label,
                            "report": report,
                        }
                    )
                    print(
                        json.dumps(
                            {"status": "case_complete", "namespace": namespace.name, "case": label}
                        ),
                        flush=True,
                    )
                # Fresh diagnostic state is kept; it is not an original benchmark namespace.
        if shutil.disk_usage(ROOT).free < 5 * 1024**3:
            raise ValueError("post-run minimum free space failed")
        summary["status"] = "passed"
    except BaseException as error:
        summary.update(status="failed", error=type(error).__name__ + ": " + str(error))
        raise
    finally:
        summary["artifact_hashes"] = file_hashes(output)
        save(output / "report.json", summary)


if __name__ == "__main__":
    main()
