"""Compare sealed baseline/candidate attribution and portable actual MCP output."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import pstats
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = ROOT / "runs/opencode-lookup-profile-20261106/profile-v1"
CANDIDATE = HERE / "profile-v1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def stats(values):
    return {
        "n": len(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "samples": values,
    }


def attributes(profile):
    result = {
        "index_pydantic_equality_calls": 0,
        "index_pydantic_equality_cumulative_seconds_nonadditive": 0,
        "build_index_cumulative_seconds_nonadditive": 0,
        "build_index_tottime_seconds": 0,
        "build_index_calls": 0,
        "profile_total_tottime_seconds": profile.total_tt,
    }
    for (filename, _, name), (_, calls, own, cumulative, callers) in profile.stats.items():
        if filename == "/opt/cami-src/cami/index.py" and name == "build_index":
            result.update(
                build_index_cumulative_seconds_nonadditive=cumulative,
                build_index_tottime_seconds=own,
                build_index_calls=calls,
            )
        if filename.endswith("/pydantic/main.py") and name == "__eq__":
            for (caller_file, _, caller_name), values in callers.items():
                if caller_file == "/opt/cami-src/cami/index.py" and caller_name == "build_index":
                    result["index_pydantic_equality_calls"] += values[1]
                    result["index_pydantic_equality_cumulative_seconds_nonadditive"] += values[3]
    return result


def main():
    original, candidate = load(BASE / "report.json"), load(CANDIDATE / "report.json")
    assert original["status"] == candidate["status"] == "passed"
    for root, report in [(BASE, original), (CANDIDATE, candidate)]:
        for name, expected in report["artifact_hashes"].items():
            assert sha(root / name) == expected, str(root / name)
    rows = []
    for container_case in candidate["cases"]:
        namespace, label = container_case["namespace"], container_case["case"]
        original_case = next(
            row
            for row in original["cases"]
            if row["namespace"] == namespace and row["case"] == label
        )
        for old, new in zip(
            original_case["report"]["cases"], container_case["report"]["cases"], strict=True
        ):
            assert old["label"] == new["label"]
            case = new["label"]
            profiles = []
            payloads = []
            for root in (BASE, CANDIDATE):
                directory = root / namespace / label
                profiles.append(attributes(pstats.Stats(str(directory / (case + ".prof")))))
                result = load(directory / (case + "-mcp-result.json"))
                assert result["isError"] is False
                value = json.loads(result["content"][0]["text"])
                assert value.pop("audit_receipt", None)
                payloads.append(value)
            assert payloads[0] == payloads[1], (namespace, case)
            assert (
                old["returned_ids"] == new["returned_ids"]
                and old["withheld_ids"] == new["withheld_ids"]
            )
            rows.append(
                {
                    "namespace": namespace,
                    "case": case,
                    "portable_mcp_content_equal_except_receipt": True,
                    "returned_ids": new["returned_ids"],
                    "withheld_ids": new["withheld_ids"],
                    "baseline": profiles[0],
                    "candidate": profiles[1],
                    "baseline_instrumented_dispatch_wall_seconds": old[
                        "profiled_dispatch_wall_seconds"
                    ],
                    "candidate_instrumented_dispatch_wall_seconds": new[
                        "profiled_dispatch_wall_seconds"
                    ],
                }
            )
    assert len(rows) == 15
    changed = [row for row in rows if row["case"] == "changed-new-process"]
    assert len(changed) == 3
    summary = {
        side: {key: stats([row[side][key] for row in changed]) for key in changed[0][side]}
        for side in ("baseline", "candidate")
    }
    for namespace in ("r1-cami", "r2-cami", "r3-cami"):
        assert (BASE / namespace / "memory/prepared/catalog.json").read_bytes() == (
            CANDIDATE / namespace / "memory/prepared/catalog.json"
        ).read_bytes()
    source = load(HERE / "equivalence.json")
    for name, expected in source["candidate_files"].items():
        assert sha(HERE / "candidate-source" / name) == expected
    baseline_manifest = ROOT / "runs/opencode-lookup-profile-20261106/baseline-manifest.json"
    manifest = load(baseline_manifest)
    for name, expected in manifest["files"].items():
        assert sha(baseline_manifest.parent / name) == expected
    report = {
        "status": "candidate_attribution_and_equivalence_passed",
        "all_other_core_files_identical": True,
        "only_core_change": "index.py local frozenset(module.unresolved), membership uses it",
        "equivalence_cases": len(source["cases"]),
        "actual_dispatch_comparisons": len(rows),
        "portable_mcp_contents_identical": True,
        "changed_snapshot_profile_samples": 3,
        "changed_snapshot_attribution": summary,
        "rows": rows,
        "baseline_manifest_sha256": sha(baseline_manifest),
        "candidate_index_sha256": source["candidate_index_sha256"],
        "baseline_index_sha256": source["baseline_index_sha256"],
        "raw_candidate_report_sha256": sha(CANDIDATE / "report.json"),
        "baseline_manifest_still_intact": True,
        "model_calls": 0,
        "production_edits_by_this_agent": False,
        "timing_status": "Attribution only: cProfile overhead and concurrent parent correctness tests. No end-to-end or unprofiled speedup conclusion.",
        "quiet_AB_ready": True,
        "quiet_AB_note": "Use fresh independent states and same canonical/query sequence; interleave5unprofiled A/B changed transitions before any latency claim. Preparation separate, source/index/MCP equality mandatory.",
    }
    (HERE / "comparison.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(
        json.dumps(
            {"status": report["status"], "cases": 15, "changed_profile_summary": summary}, indent=2
        )
    )


if __name__ == "__main__":
    main()
