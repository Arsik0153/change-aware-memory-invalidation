# Frozen v5 adapter lookup CPU attribution baseline

Thirty actual compact MCP dispatch calls passed on six fresh owned static/CAMI namespaces, with three repetitions per backend. Source/state are new copies; no original v5 namespace was mounted or changed. Six origin preparations are separately recorded. Containers used the exact frozen v5 image, production and adapter sources, UID65534, two CPU limit,2GiB memory and network none. No model/auth/provider calls, heldout access, network fetches or production edits occurred.

The matrix per namespace is origin cold process, origin same-process repeat, unchanged-origin new process, changed canonical stage3 new process, and unchanged-stage3 new process. Each query uses the same frozen first CAMI query arguments. All329 catalog records are retained. New-process means Python/MCP process cold, not a flushed OS/page cache. Original fixed canonical archives are reset as fresh single-commit repositories; no upstream history, generated patch or gold source is used.

`profile-v1/profile-plan.json` was written before profile execution and pins source, worker, query, image and concurrent-work caveat. `profile-v1/report.json` binds2431 artifacts, including30 raw `.prof` binaries and full-path per-function JSON, actual full/compact MCP result evidence, backend traces, source resets, resources and cleanup. `baseline-summary.json` independently verifies these hashes, raw.prof↔JSON totals, profile-exclusive group sums, frozen source pins, and unchanged original36 terminal hashes. Original namespaces are not traversed in that verification.

| Profiled dispatch case, median/range seconds (n3) | Static | CAMI |
| --- | ---: | ---: |
| origin cold | 0.0110 /0.0106–0.0141 | 1.455 /1.449–1.469 |
| origin same-process repeat | 0.0102 /0.0101–0.0161 | 1.041 /1.006–1.134 |
| unchanged-origin new process | 0.0113 /0.0110–0.0129 | 1.512 /1.448–1.605 |
| changed canonical new process | 0.0107 /0.0105–0.0113 | 4.650 /4.517–4.744 |
| unchanged-stage3 new process | 0.0107 /0.0104–0.0107 | 1.634 /1.580–1.663 |

These are instrumented attribution timings: cProfile slows execution, and short unrelated pure/no-model correctness work could overlap. They are not quiet benchmark confirmation, a measured optimization, or an end-to-end model speedup. Preparation is excluded from dispatch profiles; adapter imports before Server construction are excluded, while first CAMI import inside lookup is included as in the original backend timer. Profile cumulative frames overlap and must not be summed. Only exclusive `tottime` groups partition the total. C calls and file waits can contribute wall time; process CPU is separately recorded.

Changed-snapshot findings across all three profiles:

- `index.build_index`: one call, cumulative median1.968s (1.869–1.991). Its unresolved-membership tuple scan causes106075 Pydantic `Node` equality calls in the first sample, about0.248s cumulative. A local `frozenset(module.unresolved)` is a small, directly measured candidate that preserves membership semantics.
- `validation.matches`:331calls, cumulative median0.437s (0.433–0.482). Exact-subject scans cause169472 equality calls in the first sample. An operation-lifetime index may help later, but needs explicit duplicate/ambiguity handling and protection against stale `CodeView.model_copy`; it is not the first change.
- `ast._splitlines_no_ff`:512calls, cumulative median0.359s (0.323–0.360). `get_source_segment` repeatedly splits module strings. Any later reuse must preserve this structural source-segment recipe exactly and not substitute literal-source-prefix semantics.
- `ProductMemory.observe` has zero calls on the actual adapter route. `refresh` calls repository capture/index/validation; standalone observe latency is not measured. The first changed profile records3 repository captures and31 literal-source preparations; these are operation-path observations, not proof that a correctness guard can be removed.

Root will consider only the local unresolved-membership set first, comparing identical index output semantics and new side-by-side profiles before any full-model work. No Rust rewrite or broader caching is justified by this baseline alone. The read-only historical cost diagnosis remains separately sealed under `runs/opencode-v5-cost-diagnosis-20261106`; it bounds all measured memory construction+execution at1.86% of CAMI's original charged task wall on a fixed trace.

## Reproduce as a separate NEW owned profile run

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python runs/opencode-lookup-profile-20261106/run_profiles.py --run --out runs/opencode-lookup-profile-20261106/NEW_OUTPUT
```

Default without `--run` is plan-only. The orchestrator refuses existing output and requires5GiB free disk before/after. `profile_worker.py` dispatches the actual frozen adapter handler, never executes target source, and records failure outputs. `summarize_profiles.py` regenerates the summary from the sealed original baseline; it does not rerun a lookup. All container resource/cleanup reports are retained. State copies remain isolated and are not shared with future candidate namespaces.
