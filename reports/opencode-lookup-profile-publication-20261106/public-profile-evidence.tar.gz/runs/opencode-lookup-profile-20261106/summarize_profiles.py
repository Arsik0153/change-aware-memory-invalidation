"""Verify owned profiler artifacts and summarize exclusive and nonadditive costs."""

from __future__ import annotations

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import pstats
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = HERE / "profile-v1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def stats(values):
    return {
        "n": len(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "sum": sum(values),
    }


def group(filename, name):
    if "sqlite" in filename.lower() or "sqlite" in name.lower():
        return "sqlite"
    if "pydantic" in filename.lower() or "pydantic" in name.lower():
        return "pydantic"
    if "importlib" in filename or "marshal.loads" in name:
        return "import_machinery"
    if (
        filename.endswith(("/ast.py", "/tokenize.py"))
        or name == "<built-in method builtins.compile>"
    ):
        return "python_ast_tokenizer_compile"
    if filename.endswith(("/python_excerpt.py", "/validation.py")):
        return "literal_predicate_validation"
    if filename.endswith(
        ("/worktree.py", "/git_snapshot.py", "/snapshot.py", "/repository.py", "/repo.py")
    ):
        return "repository_capture"
    if filename.endswith(
        ("/index.py", "/symbol_search.py", "/product/store.py", "/memory/adapters.py")
    ):
        return "index_and_view_projection"
    if "/json/" in filename or "_json." in name:
        return "json"
    if filename.endswith("/pathlib.py") or "posix." in name or "io." in name:
        return "filesystem_io"
    if filename.endswith(("/product/service.py", "/memory/store.py", "/memory/models.py")):
        return "memory_coordination_models_store"
    if filename.startswith("/opt/memory-adapter/"):
        return "adapter"
    return "other"


def main():
    original = load(DATA / "report.json")
    assert original["status"] == "passed" and len(original["cases"]) == 24
    for name, expected in original["artifact_hashes"].items():
        assert sha(DATA / name) == expected, name
    rows, functions, target_callers = [], defaultdict(list), []
    for container_case in original["cases"]:
        directory = DATA / container_case["namespace"] / container_case["case"]
        events = [
            json.loads(line)
            for line in (directory / "backend-trace.jsonl").read_text().splitlines()
        ]
        lookups = [event for event in events if event.get("event") == "memory_lookup"]
        assert len(lookups) == len(container_case["report"]["cases"])
        for case, event in zip(container_case["report"]["cases"], lookups, strict=True):
            label = case["label"]
            profile = pstats.Stats(str(directory / (label + ".prof")))
            saved = load(directory / (label + "-profile.json"))
            assert abs(profile.total_tt - saved["total_tottime_seconds"]) < 1e-10
            groups = defaultdict(float)
            selected = {}
            for (filename, line, name), (
                primitive,
                calls,
                own,
                cumulative,
                callers,
            ) in profile.stats.items():
                groups[group(filename, name)] += own
                key = filename + ":" + str(line) + ":" + name
                if any(
                    name == target
                    for target in [
                        "matches",
                        "build_index",
                        "parse_module",
                        "project",
                        "refresh",
                        "observe",
                        "capture",
                        "prepare_python_excerpt_source",
                        "_splitlines_no_ff",
                        "get_source_segment",
                        "__eq__",
                    ]
                ):
                    value = {
                        "filename": filename,
                        "line": line,
                        "function": name,
                        "calls": calls,
                        "primitive_calls": primitive,
                        "tottime_seconds": own,
                        "cumulative_seconds_nonadditive": cumulative,
                    }
                    selected[key] = value
                    functions[(container_case["backend"], label, key)].append(value)
                if filename.endswith("/pydantic/main.py") and name == "__eq__":
                    target_callers.append(
                        {
                            "namespace": container_case["namespace"],
                            "case": label,
                            "callers_nonadditive": [
                                {
                                    "filename": key[0],
                                    "line": key[1],
                                    "function": key[2],
                                    "pstats_call_counts_and_times": value,
                                }
                                for key, value in sorted(
                                    callers.items(), key=lambda x: x[1][-1], reverse=True
                                )[:12]
                            ],
                        }
                    )
            assert abs(sum(groups.values()) - profile.total_tt) < 1e-8
            assert event["error"] is None and event["selected_records"] == len(
                case["returned_ids"]
            ) + len(case["withheld_ids"])
            rows.append(
                {
                    "namespace": container_case["namespace"],
                    "backend": container_case["backend"],
                    "repetition": container_case["repetition"],
                    "case": label,
                    "dispatch_profiled_wall_seconds": case["profiled_dispatch_wall_seconds"],
                    "dispatch_profiled_process_cpu_seconds": case[
                        "profiled_dispatch_process_cpu_seconds"
                    ],
                    "profile_total_tottime_seconds": profile.total_tt,
                    "exclusive_tottime_groups_seconds": dict(groups),
                    "focus_functions_nonadditive": selected,
                    "backend_trace_without_payload": {
                        k: v for k, v in event.items() if k != "response_audit"
                    },
                    "returned_ids": case["returned_ids"],
                    "withheld_ids": case["withheld_ids"],
                    "profile_sha256": sha(directory / (label + ".prof")),
                    "profile_json_sha256": sha(directory / (label + "-profile.json")),
                }
            )
    summaries = []
    for backend in ["static", "cami"]:
        for case in sorted({row["case"] for row in rows}):
            selected = [row for row in rows if row["backend"] == backend and row["case"] == case]
            assert len(selected) == 3
            summaries.append(
                {
                    "backend": backend,
                    "case": case,
                    "profiled_dispatch_wall_seconds": stats(
                        [row["dispatch_profiled_wall_seconds"] for row in selected]
                    ),
                    "exclusive_tottime_groups_seconds": {
                        name: stats(
                            [
                                row["exclusive_tottime_groups_seconds"].get(name, 0)
                                for row in selected
                            ]
                        )
                        for name in sorted(
                            {
                                key
                                for row in selected
                                for key in row["exclusive_tottime_groups_seconds"]
                            }
                        )
                    },
                }
            )
    focus = [
        {
            "backend": backend,
            "case": case,
            "function_identity": identity,
            "calls": stats([value["calls"] for value in values]),
            "tottime_seconds": stats([value["tottime_seconds"] for value in values]),
            "cumulative_seconds_nonadditive": stats(
                [value["cumulative_seconds_nonadditive"] for value in values]
            ),
        }
        for (backend, case, identity), values in sorted(functions.items())
    ]
    source_identity = load(DATA / "profile-plan.json")["source_pins"]
    for pin in source_identity.values():
        for name, expected in pin["files"].items():
            assert sha(Path(pin["root"]) / name) == expected
    # Only original terminal hashes are rechecked; original namespaces are never traversed.
    old = load(ROOT / "runs/opencode-v5-cost-diagnosis-20261106/analysis-v2/report.json")[
        "inputs_sha256"
    ]
    originals = {
        path: expected for path, expected in old.items() if path.endswith("/terminal.json")
    }
    assert len(originals) == 36 and all(
        sha(Path(path)) == expected for path, expected in originals.items()
    )
    result = {
        "status": "sealed_baseline_profiles",
        "repetitions": 3,
        "fresh_namespaces": 6,
        "preparations": 6,
        "actual_compact_dispatch_calls": len(rows),
        "profile_artifact_hashes_verified": len(original["artifact_hashes"]),
        "runtime_image": load(DATA / "profile-plan.json")["image"],
        "python": original["cases"][0]["report"]["python"],
        "pydantic": original["cases"][0]["report"]["pydantic"],
        "summaries": summaries,
        "focus_functions_nonadditive": focus,
        "pydantic_equality_callers_nonadditive": target_callers,
        "rows": rows,
        "source_pins": source_identity,
        "original36_terminal_sha256_unchanged": originals,
        "observe_scope": "ProductMemory.observe has0calls in actual adapter lookup; refresh calls repository capture/index paths. No standalone observe latency claimed.",
        "preparation_scope": "Six preparations separately charged in each namespace/preparation and memory/prepared/construction-metrics.json. Never included in dispatch profiles.",
        "limitations": [
            "cProfile slows execution and reports inclusive overlapping frames. Cumulative function values must not be summed; only exclusive tottime groups partition profile total.",
            "Short unrelated container/pure correctness checks may overlap. These are attribution samples, not quiet unprofiled benchmark confirmation.",
            "All samples use original frozen image/source and full329-record literal catalog on fresh owned canonical/state copies; no original v5 namespace is mounted writable.",
            "Cold means new Python/MCP process. Filesystem/page caches may be warm; no machine-wide cache flush.",
            "No model task quality/success/causal benefit is measured here.",
        ],
        "model_calls": 0,
        "heldout_reads": False,
        "network": "none",
        "production_edits": False,
    }
    (HERE / "baseline-summary.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": result["status"],
                "lookups": len(rows),
                "profile_hashes_verified": result["profile_artifact_hashes_verified"],
            }
        )
    )


if __name__ == "__main__":
    main()
