"""Grade one observed stopped-v4 static source; never repair the original trial."""

from datetime import datetime, UTC
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CONTROLLER = ROOT / "scripts/opencode_benchmark/controller"
sys.path.insert(0, str(CONTROLLER))

from study_common import digest, file_hashes, inventory, read, verify_files, write  # noqa: E402
from study_runtime import grade, regression_allowance  # noqa: E402
from study_workspace import capture  # noqa: E402


def main():
    evidence = OUT / "evidence"
    evidence.mkdir(exist_ok=False)
    run = ROOT / "runs/opencode-development-v4-20261104"
    directory = run / "trials/r1-static-s1"
    workspace = run / "namespaces/r1-static/workspace"
    study = read(run / "frozen-study.json")
    require_files = ["study_workspace.py", "study_runtime.py", "study_common.py", "fixed_grader.py"]
    controller_before = {name: digest(CONTROLLER / name) for name in require_files}
    expected = study["pins"]["controller"]["files"]
    assert all(controller_before[name] == expected[name] for name in require_files)
    original_terminal = read(directory / "terminal.json")
    assert original_terminal["trial"]["id"] == "r1-static-s1"
    assert study["bundle_kind"] == "development"
    verify_files(directory, original_terminal["artifact_hashes"])
    actual = {name: value["sha256"] for name, value in inventory(directory).items() if name != "terminal.json"}
    assert actual == original_terminal["artifact_hashes"]
    trial_before = file_hashes(directory)
    workspace_before = inventory(workspace, omit_git=True, describe_nonregular=True)
    source_before = inventory(workspace / "src")
    write(evidence / "input-observation.json", {
        "observed_utc": datetime.now(UTC).isoformat(),
        "run": str(run), "workspace": str(workspace),
        "original_terminal_sha256": digest(directory / "terminal.json"),
        "frozen_study_sha256": digest(run / "frozen-study.json"),
        "canonical_reset_sha256": digest(directory / "canonical-reset.json"),
        "controller_files": controller_before,
        "original_terminal_artifact_hashes": original_terminal["artifact_hashes"],
        "workspace_files_before": workspace_before, "source_before": source_before,
        "capture_semantics": "One current quiet-window source observation, not a retroactive claim that uncaptured terminal-time bytes were pinned.",
    })
    result = None
    failure = None
    try:
        (task,) = [t for t in study["normalized"]["tasks"] if t["id"] == original_terminal["trial"]["task"]]
        allowance_path = run / "baselines" / task["id"] / "allowance.json"
        assert allowance_path.is_file()  # No new baseline/model or hidden recomputation.
        allowance, allowance_sha = regression_allowance(study, task, workspace, run)
        patch = capture(workspace, read(directory / "canonical-reset.json")["canonical_files"], evidence / "candidate")
        assert inventory(evidence / "candidate/src") == source_before
        result = grade(study, task, evidence / "candidate", evidence / "grading", allowance=allowance)
        write(evidence / "retrospective-result.json", {
            "retrospective_quality": result["status"], "existing_baseline_allowance_sha256": allowance_sha,
            "source_patch_sha256": digest(evidence / "candidate/source-patch.json"),
            "source_changed_paths": patch["changed"], "source_added_paths": patch["added"], "source_deleted_paths": patch["deleted"],
            "outcomes": result["outcomes"], "model_calls_made": 0,
        })
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error)}
        write(evidence / "failure.json", failure)
        raise
    finally:
        source_after = inventory(workspace / "src")
        workspace_after = inventory(workspace, omit_git=True, describe_nonregular=True)
        terminal_after = file_hashes(directory)
        controller_after = {name: digest(CONTROLLER / name) for name in require_files}
        checks = {"source_before_after_equal": source_before == source_after,
                  "workspace_before_after_equal": workspace_before == workspace_after,
                  "original_trial_before_after_equal": trial_before == terminal_after,
                  "grading_controller_before_after_equal": controller_before == controller_after}
        write(evidence / "immutability-checks.json", {**checks, "source_after": source_after, "controller_after": controller_after})
        summary = {
            "status": "retrospective_complete" if result is not None and failure is None and all(checks.values()) else "retrospective_failed_preserved",
            "analysis_kind": "separate_retrospective_fixed_grading_not_primary_trial_repair",
            "original_trial": "r1-static-s1",
            "original_terminal_status": original_terminal.get("status"),
            "original_quality": original_terminal.get("quality"),
            "original_session_status": original_terminal.get("session_status"),
            "original_operational_status": original_terminal.get("operational_status"),
            "retrospective_quality": result["status"] if result else None,
            "outcome_counts": {k: v["counts"] for k, v in result["outcomes"].items()} if result else None,
            "model_calls_made": 0, "observed_model_solutions": 1, "alternative_candidates": 0,
            "not_pooled_with_primary_quality": True, "primary_study_admission_changed": False,
            "heldout_access": False, "original_inputs_changed": not all(checks.values()),
            "checks": checks, "image": study["image"], "network": "none",
            "failure": failure, "evidence_hashes": file_hashes(evidence),
        }
        write(OUT / "summary.json", summary)
        assert all(checks.values())
    print(json.dumps({k: summary[k] for k in ["status", "original_terminal_status", "original_quality", "retrospective_quality", "outcome_counts", "model_calls_made", "checks"]}, sort_keys=True))


if __name__ == "__main__":
    main()
