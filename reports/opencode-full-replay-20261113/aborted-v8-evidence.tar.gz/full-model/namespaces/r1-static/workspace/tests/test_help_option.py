import pytest

import click


class CustomOption(click.Option):
    pass


@pytest.fixture(params=["automatic", "direct", "decorator", "custom_cls"])
def help_command(request):
    @click.command(add_help_option=request.param == "automatic")
    @click.argument("required")
    def cli(required):
        click.echo(required)

    if request.param == "direct":
        cli.params.append(click.HelpOption())
    elif request.param == "decorator":
        click.help_option()(cli)
    elif request.param == "custom_cls":
        click.help_option(cls=CustomOption)(cli)

    return cli


def test_defaults(help_command):
    ctx = click.Context(help_command)
    option = help_command.get_params(ctx)[-1]
    assert isinstance(option, click.Option)
    assert isinstance(option, (click.HelpOption, CustomOption))
    assert option.opts == ["--help"]
    assert option.is_flag
    assert option.is_eager
    assert not option.expose_value
    assert option.help == "Show this message and exit."
    assert option.callback is click.HelpOption.show_help


def test_prints_help_and_exits_eagerly(runner, help_command):
    result = runner.invoke(help_command, ["--help"])
    assert result.exit_code == 0
    assert result.output.splitlines() == [
        "Usage: cli [OPTIONS] REQUIRED",
        "",
        "Options:",
        "  --help  Show this message and exit.",
    ]


def test_absent_flag_does_not_expose_value(runner, help_command):
    result = runner.invoke(help_command, ["value"])
    assert result.exit_code == 0
    assert result.output == "value\n"


def test_resilient_parsing(help_command, capsys):
    with help_command.make_context("cli", ["--help"], resilient_parsing=True) as ctx:
        assert "help" not in ctx.params

    assert capsys.readouterr().out == ""


@pytest.mark.parametrize(
    ("runner_color", "context_color", "expected_color"),
    [
        (False, None, False),
        (True, None, True),
        (True, False, False),
        (False, True, True),
    ],
)
def test_color(runner, help_command, runner_color, context_color, expected_color):
    styled = click.style("Help text", fg="green")
    help_command.help = styled
    help_command.context_settings["color"] = context_color
    result = runner.invoke(help_command, ["--help"], color=runner_color)
    assert result.exit_code == 0
    assert (styled in result.output) == expected_color
    assert "Help text" in result.output


@pytest.mark.parametrize("param_decls", [None, (), []])
def test_default_names(param_decls):
    assert click.HelpOption(param_decls).opts == ["--help"]


@pytest.mark.parametrize("kind", ["automatic", "direct", "decorator", "custom_cls"])
def test_custom_names(runner, kind):
    names = ["-h", "--assist"]
    cli = click.Command(
        "cli",
        add_help_option=kind == "automatic",
        context_settings={"help_option_names": names},
    )

    if kind == "direct":
        cli.params.append(click.HelpOption(names))
    elif kind in {"decorator", "custom_cls"}:
        cls = CustomOption if kind == "custom_cls" else None
        click.help_option(*names, cls=cls)(cli)

    with cli.make_context("cli", []) as ctx:
        option = cli.get_params(ctx)[-1]
        assert set(option.opts) == set(names)

    for name in names:
        result = runner.invoke(cli, [name])
        assert result.exit_code == 0
        assert "-h, --assist  Show this message and exit." in result.output

    assert runner.invoke(cli, ["--help"]).exit_code == 2


@pytest.mark.parametrize(
    "settings", [{"add_help_option": False}, {"help_option_names": []}]
)
def test_disabled_automatic_help(runner, settings):
    add_help_option = settings.get("add_help_option", True)
    context_settings = {k: v for k, v in settings.items() if k != "add_help_option"}
    cli = click.Command(
        "cli", add_help_option=add_help_option, context_settings=context_settings
    )
    with cli.make_context("cli", []) as ctx:
        assert cli.get_help_option(ctx) is None
        assert cli.get_params(ctx) == []

    assert runner.invoke(cli, ["--help"]).exit_code == 2


def test_conflicting_automatic_names(runner):
    @click.command(context_settings={"help_option_names": ["-h", "--help"]})
    @click.option("--help", is_flag=True)
    def cli(help):
        click.echo(help)

    with cli.make_context("cli", []) as ctx:
        option = cli.get_help_option(ctx)
        assert isinstance(option, click.HelpOption)
        assert option.opts == ["-h"]

    assert runner.invoke(cli, ["--help"]).output == "True\n"
    assert "Show this message and exit." in runner.invoke(cli, ["-h"]).output

    cli.context_settings["help_option_names"] = ["--help"]
    with click.Context(cli) as ctx:
        assert cli.get_help_option(ctx) is None


@pytest.fixture(params=["direct", "decorator", "custom_cls"])
def make_option(request):
    def make(**attrs):
        if request.param == "direct":
            return click.HelpOption(**attrs)

        cli = click.Command("cli")
        cls = CustomOption if request.param == "custom_cls" else None
        click.help_option(cls=cls, **attrs)(cli)
        option = cli.params[0]
        assert type(option) is (CustomOption if cls is not None else click.HelpOption)
        return option

    return make


def test_keyword_overrides(runner, make_option):
    option = make_option(
        is_flag=False,
        is_eager=False,
        expose_value=True,
        help="Custom help",
        callback=None,
        default="default page",
        metavar="PAGE",
    )
    assert not option.is_flag
    assert not option.is_eager
    assert option.expose_value
    assert option.help == "Custom help"
    assert option.callback is None
    assert option.metavar == "PAGE"
    cli = click.Command(
        "cli",
        params=[option],
        add_help_option=False,
        callback=lambda help: click.echo(help),
    )
    result = runner.invoke(cli, ["--help", "topic"])
    assert result.exit_code == 0
    assert result.output == "topic\n"
    result = runner.invoke(cli)
    assert result.exit_code == 0
    assert result.output == "default page\n"


def test_callback_override(runner, make_option):
    def callback(ctx, param, value):
        assert param is option
        if value:
            click.echo("Custom callback")

    option = make_option(callback=callback, help=None)
    assert option.callback is callback
    assert option.help is None
    cli = click.Command("cli", params=[option], callback=lambda: click.echo("Command"))
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert result.output == "Custom callback\nCommand\n"
