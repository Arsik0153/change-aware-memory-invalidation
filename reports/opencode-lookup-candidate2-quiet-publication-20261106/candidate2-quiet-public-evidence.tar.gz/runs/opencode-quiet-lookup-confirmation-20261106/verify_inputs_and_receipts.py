"""Post-window source inventory, query, catalog and compact receipt checks."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "scripts/opencode_benchmark/analysis"))
from classify_literal_calls import authenticate_response, canonical  # noqa:E402


def main():
    data = HERE / "quiet-v1"
    report = json.loads((data / "report.json").read_bytes())
    plan = json.loads((data / "plan.json").read_bytes())
    query_hash = hashlib.sha256(canonical(plan["query"])).hexdigest()
    origins, changed, catalogs, receipts = [], [], [], []
    for attempt in report["attempts"]:
        namespace = data / f"b{attempt['block']}-{attempt['variant']}"
        origins.append(
            json.loads((namespace / "origin-reset.json").read_bytes())["canonical_files"]
        )
        changed.append(
            json.loads((namespace / "changed-reset.json").read_bytes())["canonical_files"]
        )
        catalogs.append((namespace / "memory/prepared/catalog.json").read_bytes())
        for container in attempt["cases"]:
            directory = namespace / container["container_case"]
            events = [
                json.loads(line)
                for line in (directory / "backend-trace.jsonl").read_text().splitlines()
            ]
            events = [event for event in events if event["event"] == "memory_lookup"]
            for event, case in zip(events, container["worker"]["cases"], strict=True):
                result = json.loads((directory / (case["label"] + "-mcp-result.json")).read_bytes())
                assert event["query_sha256"] == query_hash
                full, mode = authenticate_response(result["content"][0]["text"], event)
                assert mode == "compact_verified" and full["query"] == plan["query"]["query"]
                receipts.append(
                    {
                        "block": attempt["block"],
                        "variant": attempt["variant"],
                        "case": case["label"],
                        "query_sha256": query_hash,
                        "receipt_sha256": event["response_audit"]["receipt_sha256"],
                    }
                )
    assert len(origins) == len(changed) == len(catalogs) == 15 and len(receipts) == 75
    assert all(value == origins[0] for value in origins)
    assert all(value == changed[0] for value in changed)
    assert all(value == catalogs[0] for value in catalogs)
    source = ROOT / "scripts/opencode_benchmark/analysis/classify_literal_calls.py"
    result = {
        "status": "passed",
        "source_inventory_equality": "all15origin and all15changed reset file hash/mode inventories exact",
        "origin_file_count": len(origins[0]),
        "changed_file_count": len(changed[0]),
        "all15catalog_bytes_equal": True,
        "catalog_raw_sha256": hashlib.sha256(catalogs[0]).hexdigest(),
        "query_hashes_verified": 75,
        "full_compact_receipts_verified": 75,
        "receipt_authenticator_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "receipts": receipts,
        "model_calls": 0,
    }
    (HERE / "additional-verification.json").write_text(
        json.dumps(result, sort_keys=True, indent=2) + "\n"
    )
    print(json.dumps({k: v for k, v in result.items() if k != "receipts"}))


if __name__ == "__main__":
    main()
