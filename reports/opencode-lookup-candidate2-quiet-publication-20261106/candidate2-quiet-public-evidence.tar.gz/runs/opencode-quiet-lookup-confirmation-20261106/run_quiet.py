"""Five prospective interleaved baseline/c1/c2 offline blocks, fresh state each variant."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
FROZEN = ROOT / "runs/opencode-indexed-transition-candidate-20261106"
ORDERS = [
    ["baseline", "candidate1", "candidate2"],
    ["candidate1", "candidate2", "baseline"],
    ["candidate2", "baseline", "candidate1"],
    ["baseline", "candidate2", "candidate1"],
    ["candidate2", "candidate1", "baseline"],
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def command(argv):
    result = subprocess.run(argv, capture_output=True, text=True, timeout=30)
    return {
        "argv": argv,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def concurrency():
    processes = {}
    for path in Path("/proc").iterdir():
        if not path.name.isdigit():
            continue
        try:
            raw = (path / "stat").read_text()
            tail = raw.rsplit(")", 1)[1].split()
            processes[path.name] = {
                "comm": raw.split("(", 1)[1].rsplit(")", 1)[0],
                "state": tail[0],
                "ppid": int(tail[1]),
                "cpu_ticks_self": int(tail[11]) + int(tail[12]),
            }
        except (OSError, ValueError, IndexError):
            continue
    return {
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "loadavg": Path("/proc/loadavg").read_text().strip(),
        "uptime": command(["uptime"]),
        "nproc": command(["nproc"]),
        "proc_stat": Path("/proc/stat").read_text(),
        "processes_no_arguments_or_environment": processes,
        "clock_ticks": os.sysconf("SC_CLK_TCK"),
        "running_docker": command(
            [
                "docker",
                "--host=unix:///var/run/docker.sock",
                "ps",
                "--format",
                "{{.ID}} {{.Names}} {{.Status}}",
            ]
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if not args.run:
        print(
            json.dumps(
                {
                    "status": "plan_only",
                    "blocks": 5,
                    "orders": ORDERS,
                    "fresh_namespaces": 15,
                    "lookups": 75,
                    "model_calls": 0,
                }
            )
        )
        return
    if not args.out or args.out.exists() or not args.out.resolve().is_relative_to(HERE):
        parser.error("NEW output under quiet stage required")
    if shutil.disk_usage(ROOT).free < 5 * 1024**3:
        raise ValueError("requires5GiB free disk")
    helper_dir = HERE / "controller-snapshot"
    helper_hashes = json.loads((FROZEN / "source-freeze.json").read_bytes())[
        "controller_helper_snapshot"
    ]
    helper_dir.mkdir(exist_ok=False)
    for name, expected in helper_hashes.items():
        original = FROZEN / "controller-snapshot" / name
        assert sha(original) == expected
        shutil.copyfile(original, helper_dir / name)
    sys.path.insert(0, str(helper_dir))
    from study_common import bytes_used, chown, file_hashes
    from study_runtime import container, origin_memory
    from study_workspace import create_namespace, reset

    study_path = ROOT / "runs/opencode-development-v5-20261104/frozen-study.json"
    original = json.loads(study_path.read_bytes())
    variant_roots = {
        "baseline": Path(original["cami_source"]),
        "candidate1": ROOT / "runs/opencode-membership-candidate-20261106/candidate-source",
        "candidate2": FROZEN / "candidate-source",
    }
    pins = {
        "baseline": original["pins"]["production"]["files"],
        "candidate1": json.loads(
            (ROOT / "runs/opencode-membership-candidate-20261106/equivalence.json").read_bytes()
        )["candidate_files"],
        "candidate2": json.loads((FROZEN / "source-freeze.json").read_bytes())["candidate_files"],
    }
    for name, directory in variant_roots.items():
        for relative, expected in pins[name].items():
            assert sha(directory / relative) == expected
    for relative, expected in original["pins"]["adapter"]["files"].items():
        assert sha(Path(original["adapter"]) / relative) == expected
    output = args.out.resolve()
    output.mkdir(parents=True)
    arguments = json.loads((FROZEN / "profile-v1/profile-plan.json").read_bytes())["arguments"]
    plan = {
        "status": "prospective_before_execution",
        "claim": "On the fixed329literal local workload, measure whether candidate1 lowers changed-snapshot dispatch CPU/wall versus baseline and candidate2 lowers it further; no end-to-end/model claim.",
        "primary_case": "changed-new-process",
        "metrics": ["dispatch_wall_seconds", "dispatch_cpu_self_and_completed_children_seconds"],
        "noise_rule": "Report median/range and paired deltas. If absolute median difference <=max(within-side ranges), label no_measurable_difference; mixed paired signs remain inconclusive. No favorable omission.",
        "orders": ORDERS,
        "variants": {
            name: {"root": str(directory), "files": pins[name]}
            for name, directory in variant_roots.items()
        },
        "helper_snapshot": helper_hashes,
        "worker_sha256": sha(HERE / "quiet_worker.py"),
        "orchestrator_sha256": sha(Path(__file__)),
        "query": arguments,
        "study_sha256": sha(study_path),
        "image": original["image"],
        "limits": {"cpus": 2, "memory_bytes": 2147483648, "network": "none"},
        "limiter_evidence": "Separately sealed cProfile shows tuple membership and per-record definition scans; no new instrumentation inside timed dispatch.",
        "cases": [
            "origin-cold",
            "origin-cold-same-process-repeat",
            "origin-unchanged-new-process",
            "changed-new-process",
            "changed-unchanged-new-process",
        ],
        "construction": "Each variant/block pays fresh origin preparation; no reused DB. Source reset/materialization and final storage hashing separately timed; container lifecycle is nested separately.",
        "cold_scope": "Fresh Python/MCP process, not flushed OS caches.",
        "concurrency_before": concurrency(),
        "model_calls": 0,
    }
    save(output / "plan.json", plan)
    report = {
        "status": "started",
        "attempts": [],
        "model_calls": 0,
        "failures": [],
        "quiet_started_utc": plan["concurrency_before"]["utc"],
    }
    try:
        for block, order in enumerate(ORDERS, 1):
            for variant in order:
                phase_start, phase_cpu = time.perf_counter(), time.process_time()
                namespace = output / f"b{block}-{variant}"
                record = {
                    "block": block,
                    "variant": variant,
                    "status": "started",
                    "cases": [],
                    "concurrency_before": concurrency(),
                }
                try:
                    study = dict(original, cami_source=str(variant_roots[variant]))
                    study["pins"] = dict(
                        original["pins"],
                        production={"root": str(variant_roots[variant]), "files": pins[variant]},
                    )
                    bundle = Path(study["bundle_path"])
                    tasks = study["normalized"]["tasks"]
                    tick = time.perf_counter()
                    create_namespace(namespace, sha(study_path))
                    save(
                        namespace / "origin-reset.json",
                        reset(
                            namespace,
                            bundle / tasks[0]["archive"],
                            tasks[0]["archive_sha256"],
                            sha(study_path),
                        ),
                    )
                    record["origin_materialization_host_seconds"] = time.perf_counter() - tick
                    workspace, memory = namespace / "workspace", namespace / "memory"
                    tick = time.perf_counter()
                    origin_memory(study, workspace, memory, namespace / "preparation", "cami")
                    record["preparation_host_inclusive_seconds"] = time.perf_counter() - tick
                    for label in [
                        "origin-cold",
                        "origin-unchanged-new-process",
                        "changed-new-process",
                        "changed-unchanged-new-process",
                    ]:
                        if label == "changed-new-process":
                            tick = time.perf_counter()
                            save(
                                namespace / "changed-reset.json",
                                reset(
                                    namespace,
                                    bundle / tasks[1]["archive"],
                                    tasks[1]["archive_sha256"],
                                    sha(study_path),
                                ),
                            )
                            chown(workspace)
                            record["changed_source_update_host_seconds"] = (
                                time.perf_counter() - tick
                            )
                        case = namespace / label
                        case.mkdir()
                        save(case / "config.json", {"arguments": arguments})
                        chown(case)
                        argv = ["python", "/opt/quiet_worker.py", "--label", label]
                        if label == "origin-cold":
                            argv += ["--same-process-repeat"]
                        tick = time.perf_counter()
                        resource_report = container(
                            study,
                            [
                                (workspace, "/workspace", False),
                                (memory, "/memory", False),
                                (variant_roots[variant], "/opt/cami-src", True),
                                (Path(study["adapter"]), "/opt/memory-adapter", True),
                                (HERE / "quiet_worker.py", "/opt/quiet_worker.py", True),
                                (case, "/check", False),
                            ],
                            argv,
                            case / "container",
                            timeout=300,
                            pythonpath="/opt/memory-adapter:/opt/cami-src:/opt/cami-deps",
                        )
                        elapsed = time.perf_counter() - tick
                        value = json.loads((case / "report.json").read_bytes())
                        record["cases"].append(
                            {
                                "container_case": label,
                                "container_host_inclusive_seconds": elapsed,
                                "status": resource_report["status"],
                                "worker": value,
                            }
                        )
                        if resource_report["status"] != "passed" or value["status"] != "passed":
                            raise ValueError("case failure retained; no retry")
                    tick = time.perf_counter()
                    record["final_owned_storage_bytes"] = bytes_used(namespace)
                    record["final_memory_storage_bytes"] = bytes_used(memory)
                    record["artifact_hashes"] = file_hashes(namespace)
                    record["final_storage_observation_and_hashing_host_seconds"] = (
                        time.perf_counter() - tick
                    )
                    record["status"] = "passed"
                except BaseException as error:
                    record.update(status="failed", error=type(error).__name__ + ": " + str(error))
                    report["failures"].append(
                        {"block": block, "variant": variant, "error": record["error"]}
                    )
                finally:
                    record["host_variant_seconds_inclusive"] = time.perf_counter() - phase_start
                    record["host_orchestrator_self_cpu_seconds"] = time.process_time() - phase_cpu
                    record["concurrency_after"] = concurrency()
                    report["attempts"].append(record)
                    save(output / "progress.json", report)
                    print(
                        json.dumps(
                            {"block": block, "variant": variant, "status": record["status"]}
                        ),
                        flush=True,
                    )
        report["status"] = "passed" if not report["failures"] else "failed_attempts_preserved"
    finally:
        report["quiet_ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        report["concurrency_after"] = concurrency()
        report["disk_free_bytes_after"] = shutil.disk_usage(ROOT).free
        save(output / "report.json", report)


if __name__ == "__main__":
    main()
