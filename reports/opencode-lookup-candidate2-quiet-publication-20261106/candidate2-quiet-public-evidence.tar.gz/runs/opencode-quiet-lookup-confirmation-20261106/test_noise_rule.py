"""Fast authored controls for the prospective conservative decision rule."""

import unittest
from summarize_quiet import compare


class NoiseRuleChecks(unittest.TestCase):
    def test_five_favorable_pairs_do_not_override_large_spread(self):
        result = compare([1, 2, 1, 1, 1], [0.5, 1.5, 0.5, 0.5, 0.5])
        self.assertEqual(result["paired_positive"], 5)
        self.assertEqual(result["classification"], "no_measurable_difference")

    def test_clear_uniform_lower_time_is_identified(self):
        result = compare([2, 2.01, 2, 2.02, 2], [1.8, 1.82, 1.8, 1.81, 1.8])
        self.assertEqual(
            result["classification"], "lower_time_for_candidate_in_this_microbenchmark"
        )

    def test_mixed_pair_signs_remain_inconclusive(self):
        result = compare([1.7, 2, 2, 2, 2], [1.99, 1.69, 1.69, 1.69, 1.69])
        self.assertEqual(result["classification"], "inconclusive_nonuniform_paired_deltas")


if __name__ == "__main__":
    unittest.main()
