"""Unprofiled frozen adapter dispatch timing; no model, auth, network or target execution."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import resource
import sys
import time


def cpu():
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return time.process_time() + children.ru_utime + children.ru_stime


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", required=True)
    parser.add_argument("--same-process-repeat", action="store_true")
    args = parser.parse_args()
    if any("/workspace" in path for path in sys.path):
        raise ValueError("workspace import boundary violated")
    from memory_adapter import Server

    out = Path("/check")
    config = json.loads((out / "config.json").read_bytes())
    report = {"status": "started", "cases": [], "model_calls": 0, "profiling_enabled": False}
    try:
        server = Server(
            Path("/memory/prepared/binding.json"),
            out / "backend-trace.jsonl",
            response_format="compact",
        )
        server.dispatch(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {},
                    "clientInfo": {"name": "quiet-lookup-confirmation", "version": "1"},
                },
            }
        )
        server.dispatch({"jsonrpc": "2.0", "method": "notifications/initialized"})
        labels = [args.label] + (
            [args.label + "-same-process-repeat"] if args.same_process_repeat else []
        )
        for index, label in enumerate(labels):
            start, start_cpu = time.perf_counter(), cpu()
            result = server.dispatch(
                {
                    "jsonrpc": "2.0",
                    "id": index + 2,
                    "method": "tools/call",
                    "params": {"name": "memory_lookup", "arguments": config["arguments"]},
                }
            )
            wall, used_cpu = time.perf_counter() - start, cpu() - start_cpu
            save(out / (label + "-mcp-result.json"), result)
            value = json.loads(result["content"][0]["text"])
            if (
                result["isError"]
                or value.get("error")
                or value.get("response_format") != "research-memory-compact/1"
            ):
                raise ValueError("actual lookup failed")
            report["cases"].append(
                {
                    "label": label,
                    "dispatch_wall_seconds": wall,
                    "dispatch_cpu_self_and_completed_children_seconds": used_cpu,
                    "returned_ids": [entry["id"] for entry in value["entries"]],
                    "withheld_ids": [entry["id"] for entry in value["withheld"]],
                    "scope": "actual compact tools/call dispatch including first CAMI import/refresh/ranking/serialization/storage/trace append; excludes Python+adapter imports, constructor, result-file write and Docker lifecycle",
                }
            )
        report["status"] = "passed"
    except BaseException as error:
        report.update(status="failed", error=type(error).__name__ + ": " + str(error))
        raise
    finally:
        save(out / "report.json", report)


if __name__ == "__main__":
    main()
