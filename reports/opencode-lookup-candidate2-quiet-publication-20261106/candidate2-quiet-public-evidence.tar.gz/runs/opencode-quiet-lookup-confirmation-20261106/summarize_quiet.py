"""Post-window verification/statistics; never starts a lookup/model or changes inputs."""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = HERE / "quiet-v1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def stats(values):
    return {
        "n": len(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "range": max(values) - min(values),
        "samples": values,
    }


def compare(before, after):
    a, b = stats(before), stats(after)
    gap = a["median"] - b["median"]
    noise = max(a["range"], b["range"])
    paired = [x - y for x, y in zip(before, after, strict=True)]
    if abs(gap) <= noise:
        result = "no_measurable_difference"
    elif all(x > 0 for x in paired):
        result = "lower_time_for_candidate_in_this_microbenchmark"
    elif all(x < 0 for x in paired):
        result = "higher_time_for_candidate_in_this_microbenchmark"
    else:
        result = "inconclusive_nonuniform_paired_deltas"
    return {
        "before": a,
        "after": b,
        "median_difference_seconds": gap,
        "noise_range_threshold_seconds": noise,
        "paired_before_minus_after_seconds": paired,
        "paired_positive": sum(x > 0 for x in paired),
        "paired_negative": sum(x < 0 for x in paired),
        "classification": result,
        "descriptive_median_fraction_lower": gap / a["median"] if a["median"] else None,
    }


def cgroup(directory):
    values = []
    for name in ["before.json", "after.json"]:
        row = load(directory / name)
        assert row["returncode"] == 0 and not row["timeout"]
        raw = json.loads(row["stdout"])
        cpu = {
            key: int(value)
            for key, value in (line.split() for line in raw["cpu.stat"].splitlines())
        }
        values.append((raw, cpu))
    before, after = values
    return {
        "cpu_seconds": (after[1]["usage_usec"] - before[1]["usage_usec"]) / 1e6,
        "throttled_seconds": (
            after[1].get("throttled_usec", 0) - before[1].get("throttled_usec", 0)
        )
        / 1e6,
        "throttled_periods": after[1].get("nr_throttled", 0) - before[1].get("nr_throttled", 0),
        "memory_peak_bytes_lifetime_not_additive": int(after[0]["memory.peak"]),
        "memory_limit": after[0]["memory.max"],
        "cpu_limit": after[0]["cpu.max"],
    }


def main():
    report, plan = load(DATA / "report.json"), load(DATA / "plan.json")
    assert report["status"] == "passed" and not report["failures"] and len(report["attempts"]) == 15
    for key, pin in plan["variants"].items():
        for name, expected in pin["files"].items():
            assert sha(Path(pin["root"]) / name) == expected
    for name, expected in plan["helper_snapshot"].items():
        assert sha(HERE / "controller-snapshot" / name) == expected
    assert sha(HERE / "quiet_worker.py") == plan["worker_sha256"]
    assert sha(HERE / "run_quiet.py") == plan["orchestrator_sha256"]
    source = ROOT / "runs/opencode-indexed-transition-candidate-20261106/compare_candidates.py"
    spec = importlib.util.spec_from_file_location("quiet_readonly_semantic_export", source)
    semantic = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = semantic
    spec.loader.exec_module(semantic)
    rows, variant_rows, resources, inputs, portable, states = [], [], [], {}, {}, {}
    verified = 0
    vectors_dir = HERE / "semantic-vectors"
    vectors_dir.mkdir(exist_ok=False)
    for attempt in report["attempts"]:
        block, variant = attempt["block"], attempt["variant"]
        namespace = DATA / f"b{block}-{variant}"
        assert attempt["status"] == "passed"
        for name, expected in attempt["artifact_hashes"].items():
            assert sha(namespace / name) == expected, str(namespace / name)
            verified += 1
        actual = {
            str(path.relative_to(namespace)) for path in namespace.rglob("*") if path.is_file()
        }
        assert actual == set(attempt["artifact_hashes"])
        inputs[namespace.name] = attempt["artifact_hashes"]
        vector = semantic.semantic_vectors(namespace)
        save(vectors_dir / (namespace.name + ".json"), vector)
        states[(block, variant)] = vector["semantic_generations"]
        construction = cgroup(namespace / "preparation")
        resources.append(
            {"block": block, "variant": variant, "phase": "preparation", **construction}
        )
        resource_report = load(namespace / "preparation/report.json")
        assert resource_report["status"] == "passed" and resource_report["cleanup_passed"]
        prep_operation = load(namespace / "preparation/preparation-operation.json")
        metrics_path = namespace / "memory/prepared/construction-metrics.json"
        prepare_metrics = load(metrics_path)
        container_seconds = 0
        for entry in attempt["cases"]:
            case = namespace / entry["container_case"]
            container_seconds += entry["container_host_inclusive_seconds"]
            resource_report = load(case / "container/report.json")
            assert (
                resource_report["status"] == entry["status"] == "passed"
                and resource_report["cleanup_passed"]
            )
            resources.append(
                {
                    "block": block,
                    "variant": variant,
                    "phase": entry["container_case"],
                    **cgroup(case / "container"),
                }
            )
            events = [
                json.loads(line) for line in (case / "backend-trace.jsonl").read_text().splitlines()
            ]
            events = [event for event in events if event["event"] == "memory_lookup"]
            assert len(events) == len(entry["worker"]["cases"])
            for event, call in zip(events, entry["worker"]["cases"], strict=True):
                assert event["error"] is None and event["backend"] == "cami"
                value = load(case / (call["label"] + "-mcp-result.json"))
                assert value["isError"] is False
                content = json.loads(value["content"][0]["text"])
                assert content.pop("audit_receipt")
                portable[(block, variant, call["label"])] = content
                trace_state = {
                    key: event[key]
                    for key in [
                        "selected_records",
                        "returned_records",
                        "withheld_records",
                        "states_checked_type",
                        "states_carried_type",
                        "note_states",
                    ]
                }
                rows.append(
                    {
                        "block": block,
                        "variant": variant,
                        "case": call["label"],
                        "dispatch_wall_seconds": call["dispatch_wall_seconds"],
                        "dispatch_cpu_self_and_completed_children_seconds": call[
                            "dispatch_cpu_self_and_completed_children_seconds"
                        ],
                        "backend_wall_seconds_nested": event["wall_seconds"],
                        "backend_cpu_seconds_nested": event[
                            "cpu_seconds_self_and_completed_children"
                        ],
                        **trace_state,
                    }
                )
        known = (
            sum(
                attempt[key]
                for key in [
                    "origin_materialization_host_seconds",
                    "preparation_host_inclusive_seconds",
                    "changed_source_update_host_seconds",
                    "final_storage_observation_and_hashing_host_seconds",
                ]
            )
            + container_seconds
        )
        assert attempt["host_variant_seconds_inclusive"] >= known - 1e-6
        variant_rows.append(
            {
                "block": block,
                "variant": variant,
                **{
                    key: attempt[key]
                    for key in [
                        "host_variant_seconds_inclusive",
                        "origin_materialization_host_seconds",
                        "preparation_host_inclusive_seconds",
                        "changed_source_update_host_seconds",
                        "final_storage_observation_and_hashing_host_seconds",
                        "final_owned_storage_bytes",
                        "final_memory_storage_bytes",
                    ]
                },
                "lookup_containers_host_seconds_inclusive": container_seconds,
                "other_host_orchestration_seconds_residual": attempt[
                    "host_variant_seconds_inclusive"
                ]
                - known,
                "seed_generation_process_seconds_nested": prep_operation["commands"][0][
                    "wall_seconds"
                ],
                "adapter_prepare_process_seconds_nested": prep_operation["commands"][1][
                    "wall_seconds"
                ],
                "adapter_function_seconds_nested": prepare_metrics["wall_seconds"],
                "catalog_capture_seconds_nested": prepare_metrics["catalog_capture"][
                    "wall_seconds"
                ],
                "registration_batch_seconds_nested": prepare_metrics["registration_batch"][
                    "wall_seconds"
                ],
                "preparation_cgroup_cpu_seconds": construction["cpu_seconds"],
            }
        )
    for block in range(1, 6):
        assert (
            states[(block, "baseline")]
            == states[(block, "candidate1")]
            == states[(block, "candidate2")]
        )
        for case in plan["cases"]:
            values = [
                portable[(block, variant, case)]
                for variant in ["baseline", "candidate1", "candidate2"]
            ]
            assert values[0] == values[1] == values[2]
            trace = [
                next(
                    row
                    for row in rows
                    if row["block"] == block and row["variant"] == variant and row["case"] == case
                )
                for variant in ["baseline", "candidate1", "candidate2"]
            ]
            keys = [
                "states_checked_type",
                "states_carried_type",
                "note_states",
                "selected_records",
                "returned_records",
                "withheld_records",
            ]
            assert all(
                [row[key] for key in keys] == [trace[0][key] for key in keys] for row in trace
            )
    assert len(rows) == 75 and len(resources) == 75
    pairs = []
    for case in plan["cases"]:
        for before, after in [
            ("baseline", "candidate1"),
            ("baseline", "candidate2"),
            ("candidate1", "candidate2"),
        ]:
            for metric in plan["metrics"]:
                left = [
                    next(
                        row[metric]
                        for row in rows
                        if row["block"] == block
                        and row["variant"] == before
                        and row["case"] == case
                    )
                    for block in range(1, 6)
                ]
                right = [
                    next(
                        row[metric]
                        for row in rows
                        if row["block"] == block and row["variant"] == after and row["case"] == case
                    )
                    for block in range(1, 6)
                ]
                pairs.append(
                    {
                        "case": case,
                        "comparison": before + "_to_" + after,
                        "metric": metric,
                        **compare(left, right),
                    }
                )
    phase_pairs = []
    phase_keys = [
        "preparation_host_inclusive_seconds",
        "preparation_cgroup_cpu_seconds",
        "host_variant_seconds_inclusive",
        "changed_source_update_host_seconds",
        "final_storage_observation_and_hashing_host_seconds",
    ]
    for before, after in [
        ("baseline", "candidate1"),
        ("baseline", "candidate2"),
        ("candidate1", "candidate2"),
    ]:
        for metric in phase_keys:
            left = [
                next(
                    row[metric]
                    for row in variant_rows
                    if row["block"] == block and row["variant"] == before
                )
                for block in range(1, 6)
            ]
            right = [
                next(
                    row[metric]
                    for row in variant_rows
                    if row["block"] == block and row["variant"] == after
                )
                for block in range(1, 6)
            ]
            phase_pairs.append(
                {"comparison": before + "_to_" + after, "metric": metric, **compare(left, right)}
            )
    summary = {
        "status": "passed_all_attempts_and_semantics",
        "quiet_started_utc": report["quiet_started_utc"],
        "quiet_ended_utc": report["quiet_ended_utc"],
        "blocks": 5,
        "variant_attempts": 15,
        "lookup_calls": 75,
        "containers": 75,
        "preparations": 15,
        "failures": [],
        "excluded_attempts": [],
        "retries": 0,
        "artifact_hashes_verified": verified,
        "portable_output_and_trace_state_equality": "all25case-block triples exact",
        "full329record_semantics_equality": "all15namespaces/all persisted generations exact under explicitly documented semantic projection; actual provenance remains separate",
        "primary_case": plan["primary_case"],
        "primary_comparisons": [row for row in pairs if row["case"] == plan["primary_case"]],
        "all_case_comparisons": pairs,
        "separate_phase_comparisons": phase_pairs,
        "variant_cost_rows": variant_rows,
        "lookup_rows": rows,
        "resources_per_container_nonadditive_peak": resources,
        "resource_summary": {
            "throttled_seconds_sum": sum(row["throttled_seconds"] for row in resources),
            "throttled_periods_sum": sum(row["throttled_periods"] for row in resources),
            "max_container_memory_peak_bytes": max(
                row["memory_peak_bytes_lifetime_not_additive"] for row in resources
            ),
        },
        "concurrency_disclosure": "Root confirmed no benchmark/taskmodel/Docker/compression during window. Brief metadata/JSON reads, draft/report writes, analysis-code editing and hosted agent inference/Codex host processes continued. Recorded uptime/nproc, proc CPU counters and Docker listings do not prove machine exclusivity. Root16:21 observation:nproc2,load0.71/0.98/0.94.",
        "sources": {
            "plan_sha256": sha(DATA / "plan.json"),
            "raw_report_sha256": sha(DATA / "report.json"),
            "state_export_implementation_sha256": sha(source),
        },
        "timing_bounds": [
            "Dispatch timer excludes Python+adapter import, constructor, result-file write and container lifecycle; first CAMI import/refresh/serialization/storage/trace append are included.",
            "Host variant inclusive timer covers materialization, paid preparation, four lookup containers (five dispatches), source update, storage observation/hashing and inner orchestration. Concurrency-after snapshots and progress/report serialization are outside it; complete outer invocation not claimed.",
            "Preparation and resource/container subtimers are nested; never add them to inclusive phases again.",
            "Warm/cold refers to Python/MCP process cache; OS/page caches not flushed. No profiler enabled.",
        ],
        "interpretation": [
            "Apply the prospective conservative range rule even if all five paired deltas have the favorable sign. No outlier removal or automatic extra samples.",
            "Microbenchmark only. No model/provider/network path or end-to-end wall gain was measured.",
            "Original v5 memory construction+tool execution31.57/1701.46s=1.86% fixed-trace conditional removal ceiling remains separate.",
        ],
        "model_calls": 0,
        "network": "none",
        "heldout_reads": False,
        "production_edits": False,
    }
    save(HERE / "summary.json", summary)
    for filename, values in [
        ("lookup-samples.csv", rows),
        ("variant-costs.csv", variant_rows),
        ("resources.csv", resources),
    ]:
        with (HERE / filename).open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(values[0]))
            writer.writeheader()
            writer.writerows(values)
    print(
        json.dumps(
            {
                "status": summary["status"],
                "verified_hashes": verified,
                "primary_comparisons": summary["primary_comparisons"],
                "resource_summary": summary["resource_summary"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
