# Indexed transition candidate2: frozen attribution and semantic checks

Candidate2 is frozen in `candidate-source/`. It differs from original v5 core only in candidate1's local unresolved-membership set plus root-authored operation-lifetime definition-indexed transitions in `validation.py` and `service.py`. Exact three hashes are in `source-freeze.json`; every other core file matches baseline. All sources mounted in the profiler were frozen copies. An eight-module controller helper snapshot was imported and its exact bytes recorded; the initial missing helper import was preserved and corrected before any container/profile execution. No production source was edited by this agent.

Three fresh CAMI namespaces repeat the same five-call sequence as baseline/candidate1: origin cold, same-process unchanged, unchanged new process, changed canonical snapshot new process, and changed unchanged new process. This gives15 actual compact dispatch calls and3 changed-snapshot profiles. Preparation is separate. Runtime image, adapter, seed/query, CPU/memory/network limits and source inputs match the original baseline. Parent broader project verification overlapped: timings are attribution-only, not quiet latency confirmation or end-to-end/model speedup.

`comparison.json` checks:

- All15 portable compact MCP contents/status labels/selection/withholding/budget match baseline and candidate1 exactly, excluding their naturally different audit receipt. Full actual provenance and raw receipts remain preserved.
- Checked/carried counts and selected/returned/withheld counts match on every call.
- Read-only SQLite exports compare all329 record payloads, revisions, state types, verdict/reasons/evidence sources, dependency scopes/certainty, invalidation scopes and carried equivalence rule at every persisted generation across all9 namespaces (baseline/c1/c2 ×3repetitions). Origin has329 checked/supported; changed snapshot has327 carried/supported and2 checked/contradicted. Empty initial context generation is retained. Fingerprints, timestamps and check/index/generation IDs remain separate actual provenance; they are not fabricated equal.
- Baseline/candidate1/candidate2 raw profiler artifacts and all frozen candidate/helper bytes verify. SQLite was opened using stdlib `mode=ro&immutable=1` and query_only, with DB byte hashes checked before/after; production recovery/connection APIs were not invoked.

The changed-snapshot transition target improves structurally: baseline/candidate1 each call scan-based `matches`331times, causing169472 Pydantic subject comparisons. Candidate2 has0 such scan calls/comparisons, one `_definition_index` construction and one `transition_many`. Candidate1's index membership improvement remains81 equality calls under `build_index` (baseline about106000). Instrumented cumulative/own times and full callers remain available in the raw profiles; they must not be summed across overlapping frames or used as a speedup claim.

These real profile semantic vectors cover `source_excerpt_equals` only. Root separately reports51 authored tests covering all4 kinds,15 views, histories, model_copy, duplicates and subclasses. This report does not turn the Click literals into an all-kind empirical claim.

`run_candidate_profiles.py` is default plan-only. Explicit run requires a NEW stage-owned output, uses only fresh canonical/state copies, and makes no model/auth/network calls. `compare_candidates.py` is read-only for baseline/c1/c2 inputs and writes new semantic-vector exports and comparison. Raw results/state/resources/cleanup are retained under `profile-v1/`; original v5 namespaces were never mounted writable.

Next step awaits both fullsuite completion and archive quiet-window confirmation: alternate baseline/candidate1/candidate2 for at least5 unprofiled fresh-state changed-snapshot blocks, charge preparation separately and preserve semantic equality/errors. No quiet measurement has started in this stage.
