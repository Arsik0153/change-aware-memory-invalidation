from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
import hashlib
from pathlib import Path
from typing import Literal

from cami.product.models import digest
from cami.product.memory.models import (
    AbsenceWitness, AvailableRecord, CarriedClaim, CheckedClaim, CheckRef, CodeView,
    DefinitionFact, DependencyStamp, Equivalence, ExistsPayload, NotePayload, NoteState,
    PythonExcerptReady, RecordRevision, RecordState, SignaturePayload, SourceExcerptPayload,
    SourceRef, SymbolKey, WithheldRecord,
)

VALIDATOR_FINGERPRINT = digest([
    "product-memory-structural/2",
    {name: hashlib.sha256((Path(__file__).parents[2] / name).read_bytes()).hexdigest()
     for name in ("ecma_models.py", "product/memory/models.py", "product/memory/adapters.py",
                  "product/memory/validation.py", "product/memory/python_excerpt.py",
                  "product/memory/_ecma_syntax.cjs")},
])


def matches(view: CodeView, subject: SymbolKey) -> tuple[DefinitionFact, ...]:
    return tuple(d for d in view.definitions if d.subject == subject)


def _definition_index(view: CodeView) -> dict[SymbolKey, tuple[DefinitionFact, ...]]:
    grouped: dict[SymbolKey, list[DefinitionFact]] = {}
    for definition in view.definitions:
        grouped.setdefault(definition.subject, []).append(definition)
    return {subject: tuple(definitions) for subject, definitions in grouped.items()}


def identity_uncertainty(view: CodeView, subject: SymbolKey) -> bool:
    return subject.language in ("js", "jsx", "ts", "tsx") and any(
        g.covers(subject.path, subject.qualname, subject.node_kind)
        for g in view.identity_gaps)


def excerpt_source_bound(definition: DefinitionFact, view: CodeView) -> bool:
    return (definition.source.index == view.index
            and definition.source.path == definition.subject.path
            and definition.source in view.sources)


def dependencies(record: RecordRevision, view: CodeView) -> DependencyStamp:
    return _dependencies(record, view, matches(view, record.payload.subject))


def _dependencies(record: RecordRevision, view: CodeView,
                  found: tuple[DefinitionFact, ...]) -> DependencyStamp:
    payload = record.payload
    subject = payload.subject
    coverage = next((c.status for c in view.coverage if c.path == subject.path), "unavailable")
    errors = tuple(error for path, error in view.path_errors if path == subject.path)
    if identity_uncertainty(view, subject):
        errors += ("binding_unresolved",)
    scopes = (f"{subject.language}:{subject.path}:{subject.qualname}:{subject.node_kind}",
              subject.path)
    if isinstance(payload, SourceExcerptPayload):
        values = []
        for definition in found:
            projection = definition.python_excerpt
            excerpt = ({"format": projection.format,
                        "prefix_sha256": projection.prefix_sha256,
                        "prefix_characters": projection.prefix_characters,
                        "truncated": projection.truncated}
                       if isinstance(projection, PythonExcerptReady)
                       else projection.model_dump(mode="json") if projection else None)
            values.append({"subject": definition.subject.model_dump(mode="json"),
                           "ambiguous": definition.ambiguous,
                           "uncertain": definition.identity_uncertain,
                           "source_bound": excerpt_source_bound(definition, view), "excerpt": excerpt})
        certain = (not errors and coverage in ("present", "absent")
                   and (not found or len(found) == 1 and not found[0].ambiguous
                        and not found[0].identity_uncertain
                        and excerpt_source_bound(found[0], view)
                        and isinstance(found[0].python_excerpt, PythonExcerptReady)))
        return DependencyStamp(fingerprint=digest([
            "source-excerpt-inputs/1", VALIDATOR_FINGERPRINT,
            view.index.policy_fingerprint, view.index.analyzer_fingerprint,
            subject.model_dump(mode="json"), payload.expected.format, values, coverage, errors]),
            scopes=scopes, certain=certain)
    if isinstance(payload, NotePayload):
        paths = {s.path for s in payload.sources}
        source_values = [(s.path, s.sha256) for s in view.sources if s.path in paths]
        return DependencyStamp(
            fingerprint=digest(["note-inputs/1", source_values,
                                [d.subject.model_dump(mode="json") for d in found], errors]),
            scopes=tuple(sorted(set(scopes) | paths)), certain=not errors and bool(found)
            and all(not d.ambiguous and not d.identity_uncertain for d in found))
    values = [{"key": d.subject.model_dump(mode="json"), "ambiguous": d.ambiguous,
               "uncertain": d.identity_uncertain,
               "signature": d.signature.model_dump(mode="json")
               if isinstance(payload, SignaturePayload) and d.signature else None} for d in found]
    certain = (not errors and coverage in ("present", "absent")
               and all(not d.ambiguous and not d.identity_uncertain for d in found))
    return DependencyStamp(fingerprint=digest([
        "structural-inputs/1", VALIDATOR_FINGERPRINT,
        view.index.policy_fingerprint, view.index.analyzer_fingerprint,
        values, coverage, errors]), scopes=scopes, certain=certain)


def transition(record: RecordRevision, view: CodeView, previous: RecordState | None,
               previous_index: CodeView | None, transition_id: str) -> RecordState:
    return _transition(record, view, previous, previous_index, transition_id,
                       matches(view, record.payload.subject))


def transition_many(records: tuple[RecordRevision, ...], view: CodeView,
                    previous: Mapping[str, RecordState], previous_index: CodeView | None,
                    transition_id: str) -> tuple[RecordState, ...]:
    """Transition in input order using an exact-subject index owned by this operation."""
    if not records:
        return ()
    definitions = _definition_index(view)
    return tuple(_transition(record, view, previous.get(record.memory_id), previous_index,
                             transition_id, definitions.get(record.payload.subject, ()))
                 for record in records)


def _transition(record: RecordRevision, view: CodeView, previous: RecordState | None,
                previous_index: CodeView | None, transition_id: str,
                found: tuple[DefinitionFact, ...]) -> RecordState:
    stamp = _dependencies(record, view, found)
    scopes = set(stamp.scopes)
    if previous:
        scopes.update(previous.dependencies.scopes)
    # Keep both edge sets available for invalidation explanations, including deleted edges.
    if previous_index:
        scopes.update("edge:" + edge for edge in previous_index.relation_scopes)
    scopes.update("edge:" + edge for edge in view.relation_scopes)
    payload = record.payload
    if isinstance(payload, NotePayload):
        current = {s.path: s for s in view.sources}
        coverage = {c.path: c.status for c in view.coverage}
        source_state: Literal["unchanged", "changed", "missing", "uncertain"] = "unchanged"
        if any(coverage.get(s.path) == "absent" for s in payload.sources):
            source_state = "missing"
        elif any(s.path not in current for s in payload.sources) or not stamp.certain:
            source_state = "uncertain"
        elif any(current[s.path].sha256 != s.sha256 for s in payload.sources):
            source_state = "changed"
        sticky = (previous is not None and previous.record.revision == record.revision
                  and isinstance(previous.state, NoteState)
                  and previous.state.review_state == "needs_review")
        state = NoteState(
            source_state=source_state,
            review_state="needs_review" if sticky or source_state != "unchanged"
            else "not_requested", origin=record.origin)
        return RecordState(record=record, state=state, dependencies=stamp,
                           invalidation_scopes=tuple(sorted(scopes)))
    if (previous is not None and previous.record.revision == record.revision
            and isinstance(previous.state, (CheckedClaim, CarriedClaim))
            and stamp.certain and previous.dependencies.certain
            and stamp.fingerprint == previous.dependencies.fingerprint):
        state_claim: CheckedClaim | CarriedClaim = CarriedClaim(
            check=previous.state.check, equivalence=Equivalence(
                from_index=previous.state.check.index, to_index=view.index,
                dependency_fingerprint=stamp.fingerprint))
    else:
        state_claim = CheckedClaim(check=_check(record, view, transition_id, found))
    return RecordState(record=record, state=state_claim, dependencies=stamp,
                       invalidation_scopes=tuple(sorted(scopes)))


def check(record: RecordRevision, view: CodeView, transition_id: str) -> CheckRef:
    return _check(record, view, transition_id, matches(view, record.payload.subject))


def _check(record: RecordRevision, view: CodeView, transition_id: str,
           found: tuple[DefinitionFact, ...]) -> CheckRef:
    payload = record.payload
    subject = payload.subject
    errors = dict(view.path_errors)
    coverage = {c.path: c.status for c in view.coverage}
    verdict: Literal["supported", "contradicted", "insufficient_evidence"] = "insufficient_evidence"
    reason = "scope_uncovered"
    evidence: tuple[SourceRef | AbsenceWitness, ...] = tuple(d.source for d in found)
    if subject.language not in ("python", "js", "jsx", "ts", "tsx"):
        reason = "unsupported_language"
    elif subject.node_kind not in (("function", "method") if subject.language == "python"
                                   else ("function", "method", "arrow", "function_expression")):
        reason = "unsupported_symbol_kind"
    elif subject.path in errors:
        reason = errors[subject.path] if errors[subject.path] in ("parse_error", "scope_uncovered", "compiler_unavailable") \
            else "source_unavailable"
    elif len(found) > 1 or any(d.ambiguous for d in found):
        reason = "ambiguous_binding"
    elif any(d.identity_uncertain for d in found) or identity_uncertainty(view, subject):
        reason = "binding_unresolved"
    elif coverage.get(subject.path) not in ("present", "absent"):
        reason = "scope_uncovered"
    elif not found:
        verdict, reason = "contradicted", "subject_absent"
        evidence = (AbsenceWitness(
            index=view.index, path=subject.path, qualname=subject.qualname,
            scope_digest=digest([view.index.snapshot_id, subject.model_dump(mode="json")]),
            reason="path_absent_in_scope" if coverage[subject.path] == "absent"
            else "symbol_absent_in_parsed_file"),)
    elif isinstance(payload, SourceExcerptPayload):
        projection = found[0].python_excerpt
        if not excerpt_source_bound(found[0], view):
            reason = "source_excerpt_unavailable"
        elif not isinstance(projection, PythonExcerptReady):
            reason = projection.reason if projection else "source_excerpt_unavailable"
        elif projection.format != payload.expected.format:
            reason = "source_excerpt_schema_mismatch"
        elif (projection.prefix_sha256 == hashlib.sha256(payload.expected.text.encode("utf-8")).hexdigest()
              and projection.prefix_characters == len(payload.expected.text)
              and projection.truncated == payload.expected.truncated):
            verdict, reason = "supported", "source_excerpt_matches"
        else:
            verdict, reason = "contradicted", "source_excerpt_mismatch"
    elif isinstance(payload, SignaturePayload):
        actual = found[0].signature
        if actual is None:
            reason = "unsupported_symbol_kind"
        elif actual.format != payload.expected.format:
            reason = "signature_schema_mismatch"
        elif actual == payload.expected:
            verdict, reason = "supported", "predicate_matches"
        else:
            verdict, reason = "contradicted", "signature_mismatch"
    elif isinstance(payload, ExistsPayload):
        verdict, reason = "supported", "predicate_matches"
    else:
        reason = "unsupported_predicate"
    return CheckRef(
        check_id=digest(["check/1", transition_id, record.memory_id, record.revision,
                         view.index.generation_id, VALIDATOR_FINGERPRINT]),
        index=view.index, record_revision=record.revision,
        validator_fingerprint=VALIDATOR_FINGERPRINT, checked_at=datetime.now(UTC).isoformat(),
        verdict=verdict, reason=reason, evidence=evidence)


def availability(item: RecordState) -> AvailableRecord | WithheldRecord:
    state = item.state
    if isinstance(state, NoteState):
        reason = "manual_review_required" if state.review_state == "needs_review" else None
        action = "review_and_update_note"
    else:
        reason = None if state.check.verdict == "supported" else state.check.reason
        action = "inspect_source_and_refresh" if state.check.verdict == "insufficient_evidence" \
            else "review_and_update_expectation"
    if reason:
        return WithheldRecord(record=item.record, state=state, reason=reason,
                              required_action=action)
    return AvailableRecord(record=item.record, state=state)
