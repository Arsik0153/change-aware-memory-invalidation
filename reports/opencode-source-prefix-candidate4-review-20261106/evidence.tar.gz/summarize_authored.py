"""Rehash every retained attempt and apply the prospective C2/C4 admission rules."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import statistics
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PRIOR = ROOT / "runs/opencode-source-segment-candidate3-review-20261106"
CASES = ["early_function_large_multiline_literal", "early_function_blank_tail"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def stats(values):
    return {
        "n": len(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "range": max(values) - min(values),
        "samples": values,
    }


def compare(before, after, memory=False):
    a, b = stats(before), stats(after)
    gap = b["median"] - a["median"]
    noise = max(a["range"], b["range"])
    pairs = [y - x for x, y in zip(before, after, strict=True)]
    result = {
        "candidate2": a,
        "candidate4": b,
        "median_increase": gap,
        "relative_median_increase": gap / a["median"],
        "paired_candidate4_minus_candidate2": pairs,
        "noise_threshold": noise,
    }
    if memory:
        result.update(
            material_memory_regression=gap > max(1048576, noise) and gap >= 0.05 * a["median"],
            material_threshold_bytes=max(1048576, noise),
        )
    else:
        result["classification"] = (
            "no_measurable_difference"
            if abs(gap) <= noise
            else "slower_candidate4_in_authored_diagnostic"
            if all(x > 0 for x in pairs)
            else "faster_candidate4_in_authored_diagnostic"
            if all(x < 0 for x in pairs)
            else "inconclusive_nonuniform_deltas"
        )
    return result


def main():
    plan = read(HERE / "prospective-authored-plan.json")
    freeze = read(HERE / "source-freeze.json")
    report = read(HERE / "authored-screen-v1/report.json")
    assert sha(HERE / "source-freeze.json") == plan["source_freeze_sha256"]
    assert sha(HERE / "run_authored_screen.py") == plan["runner_sha256"]
    assert sha(PRIOR / "authored_worker_v2.py") == plan["worker_sha256"]
    assert sha(PRIOR / "manifest.json") == freeze["prior_C3_seal_sha256"]
    for variant in ["candidate2", "candidate4"]:
        for name, expected in freeze[variant + "_files"].items():
            assert sha(ROOT / freeze[variant + "_source_path"] / name) == expected
    for name, expected in report["artifact_hashes"].items():
        assert sha(HERE / "authored-screen-v1" / name) == expected
    assert report["status"] == "passed" and len(report["attempts"]) == 20 and not report["failures"]
    expected_roster = [
        (block, case, variant)
        for block, order in enumerate(plan["orders"], 1)
        for case in CASES
        for variant in order
    ]
    assert [(r["block"], r["case"], r["variant"]) for r in report["attempts"]] == expected_roster
    expected_digests = {
        row["case"]: row["complete_module_sha256"]
        for row in read(PRIOR / "repair-check-v2/result.json")["cases"]
    }
    outcomes = {}
    for case in CASES:
        raw = (PRIOR / "authored-screen-v1/fixtures" / (case + ".py")).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == plan["cases"][case]["sha256"]
        assert len(raw) == plan["cases"][case]["bytes"]
        assert (
            sum(1 for _ in ast.walk(ast.parse(raw)))
            == plan["cases"][case]["expected_total_ast_nodes"]
        )
        selected = {}
        for variant in ["candidate2", "candidate4"]:
            rows = []
            for block in range(1, 6):
                found = [
                    row
                    for row in report["attempts"]
                    if row["block"] == block and row["case"] == case and row["variant"] == variant
                ]
                assert len(found) == 1 and found[0]["status"] == "passed"
                rows.append(found[0]["result"])
            assert all(
                row["complete_module_sha256"] == expected_digests[case]
                and row["input_sha256"] == plan["cases"][case]["sha256"]
                for row in rows
            )
            selected[variant] = rows
        metrics = {}
        for label, key, scale in [
            ("parse_return_cgroup_peak_bytes", "cgroup_peak_bytes_lifetime", 1),
            ("parse_return_process_rss_peak_bytes", "rss_peak_kib_self_lifetime", 1024),
        ]:
            metrics[label] = compare(
                *[
                    [row["at_parse_return_memory"][key] * scale for row in selected[v]]
                    for v in ["candidate2", "candidate4"]
                ],
                memory=True,
            )
        for key in ["parse_wall_seconds", "parse_cpu_seconds"]:
            metrics[key] = compare(
                *[[row[key] for row in selected[v]] for v in ["candidate2", "candidate4"]]
            )
        outcomes[case] = {
            "complete_module_sha256": expected_digests[case],
            "all_complete_module_fields_equal": True,
            "input_sha256": plan["cases"][case]["sha256"],
            "metrics": metrics,
        }
    material = any(
        row["metrics"][key]["material_memory_regression"]
        for row in outcomes.values()
        for key in ["parse_return_cgroup_peak_bytes", "parse_return_process_rss_peak_bytes"]
    )
    lifecycle = []
    for row in report["attempts"]:
        p = (
            HERE
            / "authored-screen-v1"
            / f"b{row['block']}-{row['case']}-{row['variant']}"
            / "container/report.json"
        )
        container = read(p)
        assert container["status"] == "passed" and container["cleanup_passed"]
        lifecycle.append(container["total_host_wall_seconds"])
    result = {
        "status": "authored_screen_material_regression"
        if material
        else "authored_screen_admission_pass",
        "decision": "STOP_MCP_for_review"
        if material
        else "eligible_for_separate_root_authorized_MCP_comparison",
        "attempts": 20,
        "passed": 20,
        "failures": 0,
        "models": 0,
        "complete_module_equality_all_fields": True,
        "outcomes": outcomes,
        "plan_sha256": sha(HERE / "prospective-authored-plan.json"),
        "source_freeze_sha256": sha(HERE / "source-freeze.json"),
        "raw_report_sha256": sha(HERE / "authored-screen-v1/report.json"),
        "candidate4_index_sha256": freeze["candidate4_files"]["cami/index.py"],
        "cost_scopes_nonadditive": {
            "all_container_lifecycle_host_wall_seconds_sum": sum(lifecycle),
            "parse_wall_seconds_sum": sum(
                r["result"]["parse_wall_seconds"] for r in report["attempts"]
            ),
            "parse_cpu_seconds_sum": sum(
                r["result"]["parse_cpu_seconds"] for r in report["attempts"]
            ),
            "owned_output_bytes": report["owned_output_bytes"],
            "free_disk_bytes_after": report["free_disk_bytes_after"],
        },
        "limits": [
            "Two authored near-cap inputs, not a project population estimate.",
            "Memory peaks are lifetime observations at the parse boundary; process RSS and cgroup values are nonadditive.",
            "Same2CPU/2GiB runtime; sharedhost light editing/systemservices, not CPU exclusivity.",
            "Imports/input/digest outside parse timer; whole-container costs retained separately.",
            "No universal RAM benefit, OS page release or end-to-end MCP/model benefit established.",
            "Historical C3 negative screen and original serializer failures are preserved, not pooled.",
        ],
    }
    (HERE / "authored-verdict.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "outcomes": outcomes}, indent=2))
    (HERE / "host-after.json").write_text(
        json.dumps(
            {
                "uptime": subprocess.check_output(["uptime"], text=True),
                "nproc": subprocess.check_output(["nproc"], text=True).strip(),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
