"""Two fresh experimental encodings, exact reconstruction, no production import."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DECODER = json.JSONDecoder()
TABLES = ('record', 'record_revision', 'index_view', 'memory_generation', 'record_state',
          'validation_event', 'operation_receipt', 'product_head', 'source_reference')
ORDER_SCHEMA = '''
CREATE TABLE prototype_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE generation_encoding(
 generation_id TEXT PRIMARY KEY REFERENCES memory_generation(id),states_key_ordinal INTEGER NOT NULL);
CREATE TABLE generation_state_member(
 generation_id TEXT NOT NULL,position INTEGER NOT NULL CHECK(position>=0),
 record_id TEXT NOT NULL,revision INTEGER NOT NULL,
 PRIMARY KEY(generation_id,position),UNIQUE(generation_id,record_id),
 FOREIGN KEY(generation_id,record_id) REFERENCES record_state(generation_id,record_id),
 FOREIGN KEY(record_id,revision) REFERENCES record_revision(record_id,revision));
'''
SCOPE_SCHEMA = '''
CREATE TABLE shared_edge_set(sha256 TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE record_scope_reference(
 generation_id TEXT NOT NULL,record_id TEXT NOT NULL,edge_sha256 TEXT NOT NULL,
 PRIMARY KEY(generation_id,record_id),
 FOREIGN KEY(generation_id,record_id) REFERENCES record_state(generation_id,record_id),
 FOREIGN KEY(edge_sha256) REFERENCES shared_edge_set(sha256));
'''
QUERIES = []


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def query(db, sql, parameters=()):
    QUERIES.append(sql)
    return db.execute(sql, parameters)


def fragments(raw):
    """Yield object/array field fragments, retaining original JSON string bytes."""
    require(raw[:1] in ('{', '['), 'expected encoded collection')
    pos = 1
    while pos < len(raw) and raw[pos] not in '}]':
        while raw[pos].isspace() or raw[pos] == ',':
            pos += 1
        if raw[0] == '{':
            key, pos = DECODER.raw_decode(raw, pos)
            while raw[pos].isspace():
                pos += 1
            require(raw[pos] == ':', 'expected encoded field separator')
            pos += 1
            while raw[pos].isspace():
                pos += 1
        else:
            key = None
        start = pos
        _, pos = DECODER.raw_decode(raw, pos)
        yield key, raw[start:pos]
        while pos < len(raw) and raw[pos].isspace():
            pos += 1


def encoded_object(fields):
    return '{' + ','.join(compact(key) + ':' + value for key, value in fields) + '}'


def compact_generation(raw):
    fields = list(fragments(raw))
    require(encoded_object(fields) == raw, 'unsupported generation JSON whitespace/keys')
    positions = [position for position, (key, _) in enumerate(fields) if key == 'states']
    require(len(positions) == 1, 'missing/duplicate generation states')
    position = positions[0]
    states = fields[position][1]
    return encoded_object(fields[:position] + fields[position + 1:]), position, states


def compact_scopes(db, generation_id, record_id, raw):
    fields = list(fragments(raw))
    require(encoded_object(fields) == raw, 'unsupported state JSON whitespace/keys')
    position, scopes_raw = next((i, value) for i, (key, value) in enumerate(fields)
                               if key == 'invalidation_scopes')
    tokens = [value for _, value in fragments(scopes_raw)]
    scopes = [json.loads(token) for token in tokens]
    require(all(isinstance(item, str) for item in scopes) and scopes == sorted(set(scopes)),
            'scope ordering or uniqueness unsupported')
    edges = [token for token in tokens if json.loads(token).startswith('edge:')]
    local = [token for token in tokens if not json.loads(token).startswith('edge:')]
    edges_raw = '[' + ','.join(edges) + ']'
    edge_digest = sha_bytes(edges_raw.encode('utf-8'))
    existing = query(db, 'SELECT value FROM shared_edge_set WHERE sha256=?', (edge_digest,)).fetchone()
    require(existing is None or existing[0] == edges_raw, 'shared scope digest collision')
    query(db, 'INSERT OR IGNORE INTO shared_edge_set VALUES(?,?)', (edge_digest, edges_raw))
    reference = encoded_object([
        ('encoding', compact('shared-edges/1')), ('edge_sha256', compact(edge_digest)),
        ('local_scopes', '[' + ','.join(local) + ']')])
    fields[position] = 'invalidation_scopes', reference
    return encoded_object(fields), edge_digest


def restore_state(db, generation_id, record_id, raw, mode):
    if mode == 'a':
        return raw
    fields = list(fragments(raw))
    position, reference_raw = next((i, value) for i, (key, value) in enumerate(fields)
                                  if key == 'invalidation_scopes')
    reference = json.loads(reference_raw)
    require(isinstance(reference, dict) and set(reference) == {
        'encoding', 'edge_sha256', 'local_scopes'} and reference['encoding'] == 'shared-edges/1',
        'unsupported shared-scope encoding')
    recorded = query(db, 'SELECT edge_sha256 FROM record_scope_reference '
                        'WHERE generation_id=? AND record_id=?', (generation_id, record_id)).fetchone()
    require(recorded is not None and recorded[0] == reference['edge_sha256'],
            'scope JSON/relational reference mismatch')
    shared = query(db, 'SELECT value FROM shared_edge_set WHERE sha256=?', (recorded[0],)).fetchone()
    require(shared is not None and sha_bytes(shared[0].encode('utf-8')) == recorded[0],
            'shared scope content digest mismatch')
    edges = [value for _, value in fragments(shared[0])]
    local_raw = next(value for key, value in fragments(reference_raw) if key == 'local_scopes')
    local = [value for _, value in fragments(local_raw)]
    require(all(isinstance(json.loads(token), str) and json.loads(token).startswith('edge:')
                for token in edges), 'invalid shared edge token')
    require(all(isinstance(json.loads(token), str) and not json.loads(token).startswith('edge:')
                for token in local), 'invalid local scope token')
    tokens = sorted(edges + local, key=json.loads)
    require(len({json.loads(token) for token in tokens}) == len(tokens), 'duplicate reconstructed scopes')
    fields[position] = 'invalidation_scopes', '[' + ','.join(tokens) + ']'
    return encoded_object(fields)


def restore_generation(db, generation_id, raw, mode):
    fields = list(fragments(raw))
    require(all(key != 'states' for key, _ in fields), 'nested generation states unexpectedly present')
    ordinal = query(db, 'SELECT states_key_ordinal FROM generation_encoding WHERE generation_id=?',
                    (generation_id,)).fetchone()
    require(ordinal is not None and 0 <= ordinal[0] <= len(fields), 'generation field ordinal missing')
    members = query(db, 'SELECT m.position,m.record_id,m.revision,s.revision,s.value '
                        'FROM generation_state_member m JOIN record_state s '
                        'ON s.generation_id=m.generation_id AND s.record_id=m.record_id '
                        'WHERE m.generation_id=? ORDER BY m.position', (generation_id,))
    states = []
    for expected, (position, record_id, revision, actual_revision, state_raw) in enumerate(members):
        require(position == expected and revision == actual_revision, 'generation member ordering/revision differs')
        states.append(restore_state(db, generation_id, record_id, state_raw, mode))
    expected_count = query(db, 'SELECT count(*) FROM record_state WHERE generation_id=?',
                           (generation_id,)).fetchone()[0]
    require(expected_count == len(states), 'generation member coverage differs')
    fields.insert(ordinal[0], ('states', '[' + ','.join(states) + ']'))
    return encoded_object(fields)


def build(original, path, mode):
    require(not path.exists(), 'derived database must be new')
    with sqlite3.connect(path) as db:
        db.execute('PRAGMA page_size=4096')
        db.execute('PRAGMA foreign_keys=ON')
        for table in TABLES:
            sql, = query(original, 'SELECT sql FROM sqlite_schema WHERE type=\'table\' AND name=?',
                         (table,)).fetchone()
            db.execute(sql)
        db.executescript(ORDER_SCHEMA)
        if mode == 'b':
            db.executescript(SCOPE_SCHEMA)
        db.execute('PRAGMA user_version=' + ('1001' if mode == 'a' else '1002'))
        db.execute('INSERT INTO prototype_metadata VALUES(?,?)',
                   ('format', 'offline-memory-representation/' + mode + '/1'))
        generation_info, scope_refs = [], []
        for table in TABLES:
            columns = query(original, f'PRAGMA table_info("{table}")').fetchall()
            value_column = next((i for i, col in enumerate(columns) if col[1] == 'value'), None)
            for original_row in query(original, f'SELECT * FROM "{table}" ORDER BY rowid'):
                row = list(original_row)
                if table == 'memory_generation':
                    encoded, ordinal, states = compact_generation(row[value_column])
                    row[value_column] = encoded
                    generation_info.append((row[0], ordinal, states))
                elif table == 'record_state' and mode == 'b':
                    row[value_column], edge_digest = compact_scopes(db, row[0], row[1], row[value_column])
                    scope_refs.append((row[0], row[1], edge_digest))
                placeholders = ','.join('?' for _ in row)
                query(db, f'INSERT INTO "{table}" VALUES({placeholders})', row)
        for generation_id, ordinal, states in generation_info:
            db.execute('INSERT INTO generation_encoding VALUES(?,?)', (generation_id, ordinal))
            for position, (_, raw_state) in enumerate(fragments(states)):
                state = json.loads(raw_state)
                record_id, revision = state['record']['memory_id'], state['record']['revision']
                stored, = query(db, 'SELECT value FROM record_state WHERE generation_id=? AND record_id=?',
                                (generation_id, record_id)).fetchone()
                # References are inserted below; defer B reconstruction until all FK rows exist.
                if mode == 'a':
                    require(stored == raw_state, 'original nested state does not match original state row')
                db.execute('INSERT INTO generation_state_member VALUES(?,?,?,?)',
                           (generation_id, position, record_id, revision))
        if mode == 'b':
            db.executemany('INSERT INTO record_scope_reference VALUES(?,?,?)', scope_refs)
        db.commit()


def verify(original, path, mode):
    require(not path.with_name(path.name + '-wal').exists(), 'derived WAL unexpectedly present')
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        require(query(db, 'PRAGMA integrity_check').fetchall() == [('ok',)], 'integrity check failed')
        require(query(db, 'PRAGMA foreign_key_check').fetchall() == [], 'foreign key check failed')
        counts = {}
        raw_bytes = Counter()
        for table in TABLES:
            columns = query(original, f'PRAGMA table_info("{table}")').fetchall()
            value_column = next((i for i, col in enumerate(columns) if col[1] == 'value'), None)
            old_rows = query(original, f'SELECT * FROM "{table}" ORDER BY rowid')
            new_rows = query(db, f'SELECT * FROM "{table}" ORDER BY rowid')
            count = 0
            for old_row, new_row in zip(old_rows, new_rows, strict=True):
                reconstructed = list(new_row)
                if table == 'memory_generation':
                    reconstructed[value_column] = restore_generation(db, new_row[0], new_row[value_column], mode)
                elif table == 'record_state':
                    reconstructed[value_column] = restore_state(db, new_row[0], new_row[1], new_row[value_column], mode)
                require(tuple(reconstructed) == old_row, 'reconstructed original row bytes differ: ' + table)
                if table in ('memory_generation', 'record_state'):
                    require(json.loads(reconstructed[value_column]) == json.loads(old_row[value_column]),
                            'decoded original JSON value differs: ' + table)
                    raw_bytes[table] += len(old_row[value_column].encode('utf-8'))
                count += 1
            counts[table] = count
        original_history = query(original, 'SELECT s.record_id,g.id,g.sequence FROM memory_generation g '
                                'JOIN record_state s ON s.generation_id=g.id ORDER BY s.record_id,g.sequence')
        derived_history = query(db, 'SELECT s.record_id,g.id,g.sequence FROM memory_generation g '
                               'JOIN record_state s ON s.generation_id=g.id ORDER BY s.record_id,g.sequence')
        require(all(old == new for old, new in zip(original_history, derived_history, strict=True)),
                'history membership/order changed')
        pages = {key: query(db, 'PRAGMA ' + key).fetchone()[0]
                 for key in ('page_count', 'page_size', 'freelist_count', 'user_version')}
        objects = query(db, 'SELECT name,count(*),sum(pgsize),sum(payload),sum(unused) '
                           'FROM dbstat GROUP BY name ORDER BY sum(pgsize) DESC').fetchall()
        require(sum(row[2] for row in objects) + pages['freelist_count'] * pages['page_size']
                == path.stat().st_size == pages['page_count'] * pages['page_size'], 'page accounting differs')
        return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                'logical_bytes': path.stat().st_size, 'allocated_bytes': path.stat().st_blocks * 512,
                'pages': pages, 'original_table_row_counts': counts,
                'reconstructed_original_value_bytes': dict(raw_bytes),
                'all_original_rows_exact': True, 'all_decoded_state_generation_values_equal': True,
                'explicit_state_order_and_history_membership_equal': True,
                'integrity_check': 'ok', 'foreign_key_check': [],
                'dbstat': [dict(zip(('name', 'pages', 'bytes', 'payload_bytes', 'unused_bytes'), row))
                           for row in objects]}


def corruption_checks(path):
    checks = []
    with sqlite3.connect(path) as db:
        db.execute('PRAGMA foreign_keys=ON')
        generation_id, record_id, raw = db.execute('SELECT generation_id,record_id,value FROM record_state LIMIT 1').fetchone()
        digest, = db.execute('SELECT edge_sha256 FROM record_scope_reference WHERE generation_id=? AND record_id=?',
                            (generation_id, record_id)).fetchone()
        generation_raw, = db.execute('SELECT value FROM memory_generation WHERE id=?', (generation_id,)).fetchone()
        cases = [
            ('corrupted shared scope bytes', 'UPDATE shared_edge_set SET value=\'[]\' WHERE sha256=?',
             (digest,), lambda: restore_state(db, generation_id, record_id, raw, 'b')),
            ('missing generation member', 'DELETE FROM generation_state_member WHERE generation_id=? AND position=0',
             (generation_id,), lambda: restore_generation(db, generation_id, generation_raw, 'b')),
            ('noncontiguous explicit member order', 'UPDATE generation_state_member SET position=100000 '
             'WHERE generation_id=? AND position=0', (generation_id,),
             lambda: restore_generation(db, generation_id, generation_raw, 'b')),
        ]
        for label, sql, parameters, read in cases:
            db.execute('BEGIN')
            try:
                db.execute(sql, parameters)
                try:
                    read()
                except ValueError as error:
                    checks.append({'mutation': label, 'status': 'expected_rejection', 'reason': str(error)})
                else:
                    raise ValueError('corruption was silently accepted: ' + label)
            finally:
                db.rollback()
        db.execute('BEGIN')
        try:
            try:
                db.execute('DELETE FROM shared_edge_set WHERE sha256=?', (digest,))
            except sqlite3.IntegrityError as error:
                checks.append({'mutation': 'delete referenced immutable edge set',
                               'status': 'expected_rejection', 'reason': str(error)})
            else:
                raise ValueError('missing scope FK was silently accepted')
        finally:
            db.rollback()
    return checks


def main():
    diagnosis_path = ROOT / 'runs/opencode-memory-storage-diagnosis-20261106/storage-report.json'
    diagnosis = json.loads(diagnosis_path.read_bytes())
    selected = diagnosis['namespaces'][1]
    original_path = ROOT / selected['database']
    require(sorted(original_path.parent.glob('memory.sqlite3*')) == [original_path],
            'original live WAL/journal family refused')
    original_hash = sha(original_path)
    original_expected = next(value['sha256'] for path, value in selected['memory_inventory'].items()
                             if path.endswith('/memory.sqlite3'))
    require(original_hash == original_expected, 'original database diagnosis pin mismatch')
    source_paths = ('src/cami/product/memory/store.py', 'src/cami/product/memory/models.py',
                    'src/cami/product/memory/validation.py', 'src/cami/product/service.py')
    source_pins = {path: sha(ROOT / path) for path in source_paths}
    original_size = original_path.stat().st_size
    with sqlite3.connect(original_path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True) as original:
        original.execute('PRAGMA query_only=ON')
        original.execute('PRAGMA cache_size=-2048')
        require(query(original, 'PRAGMA integrity_check').fetchall() == [('ok',)], 'original integrity check failed')
        require(query(original, 'PRAGMA foreign_key_check').fetchall() == [], 'original foreign key check failed')
        results = []
        for mode in ('a', 'b'):
            path = OUT / ('representation-' + mode + '.sqlite3')
            build(original, path, mode)
            results.append(verify(original, path, mode))
        negative = corruption_checks(OUT / 'representation-b.sqlite3')
        final_b = verify(original, OUT / 'representation-b.sqlite3', 'b')
        require(final_b == results[1], 'derived B changed after rolled-back corruption checks')
    require(sha(original_path) == original_hash, 'original database changed')
    require(sorted(original_path.parent.glob('memory.sqlite3*')) == [original_path], 'original family changed')
    require(all(sha(ROOT / path) == expected for path, expected in source_pins.items()), 'source files changed')
    require(sum(result['logical_bytes'] for result in results) <= 50_000_000, 'derived DB size budget exceeded')
    for result in results:
        result['observed_logical_byte_reduction_from_original'] = original_size - result['logical_bytes']
        result['fresh_file_comparison_only'] = True
    report = {'status': 'passed', 'scope': 'Offline experimental representation only, not a production migration or model run.',
              'baseline_head_observed_before_run': 'fe0766761532d4544d3f39a95f4a4a622bf9707a',
              'original_database': str(original_path.relative_to(ROOT)), 'original_sha256_before': original_hash,
              'original_sha256_after': sha(original_path), 'original_logical_bytes': original_size,
              'original_read_only_immutable': True, 'original_family_no_wal_or_journal': True,
              'diagnosis_sha256': sha(diagnosis_path), 'source_sha256': source_pins,
              'sqlite_version': sqlite3.sqlite_version, 'representations': results,
              'corruption_checks': negative,
              'preserved_evidence': 'All original rows; every state and generation reconstructs exact JSON bytes and decoded values; source files remain external unchanged provenance, not copied.',
              'limitations': ['Freshly built files include repacking; no same-layout baseline rewrite was added because the bound is two derived databases.',
                             'No production model/parser executed. Byte equality proves decoded model inputs are unchanged, not that a production migration exists.',
                             'No latency, RSS or performance claim; full suite may overlap.',
                             'Explicit schema1001/1002 and extra tables make existing production readers reject these files.',
                             'The shared whole-scope arrays are unique after A; B therefore shares the repeated edge subset, retaining local scopes separately.'],
              'project_code_executed': False, 'original_writes': False, 'derived_database_count': 2,
              'network_calls': 0, 'model_calls': 0, 'Docker': 0, 'heldout_reads': 0}
    save('prototype-report.json', report)
    save('queries.json', list(dict.fromkeys(QUERIES)))
    print(json.dumps({'status': report['status'], 'original_bytes': original_size,
                      'representations': [{key: value for key, value in result.items()
                                           if key not in ('dbstat',)} for result in results],
                      'corruption_checks': negative}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('failure-attempt1.json', {'error': type(error).__name__ + ': ' + str(error)})
        raise
