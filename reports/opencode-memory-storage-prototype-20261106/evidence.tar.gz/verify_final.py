"""Final immutable proof on retained files, no build or project execution."""
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(raw)
    return digest.hexdigest()


report = json.loads((OUT / 'prototype-report.json').read_bytes())
diagnosis = json.loads((ROOT / 'runs/opencode-memory-storage-diagnosis-20261106/storage-report.json').read_bytes())
selected = diagnosis['namespaces'][1]
memory = ROOT / selected['namespace'] / 'memory'
assert sorted(str(path.relative_to(memory)) for path in memory.rglob('*') if path.is_file()) == sorted(selected['memory_inventory'])
for name, metadata in selected['memory_inventory'].items():
    path = memory / name
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size == metadata['logical_bytes'] and sha(path) == metadata['sha256']
extras = []
for result in report['representations']:
    path = ROOT / result['path']
    assert sha(path) == result['sha256']
    assert sorted(path.parent.glob(path.name + '*')) == [path]
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True) as db:
        scopes = {'shared_edge_sets': 0, 'scope_references': 0}
        if path.name == 'representation-b.sqlite3':
            scopes = {'shared_edge_sets': db.execute('SELECT count(*) FROM shared_edge_set').fetchone()[0],
                      'scope_references': db.execute('SELECT count(*) FROM record_scope_reference').fetchone()[0],
                      'unique_shared_edge_list_bytes': db.execute('SELECT sum(length(CAST(value AS BLOB))) FROM shared_edge_set').fetchone()[0]}
            assert scopes == {'shared_edge_sets': 2, 'scope_references': 658,
                              'unique_shared_edge_list_bytes': 22250}
        assert db.execute('SELECT count(*) FROM generation_state_member').fetchone()[0] == 658
        assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        extras.append({'path': result['path'], **scopes})
consumer_paths = ['tests/watch/cli_driver.py', 'tests/memory/test_memory.py',
                  'tests/memory/test_source_excerpt_behavior.py']
final = {'status': 'passed', 'original_memory_inventory_files_reverified': len(selected['memory_inventory']),
         'all_external_index_and_source_evidence_unchanged': True,
         'all_derived_file_hashes_match_initial_verification': True,
         'derived_storage_details': extras,
         'compatibility_consumer_sha256': {path: sha(ROOT / path) for path in consumer_paths},
         'scope': 'Read-only immutable final checks; no production imports or migration.'}
(OUT / 'final-verification.json').write_text(json.dumps(final, sort_keys=True, indent=2) + '\n')
print(json.dumps(final, indent=2))
