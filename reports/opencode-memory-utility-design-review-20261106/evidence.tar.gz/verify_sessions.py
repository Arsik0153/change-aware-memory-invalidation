"""Reproduce public terminal-bound session identity and private-state removal metadata."""

import json

from review_evidence import DESIGN, RUN, STAGE, read, sha


def main():
    freeze = json.loads(read(DESIGN / "source-freeze.json"))
    rows = []
    for path in sorted((RUN / "trials").glob("*/terminal.json")):
        terminal = json.loads(read(path))
        outer_raw = read(path.parent / "session/manifest.json")
        inner_raw = read(path.parent / "session/evidence/manifest.json")
        assert terminal["artifact_hashes"]["session/manifest.json"] == sha(outer_raw)
        assert terminal["artifact_hashes"]["session/evidence/manifest.json"] == sha(inner_raw)
        outer, inner = json.loads(outer_raw), json.loads(inner_raw)
        assert outer["state_removed"] is True
        rows.append(
            {
                "trial_id": path.parent.name,
                "session_id": inner["session_id"],
                "state_removed": True,
                "outer_manifest_sha256": sha(outer_raw),
                "inner_manifest_sha256": sha(inner_raw),
            }
        )
    assert len(rows) == 36 and len({row["session_id"] for row in rows}) == 36
    sources = {
        name: {"sha256": freeze["files"][name], "lines": lines}
        for name, lines in {
            "scripts/opencode_benchmark/harness/container_session.py": [211],
            "scripts/opencode_benchmark/harness/container_worker.py": [240, 248],
        }.items()
    }
    output = STAGE / "session-bindings.json"
    if output.exists():
        raise ValueError("no overwrite")
    output.write_text(
        json.dumps(
            {
                "status": "passed",
                "distinct_sessions": 36,
                "private_state_removed": 36,
                "source_bindings": sources,
                "rows": rows,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "status": "passed",
                "distinct_sessions": 36,
                "session_bindings_sha256": sha(output.read_bytes()),
            }
        )
    )


if __name__ == "__main__":
    main()
