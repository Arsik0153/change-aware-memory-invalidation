"""Read only frozen public v6 contracts, code, terminal bindings and memory metadata."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
DESIGN = ROOT / "reports/opencode-study-design-v6-20261106"
AUDIT = ROOT / "runs/opencode-v6-independent-audit-20261106"
RUN = ROOT / "runs/opencode-development-v6-20261106"
PINS = {
    "reports/opencode-study-design-v6-20261106/protocol.json": "fdc5bcc642c1dc435d866b144c2654e89d91936a782485373b8b425951ff01f2",
    "reports/opencode-study-design-v6-20261106/study.json": "b66e4d557b7b7cdf0800b4c9121e793659f3a02029a74b026c7f7c4d75243cdd",
    "reports/opencode-study-design-v6-20261106/source-freeze.json": "3c39a8c0454aa8503f5206d7a44d40e4e4f10ff508f47da3b64db0f9c9abb330",
    "runs/opencode-v6-independent-audit-20261106/memory-packet-roster.json": "c7bcc97e81f8ff1a02a6f8fbab0206242f3a7110f543e1381403d3fedc61d7f5",
    "runs/opencode-v6-independent-audit-20261106/summary.json": "01de6a4011674e9678ed9790cd93be2cec0b8b40cb2d13a56488a827aead351b",
    "runs/opencode-development-v6-final-analysis-20261106/report.json": "632953c9879fb1f4f05c059d2dde747e0d4d8ead7724a13c1d7d7805faa1100b",
}
SPANS = {
    "integrations/opencode/memory_adapter.py": [(18, 34), (108, 122)],
    "integrations/opencode/memory_backend.py": [(267, 306), (642, 673), (675, 734)],
    "scripts/opencode_benchmark/controller/study_controller.py": [(85, 114), (152, 165)],
    "scripts/opencode_benchmark/controller/study_runtime.py": [(131, 160), (188, 224), (237, 244)],
    "scripts/opencode_benchmark/controller/study_workspace.py": [(70, 80)],
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    if path.is_symlink():
        raise ValueError("symlink refused")
    raw = path.read_bytes()
    if expected is not None and sha(raw) != expected:
        raise ValueError("input hash mismatch: " + str(path))
    return raw


def pointer(value, tokens):
    for token in tokens:
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def main():
    values = {name: json.loads(read(ROOT / name, pin)) for name, pin in PINS.items()}
    freeze = values["reports/opencode-study-design-v6-20261106/source-freeze.json"]
    sources = {}
    archive = DESIGN / "implementation-source.tar.gz"
    archive_sha = sha(read(archive))
    with tarfile.open(archive) as tar:
        for name, spans in SPANS.items():
            raw = tar.extractfile(name).read()
            assert sha(raw) == freeze["files"][name]
            lines = raw.decode().splitlines()
            sources[name] = {
                "sha256": sha(raw),
                "archive": str(archive.relative_to(ROOT)),
                "spans": [
                    {"first_line": a, "last_line": b, "text": "\n".join(lines[a - 1 : b])}
                    for a, b in spans
                ],
            }
    catalogs = []
    for path in sorted(RUN.glob("namespaces/*/memory/prepared/catalog.json")):
        raw = read(path)
        value = json.loads(raw)
        catalogs.append(
            {
                "path": str(path.relative_to(ROOT)),
                "sha256": sha(raw),
                "records": len(value["records"]),
                "kinds": dict(Counter(row["payload"]["type"] for row in value["records"])),
                "truncated_prefixes": sum(
                    row["payload"]["expected"]["truncated"] for row in value["records"]
                ),
            }
        )
    assert len(catalogs) == 6 and len({x["sha256"] for x in catalogs}) == 1
    catalog_sha = catalogs[0]["sha256"]
    terminals = []
    for path in sorted((RUN / "trials").glob("*/terminal.json")):
        raw = read(path)
        value = json.loads(raw)
        arm = path.parent.name.split("-")[1]
        if arm != "plain":
            assert value["immutable_memory"]["prepared/catalog.json"] == catalog_sha
        terminals.append(
            {
                "id": path.parent.name,
                "sha256": sha(raw),
                "arm": arm,
                "status": value["status"],
                "catalog_binding": None
                if arm == "plain"
                else value["immutable_memory"]["prepared/catalog.json"],
            }
        )
    assert len(terminals) == 36
    roster = values["runs/opencode-v6-independent-audit-20261106/memory-packet-roster.json"]
    lookup = defaultdict(
        lambda: {
            "calls": 0,
            "wall_seconds": 0.0,
            "cpu_seconds": 0.0,
            "requested_limits": [],
            "explicit_limit_calls": 0,
        }
    )
    trace_inputs = {}
    for row in roster["roster"]:
        trace = read(ROOT / row["backend_trace_path"], row["backend_trace_sha256"])
        messages = read(ROOT / row["messages_path"], row["messages_sha256"])
        trace_inputs[row["backend_trace_path"]] = row["backend_trace_sha256"]
        trace_inputs[row["messages_path"]] = row["messages_sha256"]
        event = json.loads(trace.splitlines()[row["backend_lookup_jsonl_line_one_based"] - 1])
        state = pointer(json.loads(messages), row["model_text_json_pointer"].split("/")[1:5])
        data = lookup[row["arm"]]
        data["calls"] += 1
        data["wall_seconds"] += event["wall_seconds"]
        data["cpu_seconds"] += event["cpu_seconds_self_and_completed_children"]
        data["requested_limits"].append(event["requested_limit"])
        data["explicit_limit_calls"] += int("limit" in state["input"])
    assert sum(x["calls"] for x in lookup.values()) == 24
    summary = values["runs/opencode-v6-independent-audit-20261106/summary.json"]
    result = {
        "status": "completed_readonly_design_review",
        "source_pins": PINS,
        "archive_sha256": archive_sha,
        "frozen_source_evidence": sources,
        "catalog_metadata": catalogs,
        "terminal_catalog_bindings": terminals,
        "actual_lookup_metadata": dict(lookup),
        "terminal_pinned_trace_inputs": trace_inputs,
        "descriptive_costs": summary["cost_resource_summaries_descriptive"],
        "visible_cost_totals": summary["visible_cost_totals"],
        "narrow_nonclaims": [
            "Only public catalog metadata and generic runtime code inspected; literal payload text not analyzed. No task prompt, gold, heldout, auth or private-state body read.",
            "No memory-write MCP API; not a claim that OS-level mutation is impossible. Backend refresh persists maintenance state, not model-authored experience.",
            "No causal attribution of provider tokens or necessary reads from byte overlap.",
            "Whole v6 wall is primary-ineligible due preserved cleanup overlap; all times descriptive.",
        ],
    }
    for name, pin in PINS.items():
        read(ROOT / name, pin)
    out = STAGE / "evidence.json"
    if out.exists():
        raise ValueError("no overwrite")
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(
        json.dumps(
            {
                "status": result["status"],
                "catalogs": len(catalogs),
                "terminals": len(terminals),
                "calls": 24,
                "evidence_sha256": sha(out.read_bytes()),
            }
        )
    )


if __name__ == "__main__":
    main()
