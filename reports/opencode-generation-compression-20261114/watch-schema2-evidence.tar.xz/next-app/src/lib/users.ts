export function createUser(name: number): string { return String(name); }
