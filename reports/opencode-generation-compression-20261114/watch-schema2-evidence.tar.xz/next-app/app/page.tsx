import {createUser} from "@/lib/users"; export function Page() { return <div>{createUser("Ada")}</div>; }
