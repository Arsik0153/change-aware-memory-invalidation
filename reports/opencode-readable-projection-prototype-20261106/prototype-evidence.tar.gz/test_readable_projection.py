"""Authored serialization cases only; no source execution or model calls."""

import copy

import pytest

from readable_projection import (
    CANDIDATES,
    INLINE,
    canonical,
    decode_inline,
    decode_pool,
    encode_inline,
    encode_pool,
)


def fixture(text, truncated=False):
    return {
        "response_format": "research-memory-compact/1",
        "schema_version": 1,
        "backend": "cami",
        "audit_receipt": "old-receipt-does-not-bind-wrapper",
        "query": "stable",
        "freshness": "origin-bound",
        "selection_budget": {"origin_record_bytes": 16384, "ranking_before_availability": True},
        "entries": [
            {
                "id": "record-a",
                "label": "validated_literal_source",
                "availability": "supported",
                "payload": {
                    "type": "source_excerpt_equals",
                    "subject": {"path": "a.py", "qualname": "f", "node_kind": "function"},
                    "origin_source": {"path": "a.py", "sha256": "x", "size": 91},
                    "origin_span": {"first_line": 1, "last_line": 3},
                    "expected": {
                        "format": "python.definition-prefix/1",
                        "text": text,
                        "truncated": truncated,
                    },
                },
            }
        ],
        "withheld": [
            {
                "id": "record-b",
                "reason": "contradicted",
                "required_action": "Do not use",
                "subject": {"path": "b.py"},
            }
        ],
        "metadata_marker_string": '~2:\n@123\nS:4 " \\',
    }


@pytest.mark.parametrize("name", CANDIDATES)
@pytest.mark.parametrize(
    "text",
    [
        "",
        'def f():\n    return "a\\b"\n',
        "def f():\r\n    return 7\r\n",
        "\tUnicode é 😀\n\r",
        "~0:\n\n~\n@123\nM:9\nS:2\n```\n",
    ],
)
@pytest.mark.parametrize("truncated", [False, True])
def test_exact_all_fields_and_physical_bytes(name, text, truncated):
    value = fixture(text, truncated)
    before = copy.deepcopy(value)
    encode, decode = CANDIDATES[name]
    wire = encode(value)
    assert decode(wire) == value == before
    assert canonical(decode(wire)) == canonical(value)
    assert text.encode("utf-8") in wire


def test_pool_deduplicates_only_identical_source_bytes_within_one_response():
    value = fixture("def f():\n    return 1\n")
    other = copy.deepcopy(value["entries"][0])
    other["id"] = "record-c"
    other["payload"]["expected"]["truncated"] = True
    value["entries"].append(other)
    wire = encode_pool(value)
    assert wire.count(b"def f():\n    return 1\n") == 1
    assert decode_pool(wire) == value
    assert encode_inline(value).count(b"def f():\n    return 1\n") == 2


@pytest.mark.parametrize("name", CANDIDATES)
def test_no_literal_fields_still_preserves_withheld_and_budget(name):
    value = fixture("source")
    value["entries"] = []
    encode, decode = CANDIDATES[name]
    assert decode(encode(value)) == value


@pytest.mark.parametrize("name", CANDIDATES)
@pytest.mark.parametrize("text", ["NUL\x00", "escape\x1b[31m", "delete\x7f"])
def test_controls_are_explicitly_unsupported_not_lossily_rewritten(name, text):
    with pytest.raises(ValueError):
        CANDIDATES[name][0](fixture(text))


def test_bad_boundary_utf8_and_wrong_location_fail_closed():
    wire = encode_inline(fixture("é"))
    with pytest.raises((ValueError, UnicodeError)):
        decode_inline(wire.replace(b"~2:", b"~1:"))
    with pytest.raises(ValueError):
        decode_inline(wire + b"extra")
    with pytest.raises(ValueError):
        decode_inline(
            INLINE
            + b'{"response_format":"research-memory-compact/1","backend":"cami","query":~1:\nx\n~}'
        )
    pool = encode_pool(fixture("abc"))
    with pytest.raises(ValueError):
        decode_pool(pool.replace(b"@0", b"@9", 1))
    with pytest.raises(ValueError):
        decode_pool(pool + b"extra")
