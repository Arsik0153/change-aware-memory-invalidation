"""Ordinary fenced text and explicit semantic retention, authored fixtures only."""

import copy
import json

import pytest

from fenced_projection import encode, verify
from test_readable_projection import fixture


def value(text, arm="cami", truncated=False):
    original = fixture(text, truncated)
    original.pop("metadata_marker_string")
    original.update(backend=arm, matched_records=2, selected_records=2, truncated=False)
    original["entries"][0]["payload"]["origin_source"]["path"] = "a.py"
    if arm == "cami":
        original["entries"][0]["state_type"] = "carried"
    return original


@pytest.mark.parametrize("arm", ["static", "cami"])
@pytest.mark.parametrize(
    "text",
    [
        "def f():\n    return 7\n",
        "last line without newline",
        "CRLF\r\nUnicode é 😀\r\n",
        "bare CR\r",
        "```\n````python\n# header\n",
    ],
)
@pytest.mark.parametrize("truncated", [False, True])
def test_exact_essential_fields_and_raw_physical_source(arm, text, truncated):
    old = value(text, arm, truncated)
    before = copy.deepcopy(old)
    event = {"requested_limit": 5}
    display = encode(old, event)
    result = verify(display, old, event)
    assert (
        result["source_tuples"][0]["text"] == text
        and result["source_tuples"][0]["truncated"] == truncated
    )
    assert old == before
    assert text.encode() in display


def test_audit_only_fields_are_not_mislabelled_as_current_or_visible_proof():
    old = value("source")
    display = encode(old, {"requested_limit": 5})
    assert b"original_audit_receipt" in display and b"origin_source" not in display
    assert b'"query"' not in display
    assert verify(display, old, {"requested_limit": 5})["whole_original_recovery"].startswith(
        "Original full/compact"
    )


@pytest.mark.parametrize(
    "mutation", ["source", "id", "label", "withheld", "budget", "suffix", "request_limit"]
)
def test_independent_verifier_rejects_changed_claims(mutation):
    old = value("SOURCE-SENTINEL")
    event = {"requested_limit": 5}
    display = encode(old, event)
    changes = {
        "source": (b"SOURCE-SENTINEL", b"OTHER-SOURCE"),
        "id": (b"record-a", b"wrong-id"),
        "label": (b"validated_literal_source", b"unknown_trust"),
        "withheld": (b"contradicted", b"supported"),
        "budget": (b"16384", b"99999"),
        "request_limit": (b'"requested_limit":5', b'"requested_limit":6'),
    }
    if mutation == "suffix":
        display += b"UNVERIFIED CLAIM"
    else:
        display = display.replace(*changes[mutation], 1)
    with pytest.raises(ValueError):
        verify(display, old, event)


def test_unknown_semantics_or_nonredundant_origin_path_refused():
    old = value("source")
    old["new_semantic_claim"] = "must not silently omit"
    with pytest.raises(ValueError):
        encode(old, {"requested_limit": 5})
    old = value("source")
    old["entries"][0]["payload"]["origin_source"]["path"] = "different.py"
    with pytest.raises(ValueError):
        encode(old, {"requested_limit": 5})


def test_unknown_full_provenance_stays_in_original_sidecar():
    old = value("source")
    origin = copy.deepcopy(old["entries"][0]["payload"]["origin_source"])
    verify(encode(old, {"requested_limit": 5}), old, {"requested_limit": 5})
    assert old["entries"][0]["payload"]["origin_source"] == origin
    json.dumps(old)


@pytest.mark.parametrize("unsupported", ["empty", "mixed", "error"])
def test_unsupported_responses_fail_explicitly(unsupported):
    old = value("source")
    if unsupported == "empty":
        old["entries"] = []
    elif unsupported == "mixed":
        other = copy.deepcopy(old["entries"][0])
        other["payload"]["type"] = "note"
        old["entries"].append(other)
    else:
        old = {"error": "backend unavailable"}
    with pytest.raises(ValueError):
        encode(old, {"requested_limit": 5})
