"""Two lossless display wrappers, not MCP formats or new semantic projections."""

from __future__ import annotations

import json
import re

INLINE = b"RM-READABLE-WRAP/inline-0\n"
POOL = b"RM-READABLE-WRAP/pool-0\n"
MAX_BYTES = 1024 * 1024


def canonical(value):
    return json.dumps(
        value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False
    ).encode()


def literal_paths(value):
    paths = {}
    for collection in ["entries", "withheld"]:
        for i, record in enumerate(value.get(collection, [])):
            payload = record.get("payload")
            if isinstance(payload, dict) and payload.get("type") == "source_excerpt_equals":
                expected = payload.get("expected")
                if (
                    not isinstance(expected, dict)
                    or not isinstance(expected.get("text"), str)
                    or type(expected.get("truncated")) is not bool
                ):
                    raise ValueError("unsupported literal tuple")
                paths[(collection, i, "payload", "expected", "text")] = expected["text"]
    return paths


def source_bytes(text):
    if any(ord(char) < 32 and char not in "\t\r\n" or ord(char) == 127 for char in text):
        raise ValueError(
            "raw display refuses terminal control characters; no lossy escaping/fallback"
        )
    return text.encode("utf-8")


def validate(value):
    if not isinstance(value, dict) or value.get("response_format") != "research-memory-compact/1":
        raise ValueError("only an authenticated original compact/1 value may be wrapped")
    if value.get("backend") not in ["static", "cami"]:
        raise ValueError("unsupported backend")
    canonical(value)
    return literal_paths(value)


def encode_tree(value, paths, transform, path=()):
    if path in paths:
        return transform(source_bytes(paths[path]))
    if isinstance(value, dict):
        return (
            b"{"
            + b",".join(
                canonical(k) + b":" + encode_tree(value[k], paths, transform, (*path, k))
                for k in sorted(value)
            )
            + b"}"
        )
    if isinstance(value, list):
        return (
            b"["
            + b",".join(
                encode_tree(item, paths, transform, (*path, i)) for i, item in enumerate(value)
            )
            + b"]"
        )
    return canonical(value)


def encode_inline(value):
    paths = validate(value)
    body = encode_tree(
        value, paths, lambda raw: b"~" + str(len(raw)).encode() + b":\n" + raw + b"\n~"
    )
    result = INLINE + body
    if len(result) > MAX_BYTES:
        raise ValueError("display exceeds bound")
    return result


def encode_pool(value):
    paths = validate(value)
    sources, ids = [], {}

    def reference(raw):
        if raw not in ids:
            ids[raw] = len(sources)
            sources.append(raw)
        return b"@" + str(ids[raw]).encode()

    metadata = encode_tree(value, paths, reference)
    body = (
        POOL
        + b"M:"
        + str(len(metadata)).encode()
        + b"\n"
        + metadata
        + b"\nS:"
        + str(len(sources)).encode()
        + b"\n"
    )
    for i, raw in enumerate(sources):
        body += str(i).encode() + b":" + str(len(raw)).encode() + b"\n" + raw + b"\n"
    if len(body) > MAX_BYTES:
        raise ValueError("display exceeds bound")
    return body


def number(raw, pos, suffix):
    match = re.match(rb"[0-9]+" + re.escape(suffix), raw[pos:])
    if match is None:
        raise ValueError("bad length/reference framing")
    token = match.group(0)
    digits = token[: -len(suffix)] if suffix else token
    return int(digits), pos + len(token)


def replace_tokens(raw, replace):
    """JSON string/escape aware; markers inside quoted metadata are ordinary data."""
    result, i, quoted = bytearray(), 0, False
    while i < len(raw):
        byte = raw[i]
        if quoted:
            result.append(byte)
            i += 1
            if byte == 92:
                if i == len(raw):
                    raise ValueError("unfinished JSON escape")
                result.append(raw[i])
                i += 1
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
            result.append(byte)
            i += 1
        elif byte in [126, 64]:
            text, i = replace(raw, i)
            result.extend(canonical(text))
        else:
            result.append(byte)
            i += 1
    if quoted:
        raise ValueError("unfinished JSON string")
    return json.loads(result)


def decode_inline(raw):
    if not isinstance(raw, bytes) or len(raw) > MAX_BYTES or not raw.startswith(INLINE):
        raise ValueError("invalid inline display")

    def replace(body, pos):
        if body[pos] != 126:
            raise ValueError("unexpected pool marker")
        size, start = number(body, pos + 1, b":\n")
        end = start + size
        if end > len(body) or body[end : end + 2] != b"\n~":
            raise ValueError("bad inline source boundary")
        return body[start:end].decode("utf-8"), end + 2

    value = replace_tokens(raw[len(INLINE) :], replace)
    if encode_inline(value) != raw:
        raise ValueError("noncanonical or misplaced source marker")
    return value


def decode_pool(raw):
    if not isinstance(raw, bytes) or len(raw) > MAX_BYTES or not raw.startswith(POOL):
        raise ValueError("invalid pooled display")
    pos = len(POOL)
    if raw[pos : pos + 2] != b"M:":
        raise ValueError("metadata frame missing")
    size, start = number(raw, pos + 2, b"\n")
    end = start + size
    metadata = raw[start:end]
    if len(metadata) != size or raw[end : end + 3] != b"\nS:":
        raise ValueError("source table missing")
    count, pos = number(raw, end + 3, b"\n")
    if count > MAX_BYTES:
        raise ValueError("source count exceeds bound")
    sources = []
    for i in range(count):
        ident, pos = number(raw, pos, b":")
        length, pos = number(raw, pos, b"\n")
        if ident != i or pos + length >= len(raw) or raw[pos + length : pos + length + 1] != b"\n":
            raise ValueError("source table boundary differs")
        sources.append(raw[pos : pos + length].decode("utf-8"))
        pos += length + 1
    if pos != len(raw):
        raise ValueError("unconsumed source bytes")

    def replace(body, pos):
        if body[pos] != 64:
            raise ValueError("unexpected inline marker")
        match = re.match(rb"[0-9]+", body[pos + 1 :])
        if match is None:
            raise ValueError("bad source reference")
        ident = int(match.group(0))
        if ident >= len(sources):
            raise ValueError("unknown source reference")
        return sources[ident], pos + 1 + len(match.group(0))

    value = replace_tokens(metadata, replace)
    if encode_pool(value) != raw:
        raise ValueError("noncanonical, unused or misplaced source reference")
    return value


CANDIDATES = {"inline-0": (encode_inline, decode_inline), "pool-0": (encode_pool, decode_pool)}
