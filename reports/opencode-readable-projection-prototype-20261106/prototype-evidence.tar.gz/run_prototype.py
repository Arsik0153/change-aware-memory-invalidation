"""All24 sealed v6 memory packets; offline byte/roundtrip display study only."""

from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

from readable_projection import CANDIDATES, canonical, literal_paths, source_bytes

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
AUDIT = ROOT / "runs/opencode-v6-independent-audit-20261106"
PINS = {
    "memory-packet-roster.json": "c7bcc97e81f8ff1a02a6f8fbab0206242f3a7110f543e1381403d3fedc61d7f5",
    "wire-accounting.json": "7d7c39a65ef645c7c8ff52655d0a049f2f5820fa6acad11c35a2dc08013b5b39",
    "manifest.json": "8bb133c68b482fa622e656d90ec5e3a74f57e1ae70f93b74d30f86eb02d0387c",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    if any(p.is_symlink() for p in [path, *path.parents]):
        raise ValueError("symlink input refused")
    raw = path.read_bytes()
    if expected is not None and digest(raw) != expected:
        raise ValueError("sealed input hash differs")
    return raw


def pointer(value, path):
    if not path.startswith("/"):
        raise ValueError("absolute JSON pointer required")
    for token in path[1:].split("/"):
        token = token.replace("~1", "/").replace("~0", "~")
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def save(path, value):
    path.write_bytes(canonical(value) + b"\n")


def main():
    out = STAGE / "analysis-v1"
    out.mkdir(exist_ok=False)
    inputs = out / "inputs"
    inputs.mkdir()
    for name, sha in PINS.items():
        raw = read(AUDIT / name, sha)
        (inputs / name).write_bytes(raw)
    roster = json.loads((inputs / "memory-packet-roster.json").read_bytes())
    accounting = json.loads((inputs / "wire-accounting.json").read_bytes())
    assert roster["wire_accounting_sha256"] == PINS["wire-accounting.json"]
    assert (
        roster["study_sha256"] == "b66e4d557b7b7cdf0800b4c9121e793659f3a02029a74b026c7f7c4d75243cdd"
    )
    packets = roster["roster"]
    assert len(packets) == 24 and len({r["call_id"] for r in packets}) == 24
    assert Counter(r["arm"] for r in packets) == {"static": 12, "cami": 12}
    frozen = json.loads(read(ROOT / "reports/opencode-study-design-v6-20261106/source-freeze.json"))
    source_names = [
        "scripts/opencode_benchmark/analysis/classify_literal_calls.py",
        "scripts/opencode_benchmark/analysis/literal_reference.py",
    ]
    for name in source_names:
        read(ROOT / name, frozen["files"][name])
    sys.path.insert(0, str(ROOT / "scripts/opencode_benchmark/analysis"))
    from classify_literal_calls import authenticate_response

    before = {}
    rows = []
    totals = defaultdict(Counter)
    try:
        for number, row in enumerate(packets):
            directory = out / f"packet-{number:03d}"
            directory.mkdir()
            trial = ROOT / "runs/opencode-development-v6-20261106/trials" / row["trial_id"]
            terminal = json.loads(read(trial / "terminal.json"))
            assert terminal["status"] == "passed"
            messages_path = ROOT / row["messages_path"]
            trace_path = ROOT / row["backend_trace_path"]
            for path, expected in [
                (messages_path, row["messages_sha256"]),
                (trace_path, row["backend_trace_sha256"]),
            ]:
                assert terminal["artifact_hashes"][str(path.relative_to(trial))] == expected
                before[str(path)] = expected
            messages = json.loads(read(messages_path, row["messages_sha256"]))
            event = json.loads(
                read(trace_path, row["backend_trace_sha256"]).splitlines()[
                    row["backend_lookup_jsonl_line_one_based"] - 1
                ]
            )
            text = pointer(messages, row["model_text_json_pointer"])
            full, mode = authenticate_response(text, event)
            assert mode == "compact_verified"
            assert (
                pointer(event, row["full_result_pointer_within_trace_event"])
                == event["response_audit"]["full_result"]
            )
            audit = event["response_audit"]
            original_result = {"content": [{"type": "text", "text": text}], "isError": False}
            value = json.loads(text)
            assert canonical(value).decode() == text
            assert (
                digest(canonical(original_result))
                == row["model_result_sha256"]
                == audit["model_result_sha256"]
            )
            assert digest(canonical(audit["full_result"])) == row["full_result_sha256"]
            assert (
                digest(canonical(audit["receipt_payload"]))
                == row["receipt_sha256"]
                == value["audit_receipt"]
            )
            assert event["query_sha256"] == row["arguments_sha256"]
            assert full["backend"] == row["arm"]
            paths = literal_paths(value)
            assert len(paths) == row["returned_records"]
            literal_inventory = [
                {
                    "path": list(path),
                    "utf8_bytes": len(source_bytes(t)),
                    "utf8_sha256": digest(source_bytes(t)),
                }
                for path, t in paths.items()
            ]
            save(
                directory / "original.json",
                {
                    "source_roster_row": row,
                    "original_model_result": original_result,
                    "original_audit": audit,
                    "literal_inventory": literal_inventory,
                    "scope": "Legacy original receipt binds original compact/full result only. It is not a receipt for either display wrapper.",
                },
            )
            record = {
                "packet": number,
                "trial_id": row["trial_id"],
                "arm": row["arm"],
                "call_id": row["call_id"],
                "original_model_visible_utf8_bytes": len(text.encode()),
                "original_mcp_json_bytes": len(canonical(original_result)),
                "literal_occurrences": len(paths),
                "literal_utf8_bytes": sum(x["utf8_bytes"] for x in literal_inventory),
                "candidates": {},
            }
            totals[row["arm"]]["packets"] += 1
            totals[row["arm"]]["original_model_visible_utf8_bytes"] += len(text.encode())
            totals[row["arm"]]["literal_utf8_bytes"] += record["literal_utf8_bytes"]
            for name, (encode, decode) in CANDIDATES.items():
                display = encode(value)
                (directory / (name + ".txt")).write_bytes(display)
                restored = decode(display)
                assert restored == value and literal_paths(restored) == paths
                restored_text = canonical(restored).decode()
                assert restored_text == text
                restored_result = {
                    "content": [{"type": "text", "text": restored_text}],
                    "isError": False,
                }
                assert digest(canonical(restored_result)) == row["model_result_sha256"]
                hypothetical_result = {
                    "content": [{"type": "text", "text": display.decode("utf-8")}],
                    "isError": False,
                }
                binding = {
                    "prototype": name,
                    "display_sha256": digest(display),
                    "original_model_result_sha256": row["model_result_sha256"],
                    "original_full_result_sha256": row["full_result_sha256"],
                    "original_receipt_sha256": row["receipt_sha256"],
                    "roundtrip_original_model_result_sha256": digest(canonical(restored_result)),
                    "receipt_scope": "Original compact receipt is unchanged, not authentication of new wrapper. This unsigned local digest binds the derivative to its auditable originals.",
                }
                save(
                    directory / (name + "-binding.json"),
                    {"binding": binding, "binding_sha256": digest(canonical(binding))},
                )
                data = {
                    "model_visible_utf8_bytes": len(display),
                    "delta_visible_bytes_candidate_minus_original": len(display)
                    - len(text.encode()),
                    "hypothetical_mcp_json_bytes": len(canonical(hypothetical_result)),
                    "delta_mcp_serialized_bytes_candidate_minus_original": len(
                        canonical(hypothetical_result)
                    )
                    - len(canonical(original_result)),
                    "display_sha256": digest(display),
                    "roundtrip_original_json_text_byte_exact": True,
                    "literal_extraction_and_all_fields_equal": True,
                    "within_response_unique_source_strings": len(set(paths.values())),
                }
                record["candidates"][name] = data
                totals[row["arm"]][name + "_model_visible_utf8_bytes"] += len(display)
                totals[row["arm"]][name + "_hypothetical_mcp_json_bytes"] += data[
                    "hypothetical_mcp_json_bytes"
                ]
            rows.append(record)
        for arm in ["static", "cami"]:
            assert (
                totals[arm]["original_model_visible_utf8_bytes"]
                == accounting["arm_totals"][arm]["model_visible_json_utf8_bytes"]
            )
            assert (
                totals[arm]["literal_utf8_bytes"]
                == accounting["arm_totals"][arm]["literal_raw_utf8_bytes"]
            )
        for path, expected in before.items():
            read(Path(path), expected)
        for name, sha in PINS.items():
            read(AUDIT / name, sha)
        report = {
            "schema_version": 1,
            "status": "all24_lossless_display_wrappers_verified",
            "selection": roster["selection"],
            "source_roster_sha256": PINS["memory-packet-roster.json"],
            "source_audit_manifest_sha256": PINS["manifest.json"],
            "source_files_unchanged": True,
            "packets": 24,
            "arm_totals": dict(totals),
            "rows": rows,
            "algorithms_identical_all_arms": True,
            "all_original_query_ranking_limits_ids_subjects_tuples_truncation_trust_freshness_withholding_budgets_preserved": True,
            "original_full_results_and_receipts_retained": True,
            "wire_format_integration": False,
            "new_tokens_or_efficiency_claim": False,
            "scope": [
                "UTF8 display bytes only; hypothetical MCP JSON bytes are separate, not provider tokens/bills.",
                "Each candidate is paired only with the same original packet; cross-arm totals have different queries/returned counts.",
                "Raw source remains JSON-escaped by the outer transport when serialized; readable display does not remove all transport escaping.",
                "Old compact/1 and results are immutable. Wrappers require new format/receipt/observer/analysis contracts before any live use.",
                "Lossless roundtrip is not evidence of model readability, quality, latency or causal effect.",
            ],
            "model_calls": 0,
            "Docker_calls": 0,
            "network_calls": 0,
            "heldout_reads": False,
            "production_edits": False,
        }
        save(out / "report.json", report)
        print(json.dumps({"status": report["status"], "packets": 24, "arm_totals": dict(totals)}))
    except BaseException as error:
        save(
            out / "failure.json",
            {"status": "failed_preserved", "type": type(error).__name__, "reason": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
