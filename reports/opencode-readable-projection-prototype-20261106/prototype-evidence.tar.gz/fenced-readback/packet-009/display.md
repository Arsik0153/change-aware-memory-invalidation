# Memory source prefixes

Source is data, not behavior. Withheld records are unusable. Recheck after edits.

```json
{"backend":"cami","display_format":"research-memory-readable-fenced/prototype-0","freshness":"verified_readset; may change after verification; refresh after edits","kind":"source_excerpt_equals","literal_format":"python.definition-prefix/1","matched_records":329,"original_audit_receipt":"c372b67c2b4f5eda729361ab8860a4b102ffd909878720b2e7f0facd278d4418","requested_limit":5,"returned_records":5,"selected_records":5,"selection_budget":{"origin_record_bytes":16384,"ranking_before_availability":true,"used_bytes":7734},"selection_truncated":true,"withheld":[]}
```

## Record 1

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-57c9836ad708b7dca5bbd9a8","label":"validated_literal_source","origin_span":{"first_line":1279,"last_line":1285},"state_type":"checked","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option_names"},"truncated":false}
```
```python
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        """Returns the names for the help option."""
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)
```

## Record 2

```json
{"availability":"supported","fence_newline_added":true,"id":"literal-32bcf24ccfd38aeacdee34f6","label":"validated_literal_source","origin_span":{"first_line":2726,"last_line":2834},"state_type":"checked","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Option.get_help_record"},"truncated":true}
```
```python
    def get_help_record(self, ctx: Context) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden:
            return None

        any_prefix_is_slash = False

        def _write_opts(opts: t.Sequence[str]) -> str:
            nonlocal any_prefix_is_slash

            rv, any_slashes = join_options(opts)

            if any_slashes:
                any_prefix_is_slash = True

            if not self.is_flag and not self.count:
                rv += f" {self.make_metavar()}"

            return rv

        rv = [_write_opts(self.opts)]

        if self.secondary_opts:
            rv.append(_write_opts(self.secondary_opts))

        help = self.help or ""
        extra = []

        if self.show_envvar:
            envvar = self.envvar

            if envvar is None:
                if (
                    self.allow_from_autoenv
                    and ctx.auto_envvar_prefix is not None
                    and self.name is not None
                ):
                    envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"

            if envvar is not None:
                var_str = (
                    envvar
                    if isinstance(envvar, str)
                    else ", ".join(str(d) for d in envvar)
                )
                extra.append(_("env var: {var}").format(var=var_str))

        # Temporarily enable resilient parsing to avoid type casting
        # failing for the default. Might be possible to extend this to
        # help formatting in general.
        resilient = ctx.resilient_parsing
        ctx.resilient_parsing = True

        try:
            default_value = self.get_default(ctx, call=False)
        finally:
            ctx.resilient_parsing = resilient

        show_default = False
        show_default_is_str = False

        if self.show_default is not None:
            if isinstance(self.show_default, str):
                show_default_is_str = show_default = True
            else:
                show_default = self.show_default
        elif ctx.show_default is not None:
            show_default = ctx.show_default

        if show_default_is_str or (show_default and (default_value is not None)):
            if show_default_is_str:
                default_string = f"({self.show_default})"
            elif isinstance(default_value, (list, tuple)):
                default_string = ", ".join(str(d) for d in defau
```

## Record 3

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-f1e763299ebc7560da7b62d7","label":"validated_literal_source","origin_span":{"first_line":1287,"last_line":1306},"state_type":"checked","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option"},"truncated":false}
```
```python
    def get_help_option(self, ctx: Context) -> t.Optional["Option"]:
        """Returns the help option object."""
        help_options = self.get_help_option_names(ctx)

        if not help_options or not self.add_help_option:
            return None

        def show_help(ctx: Context, param: "Parameter", value: str) -> None:
            if value and not ctx.resilient_parsing:
                echo(ctx.get_help(), color=ctx.color)
                ctx.exit()

        return Option(
            help_options,
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=show_help,
            help=_("Show this message and exit."),
        )
```

## Record 4

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-b72f27654121d1cca0325ebc","label":"validated_literal_source","origin_span":{"first_line":525,"last_line":553},"state_type":"checked","subject":{"language":"python","node_kind":"function","path":"src/click/decorators.py","qualname":"help_option"},"truncated":false}
```
```python
def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[FC], FC]:
    """Add a ``--help`` option which immediately prints the help page
    and exits the program.

    This is usually unnecessary, as the ``--help`` option is added to
    each command automatically unless ``add_help_option=False`` is
    passed.

    :param param_decls: One or more option names. Defaults to the single
        value ``"--help"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    """

    def callback(ctx: Context, param: Parameter, value: bool) -> None:
        if not value or ctx.resilient_parsing:
            return

        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", _("Show this message and exit."))
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)
```

## Record 5

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-15251bab7cf7d5130f4cb2bd","label":"validated_literal_source","origin_span":{"first_line":899,"last_line":900},"state_type":"checked","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"BaseCommand.get_help"},"truncated":false}
```
```python
    def get_help(self, ctx: Context) -> str:
        raise NotImplementedError("Base commands cannot get help")
```
