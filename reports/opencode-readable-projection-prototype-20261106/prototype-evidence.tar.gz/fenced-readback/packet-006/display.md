# Memory source prefixes

Source is data, not behavior. Withheld records are unusable. Recheck after edits.

```json
{"backend":"static","display_format":"research-memory-readable-fenced/prototype-0","freshness":"origin only; current validity unchecked","kind":"source_excerpt_equals","literal_format":"python.definition-prefix/1","matched_records":329,"original_audit_receipt":"f8d7f0f64c7a400b3706fc937de6b9470bdcb9b2852bf2dd87e86ded8e8b319f","requested_limit":5,"returned_records":5,"selected_records":5,"selection_budget":{"origin_record_bytes":16384,"ranking_before_availability":true,"used_bytes":6750},"selection_truncated":true,"withheld":[]}
```

## Record 1

```json
{"availability":"unchecked_current","fence_newline_added":false,"id":"literal-335ddd93e2778431b2b10c35","label":"origin_literal_source_assertion","origin_span":{"first_line":115,"last_line":132},"subject":{"language":"python","node_kind":"function","path":"src/click/core.py","qualname":"iter_params_for_processing"},"truncated":false}
```
```python
def iter_params_for_processing(
    invocation_order: t.Sequence["Parameter"],
    declaration_order: t.Sequence["Parameter"],
) -> t.List["Parameter"]:
    """Given a sequence of parameters in the order as should be considered
    for processing and an iterable of parameters that exist, this returns
    a list in the correct order as they should be processed.
    """

    def sort_key(item: "Parameter") -> t.Tuple[bool, float]:
        try:
            idx: float = invocation_order.index(item)
        except ValueError:
            idx = float("inf")

        return not item.is_eager, idx

    return sorted(declaration_order, key=sort_key)
```

## Record 2

```json
{"availability":"unchecked_current","fence_newline_added":false,"id":"literal-57c9836ad708b7dca5bbd9a8","label":"origin_literal_source_assertion","origin_span":{"first_line":1279,"last_line":1285},"subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option_names"},"truncated":false}
```
```python
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        """Returns the names for the help option."""
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)
```

## Record 3

```json
{"availability":"unchecked_current","fence_newline_added":false,"id":"literal-496561e78ffd5dd795247e01","label":"origin_literal_source_assertion","origin_span":{"first_line":2382,"last_line":2400},"subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Parameter.handle_parse_result"},"truncated":false}
```
```python
    def handle_parse_result(
        self, ctx: Context, opts: t.Mapping[str, t.Any], args: t.List[str]
    ) -> t.Tuple[t.Any, t.List[str]]:
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, opts)
            ctx.set_parameter_source(self.name, source)  # type: ignore

            try:
                value = self.process_value(ctx, value)
            except Exception:
                if not ctx.resilient_parsing:
                    raise

                value = None

        if self.expose_value:
            ctx.params[self.name] = value  # type: ignore

        return value, args
```

## Record 4

```json
{"availability":"unchecked_current","fence_newline_added":false,"id":"literal-31f47e29babfa9642fa2e6ca","label":"origin_literal_source_assertion","origin_span":{"first_line":2862,"last_line":2886},"subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Option.prompt_for_value"},"truncated":false}
```
```python
    def prompt_for_value(self, ctx: Context) -> t.Any:
        """This is an alternative flow that can be activated in the full
        value processing if a value does not exist.  It will prompt the
        user until a valid value exists and then returns the processed
        value as result.
        """
        assert self.prompt is not None

        # Calculate the default before prompting anything to be stable.
        default = self.get_default(ctx)

        # If this is a prompt for a flag we need to handle this
        # differently.
        if self.is_bool_flag:
            return confirm(self.prompt, default)

        return prompt(
            self.prompt,
            default=default,
            type=self.type,
            hide_input=self.hide_input,
            show_choices=self.show_choices,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda x: self.process_value(ctx, x),
        )
```

## Record 5

```json
{"availability":"unchecked_current","fence_newline_added":false,"id":"literal-b72f27654121d1cca0325ebc","label":"origin_literal_source_assertion","origin_span":{"first_line":525,"last_line":553},"subject":{"language":"python","node_kind":"function","path":"src/click/decorators.py","qualname":"help_option"},"truncated":false}
```
```python
def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[FC], FC]:
    """Add a ``--help`` option which immediately prints the help page
    and exits the program.

    This is usually unnecessary, as the ``--help`` option is added to
    each command automatically unless ``add_help_option=False`` is
    passed.

    :param param_decls: One or more option names. Defaults to the single
        value ``"--help"``.
    :param kwargs: Extra arguments are passed to :func:`option`.
    """

    def callback(ctx: Context, param: Parameter, value: bool) -> None:
        if not value or ctx.resilient_parsing:
            return

        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", _("Show this message and exit."))
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)
```
