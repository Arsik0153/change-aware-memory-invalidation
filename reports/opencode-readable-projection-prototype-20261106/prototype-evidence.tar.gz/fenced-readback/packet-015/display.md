# Memory source prefixes

Source is data, not behavior. Withheld records are unusable. Recheck after edits.

```json
{"backend":"cami","display_format":"research-memory-readable-fenced/prototype-0","freshness":"verified_readset; may change after verification; refresh after edits","kind":"source_excerpt_equals","literal_format":"python.definition-prefix/1","matched_records":329,"original_audit_receipt":"cc4a29de22bdbe2397164bebf5fbf5c089c1dddce2d29b4b781b2f938e3096c8","requested_limit":5,"returned_records":3,"selected_records":5,"selection_budget":{"origin_record_bytes":16384,"ranking_before_availability":true,"used_bytes":7396},"selection_truncated":true,"withheld":[{"id":"literal-b72f27654121d1cca0325ebc","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"function","path":"src/click/decorators.py","qualname":"help_option"}},{"id":"literal-f1e763299ebc7560da7b62d7","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option"}}]}
```

## Record 1

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-57c9836ad708b7dca5bbd9a8","label":"validated_literal_source","origin_span":{"first_line":1279,"last_line":1285},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option_names"},"truncated":false}
```
```python
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        """Returns the names for the help option."""
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)
```

## Record 2

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-488f43e660682a257294c9e7","label":"validated_literal_source","origin_span":{"first_line":2687,"last_line":2724},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Option.add_to_parser"},"truncated":false}
```
```python
    def add_to_parser(self, parser: OptionParser, ctx: Context) -> None:
        if self.multiple:
            action = "append"
        elif self.count:
            action = "count"
        else:
            action = "store"

        if self.is_flag:
            action = f"{action}_const"

            if self.is_bool_flag and self.secondary_opts:
                parser.add_option(
                    obj=self, opts=self.opts, dest=self.name, action=action, const=True
                )
                parser.add_option(
                    obj=self,
                    opts=self.secondary_opts,
                    dest=self.name,
                    action=action,
                    const=False,
                )
            else:
                parser.add_option(
                    obj=self,
                    opts=self.opts,
                    dest=self.name,
                    action=action,
                    const=self.flag_value,
                )
        else:
            parser.add_option(
                obj=self,
                opts=self.opts,
                dest=self.name,
                action=action,
                nargs=self.nargs,
            )
```

## Record 3

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-effbea113565491ba854740f","label":"validated_literal_source","origin_span":{"first_line":293,"last_line":316},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/parser.py","qualname":"OptionParser.add_option"},"truncated":false}
```
```python
    def add_option(
        self,
        obj: "CoreOption",
        opts: t.Sequence[str],
        dest: t.Optional[str],
        action: t.Optional[str] = None,
        nargs: int = 1,
        const: t.Optional[t.Any] = None,
    ) -> None:
        """Adds a new option named `dest` to the parser.  The destination
        is not inferred (unlike with optparse) and needs to be explicitly
        provided.  Action can be any of ``store``, ``store_const``,
        ``append``, ``append_const`` or ``count``.

        The `obj` can be used to identify the option in the order list
        that is returned from the parser.
        """
        opts = [normalize_opt(opt, self.ctx) for opt in opts]
        option = Option(obj, opts, dest, action=action, nargs=nargs, const=const)
        self._opt_prefixes.update(option.prefixes)
        for opt in option._short_opts:
            self._short_opt[opt] = option
        for opt in option._long_opts:
            self._long_opt[opt] = option
```
