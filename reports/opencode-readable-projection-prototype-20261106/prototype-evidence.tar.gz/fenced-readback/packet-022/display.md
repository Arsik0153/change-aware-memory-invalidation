# Memory source prefixes

Source is data, not behavior. Withheld records are unusable. Recheck after edits.

```json
{"backend":"cami","display_format":"research-memory-readable-fenced/prototype-0","freshness":"verified_readset; may change after verification; refresh after edits","kind":"source_excerpt_equals","literal_format":"python.definition-prefix/1","matched_records":329,"original_audit_receipt":"0842eb4024b227ab6dac756e2eac192cfe0ad1ec72dd4b4fdaa8f1145958506c","requested_limit":5,"returned_records":3,"selected_records":5,"selection_budget":{"origin_record_bytes":16384,"ranking_before_availability":true,"used_bytes":6802},"selection_truncated":true,"withheld":[{"id":"literal-b72f27654121d1cca0325ebc","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"function","path":"src/click/decorators.py","qualname":"help_option"}},{"id":"literal-f1e763299ebc7560da7b62d7","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option"}}]}
```

## Record 1

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-335ddd93e2778431b2b10c35","label":"validated_literal_source","origin_span":{"first_line":115,"last_line":132},"state_type":"carried","subject":{"language":"python","node_kind":"function","path":"src/click/core.py","qualname":"iter_params_for_processing"},"truncated":false}
```
```python
def iter_params_for_processing(
    invocation_order: t.Sequence["Parameter"],
    declaration_order: t.Sequence["Parameter"],
) -> t.List["Parameter"]:
    """Given a sequence of parameters in the order as should be considered
    for processing and an iterable of parameters that exist, this returns
    a list in the correct order as they should be processed.
    """

    def sort_key(item: "Parameter") -> t.Tuple[bool, float]:
        try:
            idx: float = invocation_order.index(item)
        except ValueError:
            idx = float("inf")

        return not item.is_eager, idx

    return sorted(declaration_order, key=sort_key)
```

## Record 2

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-57c9836ad708b7dca5bbd9a8","label":"validated_literal_source","origin_span":{"first_line":1279,"last_line":1285},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option_names"},"truncated":false}
```
```python
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        """Returns the names for the help option."""
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)
```

## Record 3

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-31f47e29babfa9642fa2e6ca","label":"validated_literal_source","origin_span":{"first_line":2862,"last_line":2886},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Option.prompt_for_value"},"truncated":false}
```
```python
    def prompt_for_value(self, ctx: Context) -> t.Any:
        """This is an alternative flow that can be activated in the full
        value processing if a value does not exist.  It will prompt the
        user until a valid value exists and then returns the processed
        value as result.
        """
        assert self.prompt is not None

        # Calculate the default before prompting anything to be stable.
        default = self.get_default(ctx)

        # If this is a prompt for a flag we need to handle this
        # differently.
        if self.is_bool_flag:
            return confirm(self.prompt, default)

        return prompt(
            self.prompt,
            default=default,
            type=self.type,
            hide_input=self.hide_input,
            show_choices=self.show_choices,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda x: self.process_value(ctx, x),
        )
```
