# Memory source prefixes

Source is data, not behavior. Withheld records are unusable. Recheck after edits.

```json
{"backend":"cami","display_format":"research-memory-readable-fenced/prototype-0","freshness":"verified_readset; may change after verification; refresh after edits","kind":"source_excerpt_equals","literal_format":"python.definition-prefix/1","matched_records":329,"original_audit_receipt":"429598b66a3fe6247e192b649958bbb560b086006471d481ff9b5f2a77733129","requested_limit":5,"returned_records":3,"selected_records":5,"selection_budget":{"origin_record_bytes":16384,"ranking_before_availability":true,"used_bytes":7808},"selection_truncated":true,"withheld":[{"id":"literal-b72f27654121d1cca0325ebc","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"function","path":"src/click/decorators.py","qualname":"help_option"}},{"id":"literal-f1e763299ebc7560da7b62d7","kind":"source_excerpt_equals","reason":"source_excerpt_mismatch","required_action":"review_and_update_expectation","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option"}}]}
```

## Record 1

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-57c9836ad708b7dca5bbd9a8","label":"validated_literal_source","origin_span":{"first_line":1279,"last_line":1285},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Command.get_help_option_names"},"truncated":false}
```
```python
    def get_help_option_names(self, ctx: Context) -> t.List[str]:
        """Returns the names for the help option."""
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)
```

## Record 2

```json
{"availability":"supported","fence_newline_added":true,"id":"literal-32bcf24ccfd38aeacdee34f6","label":"validated_literal_source","origin_span":{"first_line":2726,"last_line":2834},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Option.get_help_record"},"truncated":true}
```
```python
    def get_help_record(self, ctx: Context) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden:
            return None

        any_prefix_is_slash = False

        def _write_opts(opts: t.Sequence[str]) -> str:
            nonlocal any_prefix_is_slash

            rv, any_slashes = join_options(opts)

            if any_slashes:
                any_prefix_is_slash = True

            if not self.is_flag and not self.count:
                rv += f" {self.make_metavar()}"

            return rv

        rv = [_write_opts(self.opts)]

        if self.secondary_opts:
            rv.append(_write_opts(self.secondary_opts))

        help = self.help or ""
        extra = []

        if self.show_envvar:
            envvar = self.envvar

            if envvar is None:
                if (
                    self.allow_from_autoenv
                    and ctx.auto_envvar_prefix is not None
                    and self.name is not None
                ):
                    envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"

            if envvar is not None:
                var_str = (
                    envvar
                    if isinstance(envvar, str)
                    else ", ".join(str(d) for d in envvar)
                )
                extra.append(_("env var: {var}").format(var=var_str))

        # Temporarily enable resilient parsing to avoid type casting
        # failing for the default. Might be possible to extend this to
        # help formatting in general.
        resilient = ctx.resilient_parsing
        ctx.resilient_parsing = True

        try:
            default_value = self.get_default(ctx, call=False)
        finally:
            ctx.resilient_parsing = resilient

        show_default = False
        show_default_is_str = False

        if self.show_default is not None:
            if isinstance(self.show_default, str):
                show_default_is_str = show_default = True
            else:
                show_default = self.show_default
        elif ctx.show_default is not None:
            show_default = ctx.show_default

        if show_default_is_str or (show_default and (default_value is not None)):
            if show_default_is_str:
                default_string = f"({self.show_default})"
            elif isinstance(default_value, (list, tuple)):
                default_string = ", ".join(str(d) for d in defau
```

## Record 3

```json
{"availability":"supported","fence_newline_added":false,"id":"literal-b554841902ccb1dffd238050","label":"validated_literal_source","origin_span":{"first_line":699,"last_line":703},"state_type":"carried","subject":{"language":"python","node_kind":"method","path":"src/click/core.py","qualname":"Context.get_help"},"truncated":false}
```
```python
    def get_help(self) -> str:
        """Helper method to get formatted help page for the current
        context and command.
        """
        return self.command.get_help(self)
```
