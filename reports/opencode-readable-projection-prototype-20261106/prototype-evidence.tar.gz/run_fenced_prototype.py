"""Offline essential-field display comparison of every sealed v6 memory packet."""

import argparse
from collections import Counter, defaultdict
import json
import sys

from fenced_projection import FORMAT, encode, verify
from readable_projection import canonical
from run_prototype import AUDIT, PINS, ROOT, STAGE, digest, pointer, read, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=str, default="fenced-v1")
    args = parser.parse_args()
    out = (STAGE / args.out).resolve()
    if not out.is_relative_to(STAGE) or out == STAGE:
        raise ValueError("output must be a new subdirectory of this development stage")
    out.mkdir(exist_ok=False)
    roster = json.loads(
        read(AUDIT / "memory-packet-roster.json", PINS["memory-packet-roster.json"])
    )
    previous = json.loads(read(STAGE / "analysis-v1/report.json"))
    assert len(roster["roster"]) == 24
    assert Counter(row["arm"] for row in roster["roster"]) == {"static": 12, "cami": 12}
    freeze = json.loads(read(ROOT / "reports/opencode-study-design-v6-20261106/source-freeze.json"))
    for name in ["classify_literal_calls.py", "literal_reference.py"]:
        relative = "scripts/opencode_benchmark/analysis/" + name
        read(ROOT / relative, freeze["files"][relative])
    sys.path.insert(0, str(ROOT / "scripts/opencode_benchmark/analysis"))
    from classify_literal_calls import authenticate_response

    policy_path = STAGE / "field-policy.json"
    policy_hash = digest(read(policy_path))
    rows = []
    totals = defaultdict(Counter)
    source_pins = {}
    for number, row in enumerate(roster["roster"]):
        directory = out / f"packet-{number:03d}"
        directory.mkdir()
        original_path = STAGE / f"analysis-v1/packet-{number:03d}/original.json"
        original_raw = read(original_path)
        original = json.loads(original_raw)
        assert original["source_roster_row"] == row
        trace_path = ROOT / row["backend_trace_path"]
        trace = read(trace_path, row["backend_trace_sha256"])
        messages_path = ROOT / row["messages_path"]
        messages_raw = read(messages_path, row["messages_sha256"])
        source_pins[str(trace_path.relative_to(ROOT))] = digest(trace)
        source_pins[str(messages_path.relative_to(ROOT))] = digest(messages_raw)
        event = json.loads(trace.splitlines()[row["backend_lookup_jsonl_line_one_based"] - 1])
        text = pointer(json.loads(messages_raw), row["model_text_json_pointer"])
        full, mode = authenticate_response(text, event)
        assert mode == "compact_verified" and full["backend"] == row["arm"]
        assert original["original_audit"] == event["response_audit"]
        result = original["original_model_result"]
        assert result["content"][0]["text"] == text
        assert digest(canonical(result)) == row["model_result_sha256"]
        assert (
            digest(canonical(event["response_audit"]["full_result"])) == row["full_result_sha256"]
        )
        value = json.loads(text)
        display = encode(value, event)
        verification = verify(display, value, event)
        assert verification["records"] == row["returned_records"]
        # The complete full result/receipt stays unchanged in the original packet.
        assert read(original_path) == original_raw
        (directory / "display.md").write_bytes(display)
        visible = len(display)
        hypothetical = {
            "content": [{"type": "text", "text": display.decode()}],
            "isError": result["isError"],
        }
        binding = {
            "format": FORMAT,
            "display_sha256": digest(display),
            "original_sidecar_path": str(original_path.relative_to(STAGE)),
            "original_sidecar_sha256": digest(original_raw),
            "original_model_result_sha256": row["model_result_sha256"],
            "original_full_result_sha256": row["full_result_sha256"],
            "original_compact_receipt_sha256": row["receipt_sha256"],
            "field_policy_sha256": policy_hash,
            "requested_limit": event["requested_limit"],
            "receipt_scope": "Unsigned local derivative binding. The old receipt authenticates the old full/compact result, not this new display. No production projection receipt exists.",
        }
        save(
            directory / "binding.json",
            {"binding": binding, "binding_sha256": digest(canonical(binding))},
        )
        save(
            directory / "verification.json",
            {key: value for key, value in verification.items() if key != "source_tuples"},
        )
        record = {
            "packet": number,
            "trial_id": row["trial_id"],
            "arm": row["arm"],
            "call_id": row["call_id"],
            "returned_records": row["returned_records"],
            "withheld_records": row["withheld_records"],
            "original_model_visible_utf8_bytes": len(text.encode()),
            "original_mcp_json_bytes": len(canonical(result)),
            "fenced_model_visible_utf8_bytes": visible,
            "fenced_hypothetical_mcp_json_bytes": len(canonical(hypothetical)),
            "delta_visible_bytes_candidate_minus_original": visible - len(text.encode()),
            "delta_mcp_json_bytes_candidate_minus_original": len(canonical(hypothetical))
            - len(canonical(result)),
            "essential_visible_claims_exact": verification["essential_visible_claims_exact"],
            "literal_extraction_exact": verification["literal_extraction_exact"],
        }
        rows.append(record)
        for key in [
            "returned_records",
            "withheld_records",
            "original_model_visible_utf8_bytes",
            "original_mcp_json_bytes",
            "fenced_model_visible_utf8_bytes",
            "fenced_hypothetical_mcp_json_bytes",
            "delta_visible_bytes_candidate_minus_original",
            "delta_mcp_json_bytes_candidate_minus_original",
        ]:
            totals[row["arm"]][key] += record[key]
        totals[row["arm"]]["packets"] += 1
    for path, sha in source_pins.items():
        read(ROOT / path, sha)
    for name, sha in PINS.items():
        read(AUDIT / name, sha)
    report = {
        "status": "completed_offline_prototype_not_integrated",
        "format": FORMAT,
        "packet_count": len(rows),
        "roster_sha256": PINS["memory-packet-roster.json"],
        "field_policy_sha256": policy_hash,
        "coverage": "All 24 sealed memory calls, 12 per memory arm, with original order/query/ranking/limits unchanged; no outcome filtering.",
        "verification": "Original full/compact receipts independently reauthenticated; essential visible fields and literal bytes independently checked field by field. All input hashes unchanged after processing.",
        "receipt_boundary": "Old receipts bind originals only. Local derivative SHA bindings are unsigned integrity records, not production verification of a new MCP format.",
        "scope": "The fenced display preserves essential visible claims. Complete provenance/query/schema remain in the original auditable sidecar; display alone cannot reconstruct all original fields.",
        "limits": [
            "Only nonempty homogeneous source_excerpt_equals packets accepted; empty/mixed/error responses unsupported, with no silent fallback.",
            "Hypothetical MCP JSON is serialized but never sent; source newlines are still JSON escaped on the outer transport.",
            "No measured tokens, model readability, quality, latency, speedup or causal efficiency claim.",
            "Arms have different original packets/returned counts; compare each candidate with its own original only.",
        ],
        "arm_totals": {key: dict(value) for key, value in totals.items()},
        "rows": rows,
        "negative_controls": {
            "report_path": "analysis-v1/report.json",
            "report_sha256": digest(read(STAGE / "analysis-v1/report.json")),
            "arm_totals": previous["arm_totals"],
            "interpretation": "Length-framed inline/pool controls preserve the entire compact object but introduce bespoke grammar; not proposed for production. No repeated source string within any observed packet, so pooling did not deduplicate source content.",
        },
        "source_pins": source_pins,
    }
    save(out / "report.json", report)
    print(
        json.dumps(
            {
                "status": report["status"],
                "packet_count": len(rows),
                "arm_totals": report["arm_totals"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
