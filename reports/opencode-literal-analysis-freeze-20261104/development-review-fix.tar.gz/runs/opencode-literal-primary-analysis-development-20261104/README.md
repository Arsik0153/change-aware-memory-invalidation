# Pre-outcome v4 primary evaluator admission

Staged only. Install the changed `aggregate_study.py` and new `test_literal_cohort.py` after review; the other three analysis files are unchanged baseline copies for self-contained testing. No tracked file, outcome, protocol draft, heldout input or metric implementation was modified.

Two protocol IDs are admitted explicitly: the existing supported-rules ID, and exactly `opencode-cami-real-maintenance-development-v4-literal-compact`. The complete existing protected rule projection remains exact. Only the recognized v4 ID is substituted into the expected ID field. Unknown IDs, altered success rules, costs, token semantics, arms, model, sequence or repetitions fail. There is no new CLI switch, wildcard ID match, arbitrary cohort override or modified success criterion.

For the new ID, the **actual byte-bound frozen study** must also declare:

- `bundle_kind: development` and `memory_response_format: compact`.
- The explicit six-field schema2 memory-source policy with `source_excerpt_equals` and `python.definition-prefix/1`.
- Its seed equal to the normalized study seed, the versioned `seed_source_literals_v2.py` generator and exactly one `literal_source.py` helper at canonical relative paths.
- Explicit frozen SHA-256 entries for policy metadata, seed, generator and helper.

The new check runs after the existing frozen-study/run SHA/equality binding and before schedule reconstruction or any trial payload reads. It does not import the controller or regenerate a catalog. Actual source/catalog/response authentication remains the controller's pre-model boundary; this evaluator independently verifies the frozen cohort metadata and existing terminal integrity/counters. A legacy note/full-response study cannot become v4 merely by choosing a new protocol ID. The old ID path retains its previous behavior and does not gain the new schema2 requirements.

The independent cyclic schedule, single frozen study SHA, exact terminal artifact coverage, quality/measurement eligibility and all-six-pairs/same-metric rule are unchanged. No outcomes are pooled across study versions. The old `supported_rules.json` and `aggregate_metrics.py` are byte-identical.

Verification:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s runs/opencode-literal-primary-analysis-development-20261104 -p 'test*.py'
.venv/bin/ruff check runs/opencode-literal-primary-analysis-development-20261104/aggregate_study.py runs/opencode-literal-primary-analysis-development-20261104/test_literal_cohort.py
```

27 authored tests passed in 1.889s: 19 original aggregation controls and 8 new cohort controls. New tests use only synthetic temporary study/terminal records, including rehashed metadata mutations. They prove legacy success semantics, valid v4 same-metric behavior, old-note rejection under the new ID, metadata/source policy mismatches, changed shared rules, unknown IDs, cyclic-order tampering and cross-version SHA rejection. Rejection controls install a trial-reader trap to ensure no outcome payload is inspected first. The current v4 protocol draft's protected projection is accepted; no actual outcome was loaded.

This is a pre-outcome evaluator plumbing change. The current draft has not been finalized here. Root must freeze the final protocol, study and evaluator before v4 measurements. No model, Docker, network or target-source execution occurred.
