# Explicit catalog2 literal-tuple staleness analysis (staged)

This is a new offline analysis version, `source-excerpt-tuple-staleness/2`. It accepts explicit catalog schema2 and `source_excerpt_equals` only. Catalog1/manual notes and existing v3 outputs continue through the old analyzer unchanged. This stage has computed **no real trial labels** and made no model, Docker, network, Git or ProductMemory calls.

## Run after a new literal study has terminal artifacts

Install these three files together; keep the old controls/analyzer unchanged:

```sh
python summarize_literal_staleness.py --run FROZEN_DEVELOPMENT_RUN --catalog FROZEN_CATALOG2 --origin CANONICAL_ORIGIN --stage1 CANONICAL_STAGE1 --stage3 CANONICAL_STAGE3 --controls scripts/opencode_benchmark/analysis/summarize_terminal_staleness.py --analyzer scripts/analyze_opencode_staleness.py --out NEW_SEPARATE_DIRECTORY
```

Inputs are explicit public development paths; heldout/private-state/symlink roots are refused. Output must be new and outside run/source trees; fatal errors preserve `failure.json`. The roster remains the registered36 trials/three arms/four stages/three repetitions. Terminal filenames are snapshotted before reading payloads; only already-terminal attempts are inspected. Failed/plain/missing-telemetry attempts stay in the result. Nonterminal payloads and private state are not traversed.

Admission reuses the exact unmodified old `verify_terminal`, inventory/read/hash functions and API message normalizer, loaded through explicit recorded paths. Terminal artifact hashes/file coverage, trial/plan/task identity, canonical-reset full inventories and immutable/before catalog raw hashes are checked as before. Canonical trees are inventoried before/after analysis. The old wrapper/classifier is not patched or used to reinterpret typed records; the old analyzer contributes only API normalization/tool names/write policy. Hashes for all old and new implementation inputs are recorded.

## Independent literal reference

`literal_reference.py` uses only stdlib AST/tokenizer, not the CAMI, generator or adapter extractor. It matches logical decorator `@` tokens to ordered AST decorator expression ranges at the same indentation, so a leading parenthesized `@(` line is included. Strings/comments/matrix `@` are not independent decorator starts; unproved association is unavailable. It selects exact direct Python functions/methods, preserving conservative ambiguous/non-direct/parse/encoding/type unknowns. Source is never executed.

The reference reads regular bounded UTF8 source, rejects BOM and nonUTF8 cookies, and uses CRLF/LF/CR physical lines only. Unicode/form-feed separators remain literal characters. It compares the complete tuple `{format, text[:2400 Unicode characters], truncated}`. A flag-only2401→2400 edit is obsolete even when prefix text matches; a valid suffix-only change beyond a still-truncated prefix can remain the same tuple. This is neither full-body nor behavioral/API equivalence, nor an independent production binding/policy oracle.

Each selected catalog record authenticates origin full-source SHA256/size, direct subject/kind, physical span and tuple. Returned and withheld channels remain distinct. `origin_tuple/current_tuple` are bounded exact evidence with file/span hashes; a withheld comparison tuple is reviewer context and was not returned to the trial agent. A same literal under withholding does not show incorrect policy withholding.

Source comparisons are available only before any prior/overlapping possible write, using the inherited conservative tool policy. Unknown/nonfinite times and shell/unknown tools keep current source unknown. After writes, canonical base or final candidate is never substituted for contemporaneous source. Immutable-reference result caching is bounded and cleared for each classification operation.

## Full and compact authentication

Every memory call must join one backend lookup in the recorded order, with exact canonical full argument hash (including limit), catalog/backend identity, selected/returned/withheld IDs/counts and complete MCP result byte count. Duplicate IDs, missing trace, unsupported/error calls and malformed channels remain explicit; unsupported trials/calls are not counted as known source results.

Full responses bind complete payload/source to the catalog. Compact format `research-memory-compact/1` requires the public original audit: full-result digest, independent projection digest/rule, receipt digest, final model-result digest and exact model-visible text all verify. The full payload recovered from the audit is then authenticated against catalog2. Missing/redacted/different/unknown-format evidence is unsupported. Verification applies to the intact pre-scrub bytes; publication redaction must make original receipts fail. No private-state fallback, redaction reversal, inferred receipt, silent rebind or future-format interpretation is allowed.

This verifier targets the known one-text-block adapter MCP shape and successful `isError:false` envelope, not arbitrary MCP protocols. Unkeyed hashes bind frozen evidence; they are not signatures or proof of current semantic truth. Result `all_assessed_evidence_supported` describes provenance/call support, not absence of current-source unknowns. `unsupported_call_count_complete` stays false if whole trials are unassessable. Plain has no external-memory observations, not zero old internal model knowledge. Causal reliance is always `not_inferred`.

## Authored verification

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -p no:cacheprovider -q runs/opencode-literal-staleness-development-20261104/test_literal_staleness.py
.venv/bin/python -m ruff check runs/opencode-literal-staleness-development-20261104
```

28 authored tests pass in0.15s; Ruff passes. They cover physical decorators/three newline kinds/Unicode, tuple flag-only and suffix edges, independent verification of real installed compact projector output, missing/redacted/tampered compact audit, full payload/ID/channel/limit joins, before/after-write unknowns in both channels, deletion/parse/symlink unknowns, strict encoding, explicit old-catalog rejection, old recipe distinction and terminal wrapper retention of plain/failed/missing telemetry. Tests execute no target source, CAMI or actual study analysis. Source pins show the old three analysis scripts unchanged.

Reference/source classification, packet construction and any later AI reliance review are evaluation infrastructure. Their wall/CPU/storage costs must be reported separately from trial model/tool totals. Counts remain repeated dependent observations. Root must review/install/freeze this new version and its driver before applying it to a new study.

The internal offline timer covers summarize entry through final input hashing. An outer evaluation driver must additionally charge interpreter/startup imports, final report serialization/write and storage observation. No benefit conclusion is based on that partial timer.
