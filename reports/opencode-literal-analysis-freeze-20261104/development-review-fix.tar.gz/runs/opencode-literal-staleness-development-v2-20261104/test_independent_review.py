"""Bounded authored analysis review controls. No models, Docker or task data."""

from __future__ import annotations

import copy
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
STAGE = ROOT / "runs/opencode-literal-staleness-development-v2-20261104"
sys.path.insert(0, str(STAGE))
from classify_literal_calls import canonical, classify, mcp  # noqa: E402
from literal_reference import FORMAT, body, sha  # noqa: E402
from summarize_literal_staleness import load_controls, load_module, summarize  # noqa: E402

ANALYZER = ROOT / "scripts/analyze_opencode_staleness.py"
CONTROLS = ROOT / "scripts/opencode_benchmark/analysis/summarize_terminal_staleness.py"


class IndependentReview(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.origin = self.root / "origin"
        self.current = self.root / "current"
        self.origin.mkdir()
        self.current.mkdir()
        self.raw = b"@(\n deco\n)\ndef a():\n    return 1\n"
        for folder in (self.origin, self.current):
            (folder / "m.py").write_bytes(self.raw)
        source = {"path": "m.py", "sha256": sha(self.raw), "size": len(self.raw)}
        self.record = {
            "id": "literal-a",
            "source": source,
            "payload": {
                "type": "source_excerpt_equals",
                "subject": {
                    "language": "python",
                    "path": "m.py",
                    "qualname": "a",
                    "node_kind": "function",
                },
                "expected": {"format": FORMAT, "text": self.raw.decode(), "truncated": False},
                "origin_source": source,
                "origin_span": {"first_line": 1, "last_line": 5},
            },
        }
        self.catalog = {
            "schema_version": 2,
            "source_roots": ["."],
            "excluded_paths": [],
            "records": [self.record],
        }
        self.analyzer = load_module("independent_literal_review_normalizer", ANALYZER)
        body.cache_clear()

    def packet(self, compact=False, withheld=False):
        args = {"query": "literal-a", "limit": 1}
        full = {
            "schema_version": 1,
            "backend": "static",
            "query": args["query"],
            "catalog_sha256": sha(canonical(self.catalog)),
            "selected_records": 1,
            "entries": []
            if withheld
            else [
                {
                    "id": self.record["id"],
                    "payload": self.record["payload"],
                    "origin_source": self.record["source"],
                }
            ],
            "withheld": [
                {
                    "id": self.record["id"],
                    "kind": "source_excerpt_equals",
                    "subject": self.record["payload"]["subject"],
                    "reason": "source_excerpt_mismatch",
                }
            ]
            if withheld
            else [],
        }
        event = {
            "event": "memory_lookup",
            "backend": "static",
            "catalog_sha256": full["catalog_sha256"],
            "query_sha256": sha(canonical(args)),
            "returned_records": len(full["entries"]),
            "withheld_records": len(full["withheld"]),
            "error": None,
        }
        value = copy.deepcopy(full)
        if compact:
            # Independent construction of the frozen projection, not production helper.
            value = {
                key: item
                for key, item in full.items()
                if key not in {"catalog_sha256", "snapshot_id", "memory_generation_id"}
            }
            for channel in ("entries", "withheld"):
                value[channel] = [
                    {key: item for key, item in entry.items() if key != "origin_source"}
                    for entry in full[channel]
                ]
            value["response_format"] = "research-memory-compact/1"
            payload = {
                "format": "research-memory-compact/1",
                "full_result_sha256": sha(canonical(mcp(canonical(full).decode()))),
                "projection_result_sha256": sha(canonical(mcp(canonical(value).decode()))),
            }
            value["audit_receipt"] = sha(canonical(payload))
            event.update(
                response_format="compact",
                response_audit={
                    "receipt_payload": payload,
                    "receipt_sha256": value["audit_receipt"],
                    "full_result": mcp(canonical(full).decode()),
                    "model_result_sha256": sha(canonical(mcp(canonical(value).decode()))),
                },
            )
        text = canonical(value).decode()
        event["response_bytes"] = len(canonical(mcp(text)))
        rows = [
            {
                "type": "tool_use",
                "part": {
                    "id": "call-a",
                    "tool": "research_memory_memory_lookup",
                    "state": {
                        "status": "completed",
                        "input": args,
                        "output": text,
                        "time": {"start": 2, "end": 3},
                    },
                },
            }
        ]
        return rows, [event]

    def assess(self, rows=None, events=None, **options):
        if rows is None:
            rows, events = self.packet(**options)
        return classify(
            self.analyzer, rows, self.catalog, self.origin, self.current, "static", events
        )

    def test_lexical_parenthesis_scope_all_newline_forms(self):
        for ending in (b"\n", b"\r\n", b"\r"):
            raw = self.raw.replace(b"\n", ending)
            (self.origin / "m.py").write_bytes(raw)
            body.cache_clear()
            literal = body(self.origin, "m.py", "a")
            self.assertEqual(literal.text, raw.decode())
            self.assertEqual((literal.first_line, literal.last_line), (1, 5))

    def test_false_at_tokens_nested_scopes_and_unicode_are_preserved(self):
        raw = (
            '@deco("@", matrix @ matrix)\n'
            'def a():\n    @deco\n    def inner():\n        return "π\\n@"\n    return inner\n'
        ).encode()
        (self.origin / "m.py").write_bytes(raw)
        self.assertEqual(body(self.origin, "m.py", "a").text, raw.decode())

    def test_changed_opening_line_obsolete_both_wire_formats(self):
        (self.current / "m.py").write_bytes(self.raw.replace(b"@(\n", b"@( # changed\n"))
        for compact in (False, True):
            result = self.assess(compact=compact)
            self.assertEqual(result["unsupported_calls"], 0)
            self.assertEqual(result["records"][0]["assessment"], "obsolete_literal_tuple")
            self.assertEqual(result["records"][0]["causal_reliance"], "not_inferred")

    def test_truncation_flag_and_suffix_limits(self):
        prefix, suffix = 'def a():\n    return "', '"\n'
        raw = (prefix + "x" * (2401 - len(prefix) - len(suffix)) + suffix).encode()
        (self.origin / "m.py").write_bytes(raw)
        (self.current / "m.py").write_bytes(raw[:-1])
        body.cache_clear()
        old, now = body(self.origin, "m.py", "a"), body(self.current, "m.py", "a")
        self.assertEqual(old.text, now.text)
        self.assertNotEqual(old.expected(), now.expected())
        longer = (prefix + "x" * 2500 + suffix).encode()
        (self.origin / "m.py").write_bytes(longer)
        (self.current / "m.py").write_bytes(longer[:-3] + b'y"\n')
        body.cache_clear()
        self.assertEqual(
            body(self.origin, "m.py", "a").expected(), body(self.current, "m.py", "a").expected()
        )

    def test_origin_hash_and_span_changes_are_unsupported(self):
        original = copy.deepcopy(self.record)
        for field in ("hash", "span"):
            with self.subTest(field=field):
                record = copy.deepcopy(original)
                if field == "hash":
                    record["source"]["sha256"] = "0" * 64
                else:
                    record["payload"]["origin_span"]["first_line"] = 2
                self.catalog["records"] = [record]
                self.record = record
                observed = self.assess()["records"][0]
                self.assertEqual(observed["assessment"], "unsupported_origin_binding")

    def test_nonfinite_overlapping_unknown_writes_block_both_channels(self):
        for start in (None, float("nan"), float("inf"), 1, 3):
            for withheld in (False, True):
                rows, events = self.packet(withheld=withheld)
                rows.append(
                    {
                        "type": "tool_use",
                        "part": {
                            "id": "write",
                            "tool": "unknown-tool",
                            "state": {"time": {"start": start}},
                        },
                    }
                )
                result = self.assess(rows, events)
                self.assertEqual(result["records"][0]["assessment"], "unknown_after_possible_write")
                self.assertNotIn("current_tuple", result["records"][0])
                self.assertEqual(result["records"][0]["exposed_to_agent"], not withheld)
        rows, events = self.packet()
        rows.append(
            {
                "type": "tool_use",
                "part": {"id": "write", "tool": "shell", "state": {"time": {"start": 4}}},
            }
        )
        self.assertEqual(
            self.assess(rows, events)["records"][0]["assessment"], "same_literal_tuple"
        )

    def test_missing_trace_and_redacted_compact_keep_explicit_unknown(self):
        rows, _ = self.packet()
        result = self.assess(rows, None)
        self.assertEqual(result["unsupported_calls"], 1)
        self.assertEqual(result["records"], [])
        rows, events = self.packet(compact=True)
        events[0]["response_audit"]["full_result"]["content"][0]["text"] = "[REDACTED]"
        result = self.assess(rows, events)
        self.assertEqual(result["unsupported_calls"], 1)
        self.assertEqual(result["memory_calls"][0]["reported_returned_ids"], ["literal-a"])
        self.assertEqual(result["records"], [])

    def test_duplicate_and_swapped_args_cannot_authenticate(self):
        rows, events = self.packet()
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.assess(rows + rows, events)
        events[0]["query_sha256"] = sha(canonical({"query": "literal-a", "limit": 2}))
        self.assertEqual(self.assess(rows, events)["unsupported_calls"], 1)

    def test_valid_formfeed_decorator_is_conservatively_unavailable(self):
        (self.origin / "m.py").write_bytes(b"\f@deco\ndef a(): pass\n")
        self.assertEqual(body(self.origin, "m.py", "a").status, "unavailable_parse_or_lexical")

    def test_terminal_roster_retains_failed_plain_and_missing_telemetry(self):
        controls = load_controls(CONTROLS)
        run = self.root / "run"
        (run / "trials").mkdir(parents=True)
        sequence = ["one", "one", "two", "two"]

        def save(path, value):
            path.write_bytes(canonical(value) + b"\n")

        save(
            run / "frozen-study.json",
            {
                "bundle_kind": "development",
                "arms": ["plain", "static", "cami"],
                "normalized": {"sequence": sequence},
            },
        )
        plan = [
            {
                "id": f"r{rep}-{arm}-s{stage}",
                "repetition": rep,
                "arm": arm,
                "stage": stage,
                "task": sequence[stage - 1],
            }
            for rep in range(1, 4)
            for arm in ("plain", "static", "cami")
            for stage in range(1, 5)
        ]
        save(run / "plan.json", {"trials": plan})
        catalog_path = self.root / "catalog.json"
        save(catalog_path, self.catalog)
        chosen = [row for row in plan if row["repetition"] == 1 and row["stage"] == 1]
        for trial in chosen:
            directory = run / "trials" / trial["id"]
            (directory / "session/evidence").mkdir(parents=True)
            save(
                directory / "canonical-reset.json",
                {"canonical_files": controls.inventory(self.current)},
            )
            if trial["arm"] != "static":
                save(directory / "session/evidence/messages.json", [])
            artifacts = {name: row["sha256"] for name, row in controls.inventory(directory).items()}
            save(
                directory / "terminal.json",
                {
                    "trial": trial,
                    "status": "failed",
                    "artifact_hashes": artifacts,
                    "immutable_memory": {},
                },
            )
        result = summarize(
            run, catalog_path, self.origin, self.current, self.current, CONTROLS, ANALYZER
        )
        self.assertEqual(result["completed_trials"], 3)
        self.assertEqual(len(result["trials"]), 3)
        self.assertEqual(result["trials"][1]["terminal_status"], "failed")
        self.assertEqual(result["trials"][1]["status"], "unsupported_or_integrity_error")
        self.assertFalse(result["unsupported_call_count_complete"])
        self.assertFalse(result["complete_36"])


if __name__ == "__main__":
    unittest.main()
