"""One positive full control and negative unknown-marker/audit controls; no task data."""

from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--classifier-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error("new output file required; preserve prior probe")
    directory = args.classifier_dir.resolve()
    sys.path.insert(0, str(directory))
    spec = importlib.util.spec_from_file_location(
        "review_literal_full_format", directory / "classify_literal_calls.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    text = module.canonical({"schema_version": 1, "entries": [], "withheld": []}).decode()
    baseline = {
        "event": "memory_lookup",
        "error": None,
        "response_bytes": len(module.canonical(module.mcp(text))),
    }
    controls = []
    for name, changes, expected_denial in [
        ("current_full_absent_marker", {}, False),
        ("current_full_null_marker", {"response_format": None}, False),
        ("unknown_full_trace_marker", {"response_format": "future-format/2"}, True),
        ("unexpected_full_trace_audit", {"response_audit": {"future": True}}, True),
        ("unexpected_null_full_trace_audit", {"response_audit": None}, True),
    ]:
        event = copy.deepcopy(baseline)
        event.update(changes)
        try:
            module.authenticate_response(text, event)
            denied, reason = False, None
        except ValueError as error:
            denied, reason = True, str(error)
        controls.append(
            {
                "name": name,
                "expected_denial": expected_denial,
                "denied": denied,
                "passed": denied == expected_denial,
                "reason": reason,
            }
        )
    report = {
        "status": "passed" if all(row["passed"] for row in controls) else "failed",
        "classifier_dir": str(directory),
        "controls": controls,
        "model_calls": 0,
        "task_labels": 0,
    }
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
