Bounded review of the original literal staleness stage found F1: unknown full trace format/audit metadata is accepted as supported/full. Root accepted a minimal new-stage fix. See review.json and both preserved v1 probes. No actual trial labels, models, Docker, heldout, tracked edits, or producer edits.

Run fast independent controls:

    PYTHONDONTWRITEBYTECODE=1 .venv/bin/python runs/opencode-literal-staleness-review-20261104/test_independent_review.py

Run format-denial regression against root's NEW corrected stage (requires NEW output file; original v1 is expected to fail):

    PYTHONDONTWRITEBYTECODE=1 .venv/bin/python runs/opencode-literal-staleness-review-20261104/check_full_format_denial.py --classifier-dir NEW_V2_DIR --out NEW_JSON
