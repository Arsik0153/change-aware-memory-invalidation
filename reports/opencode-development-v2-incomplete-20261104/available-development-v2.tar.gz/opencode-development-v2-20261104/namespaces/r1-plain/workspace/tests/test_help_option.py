import pytest

import click


class CustomOption(click.Option):
    pass


@pytest.fixture(params=["automatic", "class", "decorator", "custom_cls"])
def help_command(request):
    def make_command(**kwargs):
        command = click.Command("cli", **kwargs)

        if request.param == "class":
            command.params.append(click.HelpOption())
        elif request.param == "decorator":
            click.help_option()(command)
        elif request.param == "custom_cls":
            click.help_option(cls=CustomOption)(command)

        return command

    return make_command


@pytest.mark.parametrize("param_decls", [None, (), ("--help",), ("-h", "--assist")])
def test_defaults(param_decls):
    option = click.HelpOption(param_decls)
    assert isinstance(option, click.Option)
    assert option.opts == list(param_decls or ("--help",))
    assert option.is_flag
    assert option.is_eager
    assert not option.expose_value
    assert option.help == "Show this message and exit."


def test_shared_class():
    command = click.Command("cli")
    assert isinstance(command.get_help_option(click.Context(command)), click.HelpOption)
    click.help_option()(command)
    assert isinstance(command.params[0], click.HelpOption)
    assert command.get_help_option(click.Context(command)) is None


def test_help_is_eager(runner, help_command):
    def callback(**kwargs):
        pytest.fail("The command should not run when help is requested.")

    command = help_command(
        callback=callback,
        params=[click.Option(["--name"], required=True, prompt=True)],
    )
    result = runner.invoke(command, ["--help"])
    assert result.exit_code == 0
    assert result.output.splitlines() == [
        "Usage: cli [OPTIONS]",
        "",
        "Options:",
        "  --name TEXT  [required]",
        "  --help       Show this message and exit.",
    ]


def test_no_value_exposed(runner, help_command):
    command = help_command(callback=lambda: click.echo("called"))
    result = runner.invoke(command)
    assert result.exit_code == 0
    assert result.output == "called\n"


@pytest.mark.parametrize("args", [[], ["--help"]])
def test_resilient_parsing(runner, help_command, args):
    command = help_command()
    result = runner.invoke(command, args, resilient_parsing=True)
    assert result.exit_code == 0
    assert result.output == ""


@pytest.mark.parametrize("color", [False, True])
def test_color(runner, help_command, color):
    styled_help = click.style("Command help", fg="green")
    command = help_command(help=styled_help)
    # Context.color must be honored even if the runner's color setting differs.
    command.context_settings["color"] = color
    result = runner.invoke(command, ["--help"], color=True)
    assert result.exit_code == 0
    assert (styled_help if color else "Command help") in result.output
    assert ("\x1b[" in result.output) is color


@pytest.mark.parametrize("source", ["automatic", "class", "decorator"])
def test_custom_names(runner, source):
    names = ["-h", "--assist"]
    command = click.Command("cli", context_settings={"help_option_names": names})

    if source == "class":
        command.params.append(click.HelpOption(names))
    elif source == "decorator":
        click.help_option(*names)(command)

    for name in names:
        result = runner.invoke(command, [name])
        assert result.exit_code == 0
        assert "Show this message and exit." in result.output

    result = runner.invoke(command, ["--help"])
    assert result.exit_code == 2
    assert "No such option: --help" in result.output


@pytest.mark.parametrize(
    "kwargs",
    [
        {"add_help_option": False},
        {"context_settings": {"help_option_names": []}},
    ],
)
def test_disabled_automatic_help(runner, kwargs):
    command = click.Command("cli", **kwargs)
    ctx = click.Context(command, **command.context_settings)
    assert command.get_help_option(ctx) is None
    result = runner.invoke(command, ["--help"])
    assert result.exit_code == 2
    assert "No such option: --help" in result.output


def test_name_conflict(runner):
    command = click.Command(
        "cli",
        params=[click.Option(["--help"], is_flag=True)],
        callback=lambda help: click.echo(help),
    )
    assert command.get_help_option(click.Context(command)) is None
    result = runner.invoke(command, ["--help"])
    assert result.exit_code == 0
    assert result.output == "True\n"


@pytest.mark.parametrize("cls", [click.HelpOption, click.Option, CustomOption])
def test_decorator_custom_class(runner, cls):
    @click.command(add_help_option=False)
    @click.help_option("-h", "--assist", cls=cls)
    def cli():
        pytest.fail("The command should not run when help is requested.")

    assert type(cli.params[0]) is cls
    result = runner.invoke(cli, ["-h"])
    assert result.exit_code == 0
    assert "-h, --assist  Show this message and exit." in result.output


@pytest.mark.parametrize("source", ["class", "decorator", "custom_cls"])
@pytest.mark.parametrize("callback_is_none", [False, True])
def test_overrides(runner, source, callback_is_none):
    seen = []

    def callback(ctx, param, value):
        seen.append((param, value))
        return value.upper()

    kwargs = dict(
        is_flag=False,
        is_eager=False,
        expose_value=True,
        help="Custom help",
        callback=None if callback_is_none else callback,
        default="default",
        metavar="VALUE",
    )

    @click.command(add_help_option=False)
    def cli(assist):
        click.echo(assist)

    if source == "class":
        cli.params.append(click.HelpOption(["--assist"], **kwargs))
    else:
        cls = CustomOption if source == "custom_cls" else None
        click.help_option("--assist", cls=cls, **kwargs)(cli)

    option = cli.params[0]
    assert not option.is_flag
    assert not option.is_eager
    assert option.expose_value
    assert option.help == "Custom help"
    assert option.callback is kwargs["callback"]
    assert option.default == "default"
    assert option.metavar == "VALUE"

    result = runner.invoke(cli, ["--assist", "hello"])
    assert result.exit_code == 0
    assert result.output == ("hello\n" if callback_is_none else "HELLO\n")
    assert seen == ([] if callback_is_none else [(option, "hello")])
