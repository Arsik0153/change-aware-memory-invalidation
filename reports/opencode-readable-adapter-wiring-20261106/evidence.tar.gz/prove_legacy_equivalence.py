"""Replay baseline/current adapter outputs and harness configs without external execution."""
from __future__ import annotations

import ast
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parents[2]
BASE = "f355b65613c7a220986cfc05c05a4c719c7b0c74"
sys.path.insert(0, str(ROOT / "integrations/opencode"))
sys.path.insert(0, str(ROOT / "scripts/opencode_benchmark/harness"))
import memory_adapter
import container_session
from memory_backend import canonical


def baseline(path):
    return subprocess.run(["git", "show", BASE + ":" + path], cwd=ROOT,
                          capture_output=True, text=True, check=True).stdout


def load_fixture():
    path = ROOT / "tests/test_opencode_readable_adapter_wiring.py"
    spec = importlib.util.spec_from_file_location("authored_wiring_fixtures", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    authored = load_fixture()
    old = types.ModuleType("baseline_memory_adapter")
    exec(compile(baseline("integrations/opencode/memory_adapter.py"), "baseline_adapter", "exec"), old.__dict__)
    tree = ast.parse(baseline("scripts/opencode_benchmark/harness/container_session.py"))
    config_node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "configuration")
    namespace = {}
    exec(compile(ast.Module(body=[config_node], type_ignores=[]), "baseline_configuration", "exec"), namespace)
    counts = {"response_and_trace_comparisons": 0, "configuration_comparisons": 0}
    with tempfile.TemporaryDirectory(prefix="authored-readable-legacy-") as tmp:
        folder = Path(tmp)
        for arm in ("static", "cami"):
            for mode in (None, "full", "compact"):
                for case in ("literal", "note", "empty", "withheld", "error"):
                    value = authored.literal_value(arm)
                    if case == "note":
                        entry = value["entries"][0]
                        entry["payload"] = {"type": "note", "subject": entry["payload"]["subject"], "text": "authored note", "note_key": "key", "sources": []}
                    if case in ("empty", "withheld"):
                        value["entries"] = []
                        if case == "withheld":
                            value["withheld"] = [{"id": "authored", "reason": "contradicted"}]
                    class FakeBackend:
                        def __init__(self, path):
                            self.binding = {"repo": str(folder / "repo"), "backend": arm, "catalog_sha256": "b" * 64, "state_home": None}
                        def lookup(self, query, limit):
                            if case == "error":
                                raise ValueError("Authored backend failure")
                            return copy.deepcopy(value), {"selected_records": 1, "returned_records": len(value["entries"])}
                    outputs = []
                    for label, module in (("old", old), ("current", memory_adapter)):
                        module.Backend = FakeBackend
                        trace = folder / (label + ".jsonl")
                        kwargs = {} if mode is None else {"response_format": mode}
                        server = module.Server(folder / "binding", trace, **kwargs)
                        server.phase = "ready"
                        result = server.dispatch(authored.request())
                        record = json.loads(trace.read_text().splitlines()[-1])
                        for key in ("wall_seconds", "cpu_seconds_self_and_completed_children"):
                            record.pop(key)
                        outputs.append((canonical(result), canonical(record)))
                    assert outputs[0] == outputs[1], (arm, mode, case)
                    counts["response_and_trace_comparisons"] += 1
        for arm in ("plain", "static", "cami"):
            for mode in (None, "full", "compact"):
                for tier in (None, "auto", "priority"):
                    kwargs = {"service_tier": tier}
                    if mode is not None:
                        kwargs["response_format"] = mode
                    expected = namespace["configuration"](arm, "authored/binding.json", **kwargs)
                    actual = container_session.configuration(arm, "authored/binding.json", **kwargs)
                    assert canonical(expected) == canonical(actual), (arm, mode, tier)
                    counts["configuration_comparisons"] += 1
    summary = {"status": "passed", "baseline_commit": BASE, **counts,
               "ignored_trace_fields": ["wall_seconds", "cpu_seconds_self_and_completed_children"],
               "model_calls": 0, "docker_calls": 0, "network_calls": 0}
    (Path(__file__).parent / "legacy-equivalence.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
