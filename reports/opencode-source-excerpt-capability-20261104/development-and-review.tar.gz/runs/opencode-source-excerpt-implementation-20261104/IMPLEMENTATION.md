# Staged core: `source_excerpt_equals`

Only the isolated `src/cami` copy in this directory is changed. No tracked source, frozen runtime, current study, adapter, catalog, generator, SQLite schema, ownership marker or database-publication machinery is edited.

## Review and execution status

`reviewable.patch` contains seven core file changes (one is new) and the two authored test files. `baseline-pins.json` binds the original copied package files. `staging-manifest.json` binds the final changed files and records deferred checks.

Executed: 25 pure extractor/model/check/transition/cache controls in 0.24 seconds, Ruff on the affected sources/tests, and syntax parsing of the staged package/tests. These controls do not construct `ProductMemory`, capture a worktree, open SQLite, import/execute target source, call a model, use Docker or access a network.

**Not executed:** 21 staged behavior cases in `tests/test_excerpt_behavior_pending.py`; existing memory/product/watch/CLI integration suites; mypy; full suite; real catalog construction; timing experiments. The behavior tests are active tests, not silently skipped by a pending flag, but have deliberately not been imported or run during the current study. Two actual old-reader/old-note checks require the preserved pre-excerpt runtime; they explicitly skip if it is unavailable and must not be counted as executed compatibility proof.

Pure check:

```sh
.venv/bin/python -m pytest -q runs/opencode-source-excerpt-implementation-20261104/tests/test_excerpt_pure.py
```

After the owner authorizes the quiet window:

```sh
.venv/bin/python -m pytest -q runs/opencode-source-excerpt-implementation-20261104/tests/test_excerpt_behavior_pending.py
```

`tests/conftest.py` selects the staged package. The stage copies Python/CJS/JSON package files, not `node_modules` or external compiler dependencies. Python behavior tests should use this stage; cross-language/full integration checks must use the complete installed dependency environment. Optional old-runtime override: `CAMI_OLD_EXCERPT_RUNTIME=/absolute/pre-excerpt/src`.

## Public capability

Use existing `remember("source_excerpt_equals", selector, authenticated_context, request_id)` or the existing bounded `RememberInput`/`remember_batch` API. The new kind rejects every non-None `text` or `note_key`, including empty strings. It accepts no arbitrary expected excerpt, hash, span or source. Existing update derives a new tuple from its authenticated context and rejects free-form replacement text for this type.

The service authenticates the context against the immutable backend view and memory-generation index, requires exactly one certain Python function/method, checks coverage/errors and that its full SourceRef is bound to that view, then reconstructs the expected tuple from verified origin CAS bytes and its backend certificate. Stale origins remain legal: their expected text is retained and current validation can immediately withhold it. Legacy origin views with no certificate require a refreshed context. Unsupported origin encodings are reported unavailable.

The payload is:

```text
{
  type: source_excerpt_equals,
  subject: <complete existing SymbolKey>,
  expected: {format: python.definition-prefix/1, text: <literal>, truncated: <bool>},
  origin_source: <complete SourceRef>,
  origin_span: {first_line: <int>, last_line: <int>}
}
```

`RecordRevision` verifies that its origin index matches the payload's origin SourceRef. The payload checks its Python kind and source path. Provenance-only origin movement does not change semantic-payload identity; the old revision retains its evidence when re-registering an identical predicate. Explicit updates and request-id conflict/retry behavior remain with the existing coordinator.

New contexts emit schema 2; the reader accepts schemas 1 and 2. Certificate presence/authenticity, not the caller's schema number alone, authorizes minting. The existing SQLite schema/version remains 1. Optional `DefinitionFact.python_excerpt=None` reads historical projections without rewriting them. Strict old readers reject the new field or discriminator. Manual notes remain free-form manual assertions with the original whole-file/sticky review policy. This type does not convert old notes.

## Literal projection and evidence

The exact region starts at column zero of the first decorator/definition physical line and ends after the complete `end_lineno` physical line, preserving indentation, inline comments and terminators. It splits only CRLF/LF/CR. Prefix length is 2,400 Unicode characters; `truncated` is true iff the region is longer. The predicate compares prefix UTF-8 SHA-256, character count, format and truncation. No marker or header is inside the expected text.

Strict UTF-8 only; BOM remains unsupported under the existing core parser. Non-UTF8 coding-cookie declarations are unavailable even when their remaining bytes are ASCII. Encoding detection receives only the first two CRLF/LF/CR physical byte lines, so a third-line cookie in a bare-CR module is ignored. No newline/Unicode normalization, AST re-rendering or behavior inference occurs. A truncated prefix can remain valid when valid code beyond the prefix changes. An unparseable module is unavailable.

The Python adapter uses its existing indexed AST association; it does not add a second resolver. It checks that captured UTF-8 text matches the indexed module source before issuing a certificate. The certificate stores span/count/digest/truncation, **not the full literal text**, in each definition fact. Explicit new validation dispatch precedes the old existence fallback. Source binding, coverage, errors, ambiguity and uncertainty remain conservative. A signature or AST digest never substitutes for literal equality.

The new dependency domain includes validator/extractor versions, full subject, current policy/analyzer identities, certainty/errors/coverage and the literal certificate tuple. Absolute lines, complete-region size and full containing-source hash do not participate in equality, so a verified unchanged literal can carry across unrelated file edits. The containing source still invalidates projection inputs: every current module certificate is rederived from its captured bytes. Ordinary `CheckedClaim`/`CarriedClaim` lineage and actual-check evidence remain intact. Full origin CAS evidence is verified during both generation verification and observation.

## Shared-source work and bounded lifetime

Implementation was adjusted after the initial draft to avoid repeating a full decode/split per definition or per excerpt record:

- One immutable `PythonExcerptSource` (decoded physical lines) is prepared per module by `PythonIndexAdapter`, then reused for its definitions.
- Batch minting retains prepared origin CAS lines by **full SourceRef**, local to that call.
- Final generation verification has separate fresh raw-CAS and prepared-line caches. It never reuses the minting cache. Observation gets fresh caches too.
- Each cache retains at most 128 full SourceRef entries and 32 MiB of byte/string-tuple bodies. Parsed cost uses actual Python tuple/string sizes. Metadata and interpreter/AST/transient allocations are outside these cache-body limits; this is not a hard RSS claim.
- On overflow, evidence is still read/verified/reconstructed; it is simply not retained. There is no persistent cache or skipped CAS verification.

Pure controls prove one module preparation for eight definitions, one final preparation for eight distinct same-file excerpts, fresh work for a new operation, separate full-SourceRef identities even for the same blob, overflow safety, stale-certificate rejection, and stale indexed-source mismatch rejection. The staged batch behavior test checks one origin preparation plus a separate final verification preparation. Its execution is pending.

## Remaining risks and next checks

All claims of CAS/update/batch/rollback/CLI/actual old-reader behavior await the staged behavior tests and the owner's independent integration/full-suite review. No end-to-end benefit is established. New certificates add metadata to index views, stored expected literals still appear in memory revisions/state generations, and operation-local preparation/CAS work has a cost. Limits are unchanged.

The literal can omit surrounding class/global/import context and everything beyond its prefix. It must be labeled as a validated literal source projection in a later adapter version, never as behavior truth. The old adapter/catalog do not yet support this discriminator; that work is intentionally separate. Native reads or regenerating current source may still be more useful for a task. No heldout input informed this implementation.
