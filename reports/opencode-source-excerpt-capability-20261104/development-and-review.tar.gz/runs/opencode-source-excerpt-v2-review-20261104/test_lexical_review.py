"""Independent generic pure lexer/cache-body controls, no product integration."""
import ast
from dataclasses import replace
from pathlib import Path
import sys
from types import MappingProxyType

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "opencode-source-excerpt-implementation-v2-20261104/src"))
from cami.product.memory.models import PythonExcerptReady, PythonExcerptUnavailable  # noqa: E402
from cami.product.memory.python_excerpt import (  # noqa: E402
    PythonExcerptSource, origin_literal_from_certificate,
    prepare_python_excerpt_source, project_python_excerpt,
)


@pytest.mark.parametrize("ending", ["\n", "\r\n", "\r"])
def test_conditional_suite_async_backslash_and_comments(ending):
    source = ("if flag:\n    @\\\n        decorator\n    # before async header\n    async \\\n    def f():\n        return left @ right\nelse:\n    def g(): pass\n").replace("\n", ending)
    prepared = prepare_python_excerpt_source(source.encode())
    assert isinstance(prepared, PythonExcerptSource)
    nodes = [n for n in ast.walk(ast.parse(source)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    for node in nodes:
        cert = project_python_excerpt(prepared, node)
        assert isinstance(cert, PythonExcerptReady)
        expected_first = 2 if node.name == "f" else node.lineno
        assert cert.span.first_line == expected_first
        literal = origin_literal_from_certificate(prepared, cert)
        lines = source.split(ending)
        assert literal.text == ending.join(lines[expected_first - 1:node.end_lineno]) + ending


def test_map_is_immutable_body_accounted_and_bound_to_prepared_module_text():
    raw = b"@deco\ndef f(): pass\n\ndef g(): pass\n"
    prepared = prepare_python_excerpt_source(raw)
    assert isinstance(prepared, PythonExcerptSource)
    physical = sys.getsizeof(prepared.lines) + sum(map(sys.getsizeof, prepared.lines))
    map_body = sum(sys.getsizeof(k) + sys.getsizeof(v) + sum(map(sys.getsizeof, v)) for k, v in prepared.definition_decorators.items())
    assert prepared.retained_bytes >= physical + map_body
    assert prepared.retained_bytes > physical
    with pytest.raises(TypeError):
        prepared.definition_decorators[2] = ()
    mismatch = prepare_python_excerpt_source(raw, expected_source=raw.decode().replace("f()", "other()"))
    assert isinstance(mismatch, PythonExcerptUnavailable)


def test_class_decorator_strings_and_matrix_do_not_bind_plain_function():
    text = '@(\n class_decorator\n)\nclass C: pass\n\nvalue = a @ b\ntext = """\n@fake\ndef fake(): pass\n"""\ndef plain(): pass\n'
    prepared = prepare_python_excerpt_source(text.encode())
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef))
    assert isinstance(prepared, PythonExcerptSource)
    assert prepared.definition_decorators[node.lineno] == ()
    assert project_python_excerpt(prepared, node).span.first_line == node.lineno


def test_invalid_lexical_map_and_token_failure_unavailable():
    text = "@(\n deco\n)\ndef f(): pass\n"
    prepared = prepare_python_excerpt_source(text.encode())
    node = ast.parse(text).body[0]
    assert isinstance(prepared, PythonExcerptSource)
    for mapping in [{}, {node.lineno: ()}, {node.lineno: (3,)}]:
        invalid = replace(prepared, definition_decorators=MappingProxyType(mapping))
        assert isinstance(project_python_excerpt(invalid, node), PythonExcerptUnavailable)
    assert isinstance(prepare_python_excerpt_source(b"@(\n"), PythonExcerptUnavailable)
