"""Run the identical authored @-opening counterexample in isolated import lanes."""
from pathlib import Path
import json
import os
import subprocess
import sys

CHILD = r'''
import ast,hashlib,json,sys
sys.path.insert(0,sys.argv[1])
from cami.product.memory.models import CodeView,DefinitionFact,IndexRef,PathCoverage,RecordRevision,SourceExcerptPayload,SourceRef,SymbolKey
from cami.product.memory.python_excerpt import prepare_python_excerpt_source,project_python_excerpt,origin_literal_from_certificate
from cami.product.memory.validation import check
old="@(\n    decorator\n)\ndef f():\n    return 1\n"
new="@(  # authored change on first decorator physical line\n    decorator\n)\ndef f():\n    return 1\n"
subject=SymbolKey(language="python",path="src/api.py",qualname="f",node_kind="function")
def view(text,version):
    node=ast.parse(text).body[0]
    source=prepare_python_excerpt_source(text.encode())
    cert=project_python_excerpt(source,node)
    index=IndexRef(worktree_key="0"*64,snapshot_id=version*64,generation_id=version*64,policy_fingerprint="1"*64,analyzer_fingerprint="2"*64)
    ref=SourceRef(index=index,path=subject.path,sha256=hashlib.sha256(text.encode()).hexdigest(),size=len(text.encode()))
    fact=DefinitionFact(subject=subject,signature=None,source=ref,ambiguous=False,python_excerpt=cert)
    return CodeView(index=index,definitions=(fact,),sources=(ref,),coverage=(PathCoverage(path=subject.path,status="present"),)),source,cert
origin,raw,cert=view(old,"a")
current,_,newcert=view(new,"b")
payload=SourceExcerptPayload(subject=subject,expected=origin_literal_from_certificate(raw,cert),origin_source=origin.sources[0],origin_span=cert.span)
record=RecordRevision(memory_id="9"*64,revision=1,payload=payload,origin=origin.index,created_at="authored",previous_revision=None)
result=check(record,current,"authored-identical-regression")
print(json.dumps({"origin_first_line":cert.span.first_line,"current_first_line":newcert.span.first_line,"fresh_verdict":result.verdict,"reason":result.reason}))
'''


def main():
    out = Path(__file__).resolve().parent
    root = out.parents[1]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    results = {}
    for version, name in [("v1", "opencode-source-excerpt-implementation-20261104"), ("v2", "opencode-source-excerpt-implementation-v2-20261104")]:
        process = subprocess.run([sys.executable, "-I", "-c", CHILD, str(root / "runs" / name / "src")],
                                 capture_output=True, text=True, env=env, timeout=5)
        assert process.returncode == 0, process.stderr
        results[version] = json.loads(process.stdout)
    assert results["v1"]["origin_first_line"] == 2 and results["v1"]["fresh_verdict"] == "supported"
    assert results["v2"]["origin_first_line"] == 1 and results["v2"]["fresh_verdict"] == "contradicted"
    with (out / "counterexample-comparison.json").open("x") as stream:
        json.dump({"status": "v1_bug_reproduced_v2_fixed", "results": results, "target_source_executed": False}, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(results, sort_keys=True))


if __name__ == "__main__":
    main()
