"""Independent AST/token evidence for decorator @ lines; never execute source."""

from __future__ import annotations

import argparse
import ast
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tokenize


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def lexical_markers(text):
    """Logical-statement @ tokens only: strings/comments/matmul are not markers."""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = normalized.split("\n")
    markers, active, start, depth = [], None, True, 0
    for token in tokenize.generate_tokens(io.StringIO(normalized).readline):
        if token.type == tokenize.NEWLINE:
            if active is not None:
                active["logical_end_line"] = token.start[0]
                markers.append(active)
                active = None
            start = True
            continue
        if token.type in {tokenize.ENCODING, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT, tokenize.NL, tokenize.ENDMARKER}:
            continue
        if token.type == tokenize.OP:
            if token.string == "@" and start and depth == 0:
                active = {"at_line": token.start[0], "at_byte_column": len(lines[token.start[0] - 1][:token.start[1]].encode("utf-8"))}
            if token.string in {"(", "[", "{"}:
                depth += 1
            elif token.string in {")", "]", "}"}:
                depth -= 1
        start = False
    if active is not None:
        raise ValueError("unterminated_decorator_token_statement")
    return markers


def definitions(tree):
    result = []
    def visit(node, prefix=""):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + child.name
                result.append((child, name))
                nested = name + (".<locals>." if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) else ".")
                visit(child, nested)
            else:
                visit(child, prefix)
    visit(tree)
    return sorted(result, key=lambda item: (item[0].lineno, item[0].col_offset))


def inspect_source(raw):
    """Associate each lexical statement to ordered AST decorator expressions."""
    try:
        text = raw.decode("utf-8")
        tree = ast.parse(text)
        markers = lexical_markers(text)
    except (UnicodeError, SyntaxError, tokenize.TokenError, IndentationError, ValueError) as error:
        return {"status": "unsupported", "reason": type(error).__name__, "risks": []}
    used, risks, decorated = set(), [], []
    for node, qualname in definitions(tree):
        if not node.decorator_list:
            continue
        count = len(node.decorator_list)
        candidates = [(i, marker) for i, marker in enumerate(markers)
                      if i not in used and marker["at_byte_column"] == node.col_offset
                      and marker["logical_end_line"] < node.lineno]
        selected = candidates[-count:]
        if len(selected) != count or any(not marker["at_line"] <= expression.lineno <= expression.end_lineno <= marker["logical_end_line"]
                                       for (_, marker), expression in zip(selected, node.decorator_list, strict=True)):
            return {"status": "unsupported", "reason": "lexical_AST_decorator_association_unproved", "risks": risks}
        used.update(i for i, _ in selected)
        details = {"qualname": qualname, "node_kind": type(node).__name__, "definition_line": node.lineno,
                   "old_recipe_first_line": min(d.lineno for d in node.decorator_list),
                   "physical_first_at_line": selected[0][1]["at_line"],
                   "decorators": [{"at_line": marker["at_line"], "logical_end_line": marker["logical_end_line"],
                                   "AST_expression_start_line": expression.lineno, "AST_expression_end_line": expression.end_lineno}
                                  for (_, marker), expression in zip(selected, node.decorator_list, strict=True)]}
        decorated.append(details)
        if details["physical_first_at_line"] < details["old_recipe_first_line"]:
            risks.append(details)
    if len(used) != len(markers):
        return {"status": "unsupported", "reason": "unassigned_logical_decorator_marker", "risks": risks}
    return {"status": "assessed", "decorated_definitions": len(decorated),
            "decorated_functions_or_methods": sum(d["node_kind"] != "ClassDef" for d in decorated),
            "logical_decorator_markers": len(markers), "risks": risks}


def inventory(root):
    result = {}
    if root.is_symlink():
        raise ValueError("source_root_symlink")
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(directory) / name
            info = path.lstat()
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ValueError("nonregular_source_inventory_entry")
            raw = path.read_bytes()
            result[path.relative_to(root).as_posix()] = {"sha256": sha(raw), "bytes": len(raw), "mode": stat.S_IMODE(info.st_mode)}
    return dict(sorted(result.items()))


def audit(roots, catalog_path, snapshot_path, out):
    out.mkdir(parents=True, exist_ok=False)
    catalog_raw, snapshot_raw = catalog_path.read_bytes(), snapshot_path.read_bytes()
    catalog, snapshot = json.loads(catalog_raw), json.loads(snapshot_raw)
    if sha(catalog_raw) != snapshot["inputs"]["catalog_raw_sha256"]:
        raise ValueError("catalog_snapshot_hash_mismatch")
    trees, cache, affected = [], {}, []
    for root in roots:
        before = inventory(root)
        expected = snapshot["inputs"]["canonical_tree_sha256"].get(str(root))
        if expected != sha(canonical(before)):
            raise ValueError("canonical_tree_inventory_mismatch")
        sources, risks = {}, []
        for path, info in before.items():
            if not path.endswith(".py"):
                continue
            raw = (root / path).read_bytes()
            if sha(raw) != info["sha256"]:
                raise ValueError("canonical_source_changed")
            if info["sha256"] not in cache:
                cache[info["sha256"]] = inspect_source(raw)
            assessment = cache[info["sha256"]]
            sources[path] = {**info, **assessment}
            risks.extend({"path": path, "source_sha256": info["sha256"], **risk} for risk in assessment["risks"])
        targets = {(r["path"], r["qualname"]) for r in risks if r["node_kind"] != "ClassDef"}
        records = [r["id"] for r in catalog["records"]
                   if (r["payload"]["subject"]["path"], r["payload"]["subject"]["qualname"]) in targets]
        affected.append({"tree": str(root), "catalog_record_ids": records,
                         "snapshot_observations": [{"trial_id": row["trial"]["id"], "call_id": record["call_id"], "record_id": record["record_id"], "channel": record["channel"]}
                                                   for row in snapshot["trials"] for record in row.get("records") or [] if record["record_id"] in records]})
        if inventory(root) != before:
            raise ValueError("source_inventory_changed_during_audit")
        trees.append({"root": str(root), "inventory_sha256": sha(canonical(before)), "snapshot_expected_inventory_sha256": expected,
                      "python_files": len(sources), "source_file_hashes": {p: v["sha256"] for p, v in sources.items()},
                      "assessment_counts": dict(Counter(v["status"] for v in sources.values())),
                      "decorated_definitions": sum(v.get("decorated_definitions", 0) for v in sources.values()),
                      "logical_decorator_markers": sum(v.get("logical_decorator_markers", 0) for v in sources.values()),
                      "risks": risks, "sources": sources})
    result = {"schema_version": 1, "status": "assessed" if all(t["assessment_counts"].get("unsupported", 0) == 0 for t in trees) else "partial_unsupported",
              "method": "Independent stdlib AST plus logical-statement @ tokens, matched to ordered decorator expressions at identical byte indentation; not regex or production excerpt helper.",
              "source_execution": False, "production_v2_helper_used": False,
              "catalog_sha256": sha(catalog_raw), "snapshot_sha256": sha(snapshot_raw), "trees": trees, "affected": affected,
              "scope_limit": "Narrow physical-leading-@ before earliest AST-decorator-expression counterexample only. Old generator/analyzer retain their old AST-line recipe; no old output rewritten and no general exposure/behavior/reliance exactness claim.",
              "model_calls": 0, "docker_calls": 0, "heldout_reads": False}
    (out / "report.json").write_bytes(canonical(result) + b"\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tree", action="append", type=Path, required=True)
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.tree, args.catalog, args.snapshot, args.out)
    print(json.dumps({"status": result["status"], "python_files": [t["python_files"] for t in result["trees"]],
                      "risk_definitions": [len(t["risks"]) for t in result["trees"]], "affected_catalog_records": [len(a["catalog_record_ids"]) for a in result["affected"]]}))


if __name__ == "__main__":
    main()
