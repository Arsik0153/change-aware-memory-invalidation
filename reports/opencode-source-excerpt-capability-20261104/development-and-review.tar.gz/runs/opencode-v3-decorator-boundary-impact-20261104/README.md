# Narrow decorator-boundary impact on existing v3 literal analysis

Independent read-only audit of the two canonical development trees; no production excerpt helper, source execution, target imports, CAMI, Git, Docker, model or heldout/private-state access. Existing outputs and source trees remain unchanged.

`summary.json` reports counts/hashes. `result-v2/report.json` retains every Python file SHA256, lexical/AST coverage and any risky definition coordinates. Whole-tree hashes match the existing terminal snapshot inputs; inventories are checked before/after. Catalog/snapshot raw hashes are verified. All70 Python files in each tree are assessed, with no unknown parse/lexical associations and no risky decorator starts.

The scanner uses stdlib tokenizer logical-statement `@` tokens, excluding comments/strings/matmul, then associates them with ordered AST decorator expressions at the definition's byte indentation. Every marker must be assigned; ambiguity/parse failure is unsupported, never zero risk. Newline normalization is used only to align tokenizer physical-line coordinates; no source bytes are rewritten or literal equality inferred from normalized text. Four authored controls cover parenthesized/continued starts, string/comment/matmul false positives, nested stacks and parse unknowns.

Reproduce with the exact absolute tree identities recorded in the old snapshot:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python runs/opencode-v3-decorator-boundary-impact-20261104/audit_decorator_boundaries.py --tree /root/apps/change-aware-memory-invalidation/runs/opencode-development-v3-staleness-20261104/origin-and-stage1 --tree /root/apps/change-aware-memory-invalidation/runs/opencode-development-v3-staleness-20261104/stage3 --catalog runs/opencode-development-v3-20261104/namespaces/r1-static/memory/prepared/catalog.json --snapshot runs/opencode-terminal-staleness-development-20261104/terminal-snapshot-final/report.json --out NEW_DIRECTORY
```

The initial relative-path invocation stopped before syntax scanning because expected tree identity keys were absolute. Its failure remains in result-v1. No outcome or source content was altered to obtain the result.

Conclusion: no instance of the narrow leading-physical-@ versus AST-expression-start counterexample exists in these exact canonical trees, and no catalog record/snapshot observation is affected by it. The old generator/analyzer still define their original min-AST-decorator-line recipe; this audit neither rewrites those results nor establishes complete physical-region/behavioral/causal reliance correctness. Awaiting the separate v2 core targeted review.
