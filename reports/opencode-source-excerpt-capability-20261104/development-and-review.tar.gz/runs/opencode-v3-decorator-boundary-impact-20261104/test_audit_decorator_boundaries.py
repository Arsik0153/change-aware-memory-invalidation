"""Small lexical controls: no target execution, CAMI imports, worktree or Docker."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_decorator_boundaries import inspect_source  # noqa: E402


def test_parenthesized_and_continued_decorators_detected():
    for text in ["@(\n    deco\n)\ndef f(): pass\n", "@\\\n    deco\ndef f(): pass\n"]:
        row = inspect_source(text.encode())
        assert row["status"] == "assessed"
        assert len(row["risks"]) == 1
        assert row["risks"][0]["physical_first_at_line"] == 1
        assert row["risks"][0]["old_recipe_first_line"] == 2


def test_strings_comments_matmul_not_decorator_markers():
    text = 's = """\n@(\n fake\n)\n"""\n# @fake\nm = left @ right\ndef f(): return m\n'
    row = inspect_source(text.encode())
    assert row["status"] == "assessed" and row["logical_decorator_markers"] == 0
    assert row["risks"] == []


def test_stacked_calls_nested_class_and_unicode_name_match_lexically():
    text = '@outer\nclass C:\n    @first(\n        1\n    )\n    @second\n    async def méthode(self):\n        @inside\n        def nested(): pass\n'
    row = inspect_source(text.encode())
    assert row["status"] == "assessed" and row["logical_decorator_markers"] == 4
    assert row["decorated_definitions"] == 3 and row["risks"] == []


def test_parse_failure_is_unknown_not_zero_risk():
    row = inspect_source(b'@(\n broken\ndef f(:\n')
    assert row["status"] == "unsupported"
