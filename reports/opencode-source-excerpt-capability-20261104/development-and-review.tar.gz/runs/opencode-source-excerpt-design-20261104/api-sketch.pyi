"""Proposed signatures only; not implementation and not imported by the product."""
from typing import Annotated, Literal
from pydantic import Field
from cami.product.models import Digest, ProductValue
from cami.product.memory.models import AgentContext, MutationReceipt, SourceRef, SymbolKey


class PythonDefinitionSpan(ProductValue):
    first_line: int = Field(ge=1)
    last_line: int = Field(ge=1)
    # Cross-field validation requires last_line >= first_line.


class PythonExcerptReady(ProductValue):
    status: Literal["ready"]
    format: Literal["python.definition-prefix/1"]
    span: PythonDefinitionSpan
    prefix_characters: int = Field(ge=1, le=2400)
    prefix_sha256: Digest
    truncated: bool
    # truncated implies prefix_characters == 2400.


class PythonExcerptUnavailable(ProductValue):
    status: Literal["unavailable"]
    reason: Literal["unsupported_encoding", "unsupported_definition", "invalid_source_span"]


PythonExcerptProjection = Annotated[
    PythonExcerptReady | PythonExcerptUnavailable,
    Field(discriminator="status"),
]
# Add DefinitionFact.python_excerpt: PythonExcerptProjection | None = None.
# None is legacy or non-Python, never a successful Python extraction.


class PythonExcerptExpected(ProductValue):
    format: Literal["python.definition-prefix/1"]
    text: str = Field(min_length=1, max_length=2400)
    truncated: bool
    # Strict UTF-8 encodability; truncated implies len(text) == 2400.


class SourceExcerptPayload(ProductValue):
    type: Literal["source_excerpt_equals"]
    subject: SymbolKey
    expected: PythonExcerptExpected
    origin_source: SourceRef
    origin_span: PythonDefinitionSpan
    # All values server-derived. Public remember input does NOT accept this model.


MemoryKind = Literal["symbol_exists", "signature_equals", "note", "source_excerpt_equals"]
# Extend the existing Payload union and RememberInput.kind with this shared kind.
# RememberInput keeps existing text/note_key fields for old kinds, but the new
# kind rejects any non-None text/note_key. No expected/source/span/hash field.


def project_python_excerpt(raw: bytes, indexed_ast_node: object) -> PythonExcerptProjection:
    """Pure: existing trusted indexed node; no new resolver or filesystem access."""
    ...


def origin_literal_from_certificate(
    raw_cas_bytes: bytes, certificate: PythonExcerptReady
) -> PythonExcerptExpected:
    """Pure: verify certificate span/count/hash/truncated against exact CAS bytes."""
    ...


def remember(
    kind: MemoryKind, query: str, context: AgentContext, request_id: str,
    *, note_key: str | None = None, text: str | None = None,
) -> MutationReceipt:
    """Existing ProductMemory method; new branch derives payload from backend CAS."""
    ...
