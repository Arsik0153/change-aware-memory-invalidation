# Server-minted Python literal source excerpts

Design only. No product code, tests, models, containers or study inputs changed. The target is useful, authenticated context that survives an unrelated edit in the same file. It is not a CPU optimization proposal.

## Usage and guarantee

The public call uses an existing authenticated context. There is no `expected`, `excerpt`, `span`, `hash`, `text` or `note_key` input for this kind:

```python
context = memory.context("src/api.py:Service.method")
receipt = memory.remember(
    "source_excerpt_equals", "src/api.py:Service.method", context, "register-method-1"
)
```

The service derives the expected literal from the immutable origin source behind `context`. A stale origin context is allowed as today: registration keeps that origin, and the current verified view can immediately withhold the claim. A mutation receipt does not assert availability.

The predicate is:

> For this exact Python subject, the current unique indexed definition has the same `(literal_prefix, truncated)` as the server-minted origin under `python.definition-prefix/1`.

This proves only the specified literal source projection. It does not prove behavior, imports, globals, inheritance, descriptor behavior, runtime reachability, full-function equality when truncated, or API equivalence. Changing a global used by an otherwise identical function can leave this predicate supported while changing behavior.

This is a new `SourceExcerptPayload`, not a new label for `NotePayload`. Existing manual notes retain their complete-source dependency and sticky `needs_review` policy. Nothing parses old note headers to create this predicate.

## Existing flow and ownership

`ProductMemory.context_many` captures a live worktree through `ProductIndexPort`, projects it to `CodeView`, validates records and verifies the capture again before publication. The Python projection already parses each module and associates indexed definitions with AST nodes. `GenerationStore` owns immutable index generations. `MemoryStore` owns source CAS objects, revisions, receipts and memory generations. `validation.transition` compares dependencies and either makes a new check or carries the last actual check with an equivalence witness.

Registration authenticates the submitted context against a stored immutable `CodeView`, checks that its memory generation names that index, and requires a unique unambiguous subject. Origin source bytes come from `MemoryStore.read_source`, which checks bounded CAS bytes, size and SHA-256. Current raw bytes come from the verified capture and are stored in the same CAS before publication. No filesystem read of an arbitrary caller path is introduced.

The extractor belongs to the memory projection layer, where the trusted AST node, raw captured bytes and indexed subject meet. It must not create a second symbol resolver in the adapter. The adapter consumes the typed result and preserves its literal-only label.

## Fixed extractor: `python.definition-prefix/1`

There are no caller-controlled extraction options in this version.

1. Accept supported Python `function` or `method` definitions already identified by the production index. Require exactly one match of the complete `SymbolKey` and reject its existing ambiguity or identity-uncertainty flags. A short name is only a query convenience. It must resolve to one complete subject before minting.
2. Use the exact captured raw file. Detect the Python encoding using the first two physical lines. Accept strict UTF-8 without BOM only. Explicitly reject a UTF-8 BOM and other coding-cookie encodings for this predicate, including an ASCII-only file declaring Latin-1. Existing existence/signature/manual-note behavior is unaffected.
3. Use the exact AST node already associated with the indexed definition by the Python projection. Decode the raw bytes strictly as UTF-8. Current core indexing parses the decoded string and treats a UTF-8 BOM as `parse_error`; do not bypass that limitation through `ast.parse(raw)` or strip the BOM for this feature. Broadening BOM support would be a separate core change.
4. Split physical lines only at CRLF, LF or CR, preserving every terminator. Do not use `str.splitlines()`: it also splits form feed and Unicode line separators that need not be Python physical line boundaries. Preserve these characters inside the selected text. No newline, indentation or Unicode normalization occurs.
5. Start at column zero of `min(node.lineno, decorator.lineno...)`. This includes all indentation and every multiline decorator. Include blank/comment lines between the first decorator and the definition. Exclude preceding comments, class headers and class decorators.
6. End after the complete physical line `node.end_lineno`, including its existing terminator and inline comment. Exclude following blank lines or comments. The whole-line contract intentionally differs from token-column extraction. Check that bounds exist and align with the node used by the index. Do not recover a missing node by searching for a same-name string.
7. Let `region` be those exact decoded physical lines. Set `literal_prefix = region[:2400]` and `truncated = len(region) > 2400`. Python Unicode code points are the counting unit: an emoji counts once, a combining sequence can count more than once, and CRLF counts twice. UTF-8 byte length may exceed 2,400. A prefix may end inside a line, decorator, string literal, CRLF pair or token; it is a source prefix, not necessarily executable code.
8. Hash `literal_prefix.encode("utf-8")` with SHA-256 for the current projection. The predicate compares both that literal and the truncation flag. A truncation marker is display metadata, never part of the expected literal.

A one-character change inside the prefix contradicts it, even if the AST is unchanged. A valid change strictly after the first 2,400 characters can leave it supported while both regions remain truncated. Shrinking a 2,401-character region to exactly 2,400 changes `truncated` and contradicts the tuple even if its prefix is identical. Edits that make the module unparsable yield insufficient evidence, including edits beyond the prefix.

Line movement alone does not contradict it. A move to another path or qualified name is a different subject. Moving a method within a class without changing its qualified name or literal prefix can preserve the predicate. Conditional, duplicate, nested-class, `global`, rebind and wildcard-import cases inherit production index conservatism. Nested functions already receive qualified names containing `<locals>`; a nested function cannot satisfy a top-level selector. No runtime-binding claim is added.

## Two candidate structures

| Candidate | Shape | Consequence |
|---|---|---|
| A, selected | The Python projection stores a small excerpt certificate on each supported definition: format, span, character count, SHA-256 and truncation. It does not store the 2,400-character text in every `CodeView`. | Reuses the existing AST/identity decision, keeps validation pure over a verified view, and supports exact dependency comparison. Adds bounded metadata to persisted views. |
| B, rejected for this first version | The validator reads CAS bytes and reparses each registered excerpt on demand. | Avoids projection metadata for unused definitions, but gives the pure validator storage access or adds a parallel preparation layer. It duplicates parsing/resolution, complicates authenticated stale contexts and batch behavior, and risks the adapter becoming another validator. |

A does not make source checking free. Changed files still require parsing and extraction. Certificate/storage cost must be measured before accepting this design as an optimization. An implementation must not copy complete snippets into all definition facts or add an independent index/DB writer.

## Data shape and minting

`PythonExcerptProjection` is a discriminated ready/unavailable result attached to `DefinitionFact`. A ready result has format, complete physical-line span, prefix character count, prefix SHA-256 and `truncated`. An unavailable result has a bounded reason. `None` means a legacy projection or a non-Python fact, not successful extraction. The new Python projector always produces ready or unavailable for a supported definition.

`SourceExcerptPayload` stores the complete subject, the expected format/text/truncation tuple, and the origin `SourceRef` and line span. The service derives these fields from the immutable backend fact and CAS bytes, verifies that reconstruction matches its stored certificate, and rejects a legacy origin without a supported certificate with `refresh_context_required`. It does not copy `context` text or caller-provided spans. `text` and `note_key` supplied with this kind are rejected, including through `RememberInput` and the CLI.

Use the existing claim identity domain, which already includes `payload.type`, worktree key and full subject. The new discriminator cannot collide with a manual-note identity. For semantic-payload comparison, compare subject and expected format/text/truncation; provenance-only origin index/hash/line movement does not create a semantic conflict. Repeating registration from another origin with the same predicate returns the existing revision and retains its original evidence. A changed predicate requires the existing explicit `update(..., expected_revision=...)` path. Updating this type derives its new expected tuple from the new authenticated context and rejects free-form `text`.

One bounded `origin_sources(payload)` helper must cover notes and excerpts wherever `observe` and the coordinator currently special-case `NotePayload.sources`. Every source-CAS integrity check must remain in place. Origin span/certificate consistency is authenticated at minting; rendering an excerpt must use that stored expected text, not substituted fresh source. Current `CheckRef.evidence` can remain a full `SourceRef`: the immutable `CodeView` for the check index supplies the selected span/certificate. No second source-witness hierarchy is needed.

The ordinary batch coordinator remains the sole writer. It derives all requests from authenticated contexts, verifies current sources, builds all receipts before commit, and publishes or rolls back the complete batch. Request-id hashes include the full server-minted request/evidence as today. A request-id retry preserves its original receipt; conflicting reuse fails. CAS objects left by a failed transaction are harmless unpublished evidence, not available facts.

## Checks, dependencies and history

| Current condition | Verdict |
|---|---|
| Unique, covered, certain Python subject and exact format/text/truncation match | `supported`, `source_excerpt_matches` |
| Same subject with a different extracted tuple | `contradicted`, `source_excerpt_mismatch` |
| Proven absent path or subject under complete parsed coverage | `contradicted`, existing absence witness |
| Excluded, ignored, symlink/special/oversize/unreadable source, parse error, unsupported encoding/format, ambiguous/unresolved identity or unavailable certificate | `insufficient_evidence`; no historical text in usable results |

A source-excerpt dependency domain includes validator/extractor versions, the complete subject, current policy/analyzer fingerprints, coverage and error/identity certainty, current prefix digest, prefix character count, and `truncated`. Missing-subject fingerprints include the proven-absence state. Do not include absolute line positions, containing-file SHA, full-region length, snapshot ID or generation ID: those would defeat retention after unrelated edits. Do not use the signature digest or AST digest as a proxy for literal equality.

The `check()` branch must explicitly handle this new payload **before** the current final `else` that assumes existence; otherwise a mismatching excerpt would be reported supported. Prefer an explicit existence branch and conservative unknown-predicate fallback, with a direct check test for mismatch.

The full containing source still invalidates extraction inputs. After any file change, obtain a new authenticated certificate from the captured bytes. Only then can equal dependency fingerprints carry the last actual check. Record the current `CodeView` and normal `Equivalence` from the actual-check index to the current index. A source hash/signature that appears unchanged must not authenticate a cached certificate if the raw source, policy, extractor, interpreter/analyzer or validator identity changed.

Insufficient evidence never establishes reusable certainty. Restoring the exact tuple after a known mismatch or absence requires a new actual check before availability returns. A carried check retains its historical check index and evidence; the current view/equivalence supplies current identity. Display origin line numbers as origin lines. Do not present a carried historical span as a fresh current location.

## Schema and compatibility

Add a distinct payload discriminator and version the extractor independently. New contexts advertise schema 2; their parser accepts schema 1 and schema 2. `DefinitionFact.python_excerpt` is optional with legacy default `None`, so the new reader accepts old code views without rewriting them. Do not add a separate code-view schema field solely for this feature. Do not synthesize certificates for old views while reading history. Old contexts remain usable for old operations; minting the new type requires a supported certificate and returns `refresh_context_required` for a legacy context.

Add the extractor file to **both** `product.store.index_fingerprint()` and `memory.validation.VALIDATOR_FINGERPRINT` inventories. Current lists already cover memory models/adapters. An analyzer generation changes when projection/extraction changes, preventing immutable `index_view` identity collisions. An extractor-semantics change requires a new format version or explicit continued implementation of the old format; never reinterpret old expected text under a changed rule.

**Keep the existing SQLite tables, `user_version=1`, initialization marker and publication protocol. No broad database migration is justified.** The old store's `_validate_connection` already parses every `index_view` with strict `CodeView` models and parses the head using a discriminated payload union. A new `python_excerpt` field triggers `extra=forbid`; the new payload triggers an unsupported discriminator. `MemoryStore.connection` catches the resulting validation error and refuses the operation. An old context reader also rejects the new context schema. No unsafe old-reader acceptance path was found. A clearer unsupported-capability diagnostic can be added at that existing validation boundary if useful; it must not relax validation or justify a second format registry.

The new reader accepts schema-1 histories and optional absent certificates, preserves their original records and receipts, and creates fresh projected generations because the index fingerprint changes. A schema-1 context with a new or forged excerpt field still must equal the immutable backend fact before minting. Old manual notes retain their payloads, identities, text, origin references, states and sticky review semantics. Published new data is not guaranteed readable by an old binary, despite the unchanged SQLite layout version; preserve the old DB snapshot for rollback rather than stripping fields or downgrading typed records. Tests must establish this exact read behavior and rollback on failure.

A future adapter/generator/catalog version must explicitly request the new kind, mint through the service, and expose a `validated_literal_source` label. Static mode can serve the equivalent origin tuple as unchecked-current source assertion. Do not call it a validated manual note or a behavior fact. New experiments must rebuild both arms from the same canonical origin and charge all generator, registration, extraction, lookup and storage costs. The frozen v3 experiment remains unchanged.

## Contrast with the existing generator and analyzer

The actual frozen generator is `examples/opencode_benchmark_development_v1/seed_source_notes.py`, SHA-256 `197215f529c5007b81d1ced1d28999b915ddbea9184cc132e8ae1a56650d83be`; it is byte-identical to the staged generator previously inspected. It selects direct public module functions and methods (plus `__init__` and `__call__`), parses raw Python bytes, decodes UTF-8, and uses `str.splitlines(keepends=True)`. It explicitly includes decorators with `min(node.lineno, decorator.lineno...)`, joins whole selected lines through `end_lineno`, then takes `[:2400]`. It writes a **manual note** containing historical headers, the excerpt and an optional truncation marker.

The installed `scripts/analyze_opencode_staleness.py:body` uses the same decorator start/line-span/prefix recipe for direct definitions. It compares the text prefix only. It does not compare truncation metadata or establish the production index's complete binding conservatism. Both already include decorators; neither uses `ast.get_source_segment` for this comparison.

By contrast, core `index.py` stores `Definition.source_segment = ast.get_source_segment(source, node)`. That is not the new literal contract: it omits decorator lines and leading physical-line indentation, and uses token-column bounds. Do not reuse it as the prefix proof.

The proposed format differs intentionally on physical-line splitting, explicit encoding acceptance (including keeping BOM unsupported by the current core index), certificate-backed selector authentication, and truncation-tuple comparison. Ordinary UTF-8 LF snippets often coincide, but equivalence is not assumed. The reported three unchanged prefixes among five withheld notes remain observations under the old analyzer, not retrospectively validated new predicates. Keep the old catalogs/results and freeze a distinct generator/catalog/protocol before a separate development experiment.

## Minimal implementation map and tests

See `contract.json` for the touched-file map and proposed test matrix. The minimum implementation crosses models, projection/extractor, registration/CAS source collection, validation, fingerprints, strict store compatibility checks, CLI and adapter presentation. It must preserve the old single and batch mutation coordinator and all existing manual-note behavior.

Before model evaluation, authored tests must prove exact extraction boundaries, included versus excluded edits, ambiguity/coverage, authenticated stale-origin minting, CAS integrity, final-verification rollback, recovery/lineage, old/new reader behavior and manual-note compatibility. No test or implementation is supplied by this design task.

## Is it useful?

This capability can keep a relevant historical excerpt usable when another function in its file changes, while withholding a changed excerpt. It supplies a precise literal-only certificate for a memory record and explains its lifetime. That can be useful when an agent needs the stored origin view and continuity matters.

It is not automatically better than regenerating current source notes or reading current code. Current capture/indexing already obtains source and this design extracts it again or stores additional certificates; regenerated current snippets could simply return current code with a different product contract. Native reads provide surrounding code and current locations that a 2,400-character prefix omits. The inspected native patch tool does not require a prior native-read freshness flag, so there is no hard read-tracker requirement to bypass.

The parent reports that the first complete block spent about 3.83 seconds in CAMI construction and 5.07 seconds in four lookups within 582.34 seconds charged, with no token win over plain. Those figures motivate useful safe context, not a CPU-speed claim. They are parent-supplied context, not remeasured here. A later comparison should assess whether the retained context changes relevant information exposure and task outcomes while counting construction, I/O, state growth and response bytes. No heldout tasks should guide this design.
